import numpy as np
import pandas as pd


REQUIRED_INPUT_COLUMNS = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
    "revenue",
    "cost",
    "gross_profit",
]


def build_monthly_analytics(enriched_df: pd.DataFrame) -> dict[str, object]:
    """
    Produce the monthly KPI tables required by dashboards and forecasting.

    Returns:
    {
        "monthly_company": monthly_company_df,
        "monthly_by_unit": monthly_by_unit_df,
        "monthly_cafe_location": monthly_cafe_location_df,
        "available_months": list_of_months,
    }
    """
    _validate_input(enriched_df)

    working_df = enriched_df.copy(deep=True)

    # Step 1: derive month key as month-start timestamp
    working_df["month"] = working_df["date"].dt.to_period(
        "M").dt.to_timestamp()

    # Step 2: company-wide monthly aggregation
    monthly_company = _build_monthly_company(working_df)

    # Step 3: business unit monthly aggregation
    monthly_by_unit = _build_monthly_by_unit(working_df)

    # Step 4: cafe location monthly aggregation
    monthly_cafe_location = _build_monthly_cafe_location(working_df)

    available_months = monthly_company["month"].tolist()

    return {
        "monthly_company": monthly_company,
        "monthly_by_unit": monthly_by_unit,
        "monthly_cafe_location": monthly_cafe_location,
        "available_months": available_months,
    }


def _build_monthly_company(df: pd.DataFrame) -> pd.DataFrame:
    monthly_company = (
        df.groupby("month", as_index=False)
        .agg(
            revenue=("revenue", "sum"),
            cost=("cost", "sum"),
            gross_profit=("gross_profit", "sum"),
        )
        .sort_values("month")
        .reset_index(drop=True)
    )

    monthly_company["gross_margin_pct"] = _safe_percentage(
        monthly_company["gross_profit"],
        monthly_company["revenue"]
    )

    domestic_customers = (
        df[df["business_unit"] == "Domestic"]
        .groupby("month")["customer_id"]
        .nunique(dropna=True)
        .rename("unique_domestic_customers")
        .reset_index()
    )

    commercial_customers = (
        df[df["business_unit"] == "Commercial"]
        .groupby("month")["customer_id"]
        .nunique(dropna=True)
        .rename("active_commercial_customers")
        .reset_index()
    )

    monthly_company = monthly_company.merge(
        domestic_customers,
        on="month",
        how="left"
    )

    monthly_company = monthly_company.merge(
        commercial_customers,
        on="month",
        how="left"
    )

    monthly_company["unique_domestic_customers"] = (
        monthly_company["unique_domestic_customers"]
        .fillna(0)
        .astype("int64")
    )

    monthly_company["active_commercial_customers"] = (
        monthly_company["active_commercial_customers"]
        .fillna(0)
        .astype("int64")
    )

    previous_revenue = monthly_company["revenue"].shift(1)

    monthly_company["mom_revenue_growth_pct"] = np.where(
        previous_revenue.isna() | (previous_revenue == 0),
        np.nan,
        ((monthly_company["revenue"] - previous_revenue) /
         previous_revenue) * 100
    )

    monthly_company = monthly_company[
        [
            "month",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
            "unique_domestic_customers",
            "active_commercial_customers",
            "mom_revenue_growth_pct",
        ]
    ].copy()

    return monthly_company


def _build_monthly_by_unit(df: pd.DataFrame) -> pd.DataFrame:
    monthly_by_unit = (
        df.groupby(["month", "business_unit"], as_index=False)
        .agg(
            revenue=("revenue", "sum"),
            cost=("cost", "sum"),
            gross_profit=("gross_profit", "sum"),
        )
        .sort_values(["month", "business_unit"])
        .reset_index(drop=True)
    )

    monthly_by_unit["gross_margin_pct"] = _safe_percentage(
        monthly_by_unit["gross_profit"],
        monthly_by_unit["revenue"]
    )

    monthly_by_unit = monthly_by_unit[
        [
            "month",
            "business_unit",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
        ]
    ].copy()

    return monthly_by_unit


def _build_monthly_cafe_location(df: pd.DataFrame) -> pd.DataFrame:
    cafe_df = df[df["business_unit"] == "Cafe"].copy()

    monthly_cafe_location = (
        cafe_df.groupby(["month", "cafe_location"], as_index=False)
        .agg(
            revenue=("revenue", "sum"),
            cost=("cost", "sum"),
            gross_profit=("gross_profit", "sum"),
        )
        .sort_values(["month", "cafe_location"])
        .reset_index(drop=True)
    )

    monthly_cafe_location["gross_margin_pct"] = _safe_percentage(
        monthly_cafe_location["gross_profit"],
        monthly_cafe_location["revenue"]
    )

    monthly_cafe_location = monthly_cafe_location[
        [
            "month",
            "cafe_location",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
        ]
    ].copy()

    return monthly_cafe_location


def _safe_percentage(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    """
    Return numerator / denominator * 100.
    If denominator is 0 or missing, return NaN.
    """
    return pd.Series(
        np.where(
            denominator.isna() | (denominator == 0),
            np.nan,
            (numerator / denominator) * 100
        ),
        index=numerator.index,
        dtype="float64",
    )


def _validate_input(enriched_df: pd.DataFrame) -> None:
    if not isinstance(enriched_df, pd.DataFrame):
        raise ValueError("enriched_df must be a pandas DataFrame.")

    actual_columns = list(enriched_df.columns)
    if actual_columns != REQUIRED_INPUT_COLUMNS:
        raise ValueError(
            "enriched_df does not match the expected schema for Node 5.\n"
            f"Expected: {REQUIRED_INPUT_COLUMNS}\n"
            f"Actual:   {actual_columns}"
        )

    if not pd.api.types.is_datetime64_any_dtype(enriched_df["date"]):
        raise ValueError(
            "Column 'date' must be datetime before monthly analytics.")

    numeric_columns = ["revenue", "cost", "gross_profit"]
    for column_name in numeric_columns:
        if not pd.api.types.is_numeric_dtype(enriched_df[column_name]):
            raise ValueError(
                f"Column '{column_name}' must be numeric before monthly analytics."
            )

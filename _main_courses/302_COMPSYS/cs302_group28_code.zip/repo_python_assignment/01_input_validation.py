from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from pandas.errors import EmptyDataError, ParserError


COMMERCIAL_HEADERS = [
    "invoice_id",
    "date",
    "customer_id",
    "salesperson_id",
    "segment",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "unit_cost",
]

DOMESTIC_HEADERS = [
    "order_id",
    "date",
    "customer_id",
    "salesperson_id",
    "segment",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "unit_cost",
]

CAFE_HEADERS = [
    "date",
    "cafe_location",
    "sku",
    "qty_sold",
    "list_unit_price",
    "unit_cost",
]


EXPECTED_SCHEMAS = {
    "commercial": COMMERCIAL_HEADERS,
    "domestic": DOMESTIC_HEADERS,
    "cafe": CAFE_HEADERS,
}

DISPLAY_NAMES = {
    "commercial": "Commercial",
    "domestic": "Domestic",
    "cafe": "Cafe",
}


def validate_input_files(commercial_path: str, domestic_path: str, cafe_path: str) -> Dict:
    """
    Validate the three selected CSV files for existence, extension, readability,
    non-empty content, and correct schema assignment.

    Returns:
        {
            "ok": bool,
            "errors": list[str],
            "raw_data": {
                "commercial": pd.DataFrame | None,
                "domestic": pd.DataFrame | None,
                "cafe": pd.DataFrame | None,
            }
        }
    """
    errors: List[str] = []
    raw_data = {
        "commercial": None,
        "domestic": None,
        "cafe": None,
    }

    file_map = {
        "commercial": commercial_path,
        "domestic": domestic_path,
        "cafe": cafe_path,
    }

    for file_role, file_path in file_map.items():
        df, file_errors = _validate_single_file(file_path, file_role)
        if file_errors:
            errors.extend(file_errors)
        else:
            raw_data[file_role] = df

    return {
        "ok": len(errors) == 0,
        "errors": errors,
        "raw_data": raw_data,
    }


def _validate_single_file(file_path: str, expected_role: str) -> tuple[Optional[pd.DataFrame], List[str]]:
    """
    Validate one file against the expected schema for its slot.
    """
    errors: List[str] = []
    display_name = DISPLAY_NAMES[expected_role]

    if file_path is None or str(file_path).strip() == "":
        errors.append(f"{display_name} file path is missing.")
        return None, errors

    path_obj = Path(file_path)

    if not path_obj.exists():
        errors.append(f"{display_name} file does not exist: {file_path}")
        return None, errors

    if not path_obj.is_file():
        errors.append(f"{display_name} path is not a file: {file_path}")
        return None, errors

    if path_obj.suffix.lower() != ".csv":
        errors.append(f"{display_name} file must be a .csv file: {file_path}")
        return None, errors

    try:
        df = pd.read_csv(path_obj)
    except EmptyDataError:
        errors.append(f"{display_name} file is empty: {file_path}")
        return None, errors
    except ParserError as exc:
        errors.append(
            f"{display_name} file could not be parsed as CSV: {file_path}. {exc}")
        return None, errors
    except Exception as exc:
        errors.append(
            f"{display_name} file could not be read: {file_path}. {exc}")
        return None, errors

    if df.empty:
        errors.append(
            f"{display_name} file contains headers but no data rows: {file_path}")
        return None, errors

    duplicate_headers = df.columns[df.columns.duplicated()].tolist()
    if duplicate_headers:
        errors.append(
            f"{display_name} file has duplicate headers: {sorted(set(duplicate_headers))}"
        )
        return None, errors

    header_errors = _validate_headers(df.columns.tolist(), expected_role)
    if header_errors:
        errors.extend(header_errors)
        return None, errors

    return df, errors


def _validate_headers(actual_headers: List[str], expected_role: str) -> List[str]:
    """
    Validate the actual headers against the expected schema for the slot.

    This implementation is strict:
    - exact header names required
    - no missing headers
    - no unexpected extra headers
    - column order does not matter
    """
    errors: List[str] = []

    actual_set = set(actual_headers)
    expected_set = set(EXPECTED_SCHEMAS[expected_role])
    display_name = DISPLAY_NAMES[expected_role]

    # Exact schema match for the expected slot
    if actual_set == expected_set:
        return errors

    # Detect obvious misassignment first
    matched_roles = []
    for role_name, schema_headers in EXPECTED_SCHEMAS.items():
        if actual_set == set(schema_headers):
            matched_roles.append(role_name)

    if matched_roles and expected_role not in matched_roles:
        detected_role = matched_roles[0]
        detected_name = DISPLAY_NAMES[detected_role]
        errors.append(
            f"{display_name} slot received a {detected_name} file. "
            f"You likely assigned the wrong CSV to the {display_name} input."
        )
        return errors

    # Otherwise, report structural mismatch precisely
    missing_headers = sorted(expected_set - actual_set)
    unexpected_headers = sorted(actual_set - expected_set)

    message_parts = [
        f"{display_name} file headers do not match the required schema."]

    if missing_headers:
        message_parts.append(f"Missing headers: {missing_headers}.")
    if unexpected_headers:
        message_parts.append(f"Unexpected headers: {unexpected_headers}.")

    message_parts.append(
        f"Expected headers: {EXPECTED_SCHEMAS[expected_role]}.")

    errors.append(" ".join(message_parts))
    return errors

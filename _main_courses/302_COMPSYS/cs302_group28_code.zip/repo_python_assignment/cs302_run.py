import sys
import importlib.util
from pathlib import Path

from PyQt6.QtWidgets import QApplication, QMessageBox


BASE_FOLDER = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = BASE_FOLDER / filename

    if not module_path.exists():
        raise FileNotFoundError(f"Required file not found: {module_path}")

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RoastWorksApplication:
    """
    End-to-end application launcher.

    Flow:
    Node 8 (file selection) -> pipeline runs -> Node 9 (main dashboard shell)
    """

    def __init__(self):
        self.app = QApplication(sys.argv)

        self.node8 = load_module(
            "08_pyqt_file_selection_screen.py", "node8_file_selection")
        self.node9 = load_module(
            "09_pyqt_gui_application.py", "node9_gui_application")

        self.file_selection_window = None
        self.main_window = None

    def launch(self):
        self.file_selection_window = self.node8.FileSelectionScreen(
            on_pipeline_ready=self._handle_pipeline_ready
        )

        self.file_selection_window.pipeline_failed.connect(
            self._handle_pipeline_failed)

        self.file_selection_window.setWindowTitle("RoastWorks, File Selection")
        self.file_selection_window.resize(1100, 760)
        self.file_selection_window.show()

        return self.app.exec()

    def _handle_pipeline_ready(self, pipeline_package: dict):
        """
        Called by Node 8 when Nodes 1 to 7 complete successfully.
        """
        try:
            self.main_window = self.node9.MainWindow(pipeline_package)
            self.main_window.showMaximized()

            if self.file_selection_window is not None:
                self.file_selection_window.close()
                self.file_selection_window = None

        except Exception as exc:
            QMessageBox.critical(
                None,
                "Application Launch Error",
                f"Pipeline succeeded, but the main dashboard could not be opened.\n\n"
                f"{type(exc).__name__}: {exc}"
            )

    def _handle_pipeline_failed(self, errors: list):
        """
        Optional top-level hook for pipeline failure.
        Node 8 already shows readable errors inside its own UI.
        This is just an extra guard if you want to inspect failures globally.
        """
        # No popup needed here because Node 8 already displays readable errors.
        # Keeping this method for future extension or debugging.
        pass


if __name__ == "__main__":
    try:
        launcher = RoastWorksApplication()
        sys.exit(launcher.launch())
    except Exception as exc:
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        QMessageBox.critical(
            None,
            "Fatal Startup Error",
            f"The application could not start.\n\n{type(exc).__name__}: {exc}"
        )
        sys.exit(1)

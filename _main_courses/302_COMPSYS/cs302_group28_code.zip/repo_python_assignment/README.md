# RoastWorks Sales Analytics Dashboard

This project is a PyQt6 desktop application for loading three business-unit CSV files, validating and standardising them, merging them into a unified transaction dataset, calculating monthly KPIs, generating forecasts, and displaying the results in dashboard views.

The application is structured node-by-node to match the system design and implementation workflow used during development.

## Submitted Runtime Files

The following files make up the running application:

- `01_input_validation.py`  
  Validates the three selected CSV files. Checks file existence, file type, readability, emptiness, and required headers.

- `02_data_cleaning_standardising.py`  
  Cleans and standardises the three raw datasets into a shared internal schema while keeping them separate.

- `03_merge_unified_dataset.py`  
  Concatenates the cleaned datasets into one canonical unified transaction dataset.

- `04_per_row_financial_calculations.py`  
  Adds row-level financial columns: revenue, cost, and gross profit.

- `05_monthly_analytics_engine.py`  
  Builds monthly analytics tables for company-wide and business-unit dashboards.

- `06_forecasting_engine.py`  
  Generates forecasts and evaluation metrics using the selected models:
  - `linear_regression_lag3`
  - `exponential_smoothing`
  - `naive`

- `07_dashboard_data_preparation.py`  
  Converts backend outputs into GUI-ready dashboard bundles.

- `08_pyqt_file_selection_screen.py`  
  PyQt file selection screen for choosing CSV files and triggering the backend pipeline.

- `09_pyqt_gui_application.py`  
  Main PyQt application shell using `QMainWindow`, shared state, navigation, and dashboard refresh logic.

- `10_company_wide_dashboard.py`  
  Company-wide dashboard page.

- `11_business_unit_dashboard.py`  
  Business-unit dashboard page.

- `12_forecast_dashboard.py`  
  Forecast dashboard page.

- `cs302_run.py`  
  Main entry point used to launch the application.

### Generative AI Statement

This project used generative AI tools during development for code drafting, refinement, debugging support, structural planning, and UI adaptation. AI assistance was used to help develop and polish node-based backend modules, PyQt dashboard components, and repository documentation.

.gitignore contents were heavily suggested by AI

All AI-generated or AI-assisted code was reviewed, checked, modified where necessary, and understood before inclusion in the final submission. Final design decisions, locked specifications, and project integration choices were made by; Fitz Gerald Dumlao, Sharun Anton Constantine.

## Additional Libraries Used

This project uses the following non-built-in Python libraries:

- `PyQt6`
- `pandas`
- `matplotlib`
- `numpy`
- `scikit-learn`
- `statsmodels`

## How to Run

Keep all runtime node files and `cs302_run.py` in the same folder, then run:

```bash
pip install PyQt6 pandas matplotlib numpy scikit-learn statsmodels
python cs302_run.py

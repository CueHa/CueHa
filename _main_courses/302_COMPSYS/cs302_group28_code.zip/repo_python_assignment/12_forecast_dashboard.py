from typing import Optional

import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


SCOPE_OPTIONS = [
    ("Company", "company"),
    ("Commercial", "commercial"),
    ("Domestic", "domestic"),
    ("Cafe", "cafe"),
]

METRIC_OPTIONS = [
    ("Revenue", "revenue"),
    ("Cost", "cost"),
    ("Gross Margin %", "gross_margin_pct"),
]

MODEL_OPTIONS = [
    ("Linear Regression", "linear_regression_lag3"),
    ("Exponential Smoothing", "exponential_smoothing"),
    ("Naive", "naive"),
]


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(28)
        self.set_badge_style(text, bg_color, text_color)

    def set_badge_style(
        self,
        text: str,
        bg_color: str,
        text_color: str = "#1f2937",
    ) -> None:
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class MetricCard(QFrame):
    def __init__(
        self,
        title: str,
        subtitle: str,
        bg_color: str = "white",
        border_color: str = "#d9dee7",
        value_color: str = "#111827",
    ):
        super().__init__()

        self.value_color = value_color

        self.setMinimumHeight(88)
        self.setMaximumHeight(100)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Fixed,
        )

        self.setStyleSheet(
            f"""
            QFrame {{
                background-color: {bg_color};
                border: 1px solid {border_color};
                border-radius: 12px;
            }}
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(4)

        self.title_label = QLabel(title)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet(
            "font-size: 11px; font-weight: 800; color: #374151;"
        )

        self.value_label = QLabel("N/A")
        self.value_label.setWordWrap(True)
        self.value_label.setStyleSheet(
            f"font-size: 18px; font-weight: 800; color: {self.value_color};"
        )

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setStyleSheet(
            "font-size: 10px; color: #6b7280;"
        )

        layout.addWidget(self.title_label)
        layout.addWidget(self.value_label)
        layout.addWidget(self.subtitle_label)
        layout.addStretch()

    def set_value(
        self,
        value_text: str,
        subtitle_text: Optional[str] = None,
    ) -> None:
        self.value_label.setText(value_text)
        if subtitle_text is not None:
            self.subtitle_label.setText(subtitle_text)


class ForecastChartCanvas(FigureCanvas):
    def __init__(self, parent: Optional[QWidget] = None):
        self.figure = Figure(figsize=(10, 5.5), tight_layout=True)
        self.axes = self.figure.add_subplot(111)

        super().__init__(self.figure)

        self.setParent(parent)
        self.setMinimumHeight(430)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

    def plot_forecast(
        self,
        history_df: pd.DataFrame,
        test_predictions_df: pd.DataFrame,
        future_forecast_df: pd.DataFrame,
        scope_label: str,
        metric_label: str,
        model_label: str,
    ) -> None:
        self.axes.clear()

        has_any_data = (
            history_df is not None and not history_df.empty
        ) or (
            test_predictions_df is not None and not test_predictions_df.empty
        ) or (
            future_forecast_df is not None and not future_forecast_df.empty
        )

        if not has_any_data:
            self.axes.text(
                0.5,
                0.5,
                "No forecast data available",
                ha="center",
                va="center",
                transform=self.axes.transAxes,
            )
            self.axes.set_xticks([])
            self.axes.set_yticks([])
            self.draw()
            return

        if history_df is not None and not history_df.empty:
            history_working = history_df.copy()
            history_working["month"] = pd.to_datetime(
                history_working["month"]
            )
            history_working = history_working.sort_values("month")

            self.axes.plot(
                history_working["month"],
                history_working["actual_value"],
                label="Historical",
                linewidth=2.6,
                color="#334155",
            )

        if test_predictions_df is not None and not test_predictions_df.empty:
            test_working = test_predictions_df.copy()
            test_working["month"] = pd.to_datetime(test_working["month"])
            test_working = test_working.sort_values("month")

            self.axes.plot(
                test_working["month"],
                test_working["predicted_value"],
                label="Test Prediction",
                linewidth=2.3,
                linestyle="--",
                color="#2563eb",
                marker="o",
            )

        if future_forecast_df is not None and not future_forecast_df.empty:
            future_working = future_forecast_df.copy()
            future_working["month"] = pd.to_datetime(
                future_working["month"]
            )
            future_working = future_working.sort_values("month")

            self.axes.plot(
                future_working["month"],
                future_working["forecast_value"],
                label="Future Forecast",
                linewidth=2.3,
                linestyle="--",
                color="#0f766e",
                marker="o",
            )

        display_metric = self._metric_label_from_value(metric_label)
        display_model = self._model_label_from_value(model_label)

        self.axes.set_title(
            f"{scope_label} Forecast, {display_metric}, {display_model}",
            fontsize=10,
            pad=8,
        )

        self.axes.set_xlabel("Month")
        self.axes.set_facecolor("#f8fafc")
        self.axes.grid(True, alpha=0.25)
        self.axes.legend(loc="upper left")

        if metric_label in ["revenue", "cost"]:
            self.axes.set_ylabel("Value ($)")
            self.axes.yaxis.set_major_formatter(
                FuncFormatter(lambda value, _: f"${value:,.0f}")
            )
        elif metric_label == "gross_margin_pct":
            self.axes.set_ylabel("Gross Margin (%)")
            self.axes.yaxis.set_major_formatter(
                FuncFormatter(lambda value, _: f"{value:.1f}%")
            )
        else:
            self.axes.set_ylabel("Value")

        for spine in self.axes.spines.values():
            spine.set_color("#d1d5db")

        self.figure.autofmt_xdate()
        self.draw()

    def _metric_label_from_value(self, metric_value: str) -> str:
        for display_text, internal_value in METRIC_OPTIONS:
            if internal_value == metric_value:
                return display_text
        return metric_value

    def _model_label_from_value(self, model_value: str) -> str:
        for display_text, internal_value in MODEL_OPTIONS:
            if internal_value == model_value:
                return display_text
        return model_value


class ForecastDashboard(QWidget):
    scope_changed = pyqtSignal(str)
    metric_changed = pyqtSignal(str)
    model_changed = pyqtSignal(str)

    def __init__(
        self,
        forecast_dashboard_bundle: Optional[dict] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)

        self._current_bundle: Optional[dict] = None

        self.setStyleSheet(
            """
            QWidget {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 6px 10px;
                font-size: 12px;
                color: #111827;
                min-height: 20px;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
            }
            """
        )

        self._build_ui()

        if forecast_dashboard_bundle is not None:
            self.set_dashboard_data(forecast_dashboard_bundle)

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 18, 24, 18)
        main_layout.setSpacing(10)

        header_card = QFrame()
        header_card.setMaximumHeight(80)
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 12, 18, 12)
        header_layout.setSpacing(16)

        title = QLabel("Forecasting Dashboard")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;"
        )

        subtitle = QLabel(
            "Historical sales values, forecast output, and model error metrics."
        )
        subtitle.setWordWrap(False)
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")

        title_block = QVBoxLayout()
        title_block.setSpacing(2)
        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        self.loaded_badge = StatusBadge(
            "Forecast Loaded", "#dcfce7", "#166534"
        )
        self.loaded_badge.setFixedWidth(130)

        self.scope_badge = StatusBadge("Forecast View", "#dbeafe", "#1d4ed8")
        self.scope_badge.setFixedWidth(120)

        header_layout.addWidget(self.loaded_badge)
        header_layout.addWidget(self.scope_badge)

        main_layout.addWidget(header_card)

        controls_card = self._make_info_card("Forecast Controls")
        controls_card.setMaximumHeight(88)
        controls_layout = controls_card.layout()

        controls_grid = QGridLayout()
        controls_grid.setHorizontalSpacing(10)
        controls_grid.setVerticalSpacing(0)

        scope_label = QLabel("Scope")
        scope_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.scope_selector = QComboBox()
        for display_text, internal_value in SCOPE_OPTIONS:
            self.scope_selector.addItem(display_text, internal_value)
        self.scope_selector.currentIndexChanged.connect(self._on_scope_changed)

        metric_label = QLabel("Metric")
        metric_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.metric_selector = QComboBox()
        for display_text, internal_value in METRIC_OPTIONS:
            self.metric_selector.addItem(display_text, internal_value)
        self.metric_selector.currentIndexChanged.connect(
            self._on_metric_changed
        )

        model_label = QLabel("Model")
        model_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.model_selector = QComboBox()
        for display_text, internal_value in MODEL_OPTIONS:
            self.model_selector.addItem(display_text, internal_value)
        self.model_selector.currentIndexChanged.connect(
            self._on_model_changed
        )

        controls_grid.addWidget(scope_label, 0, 0)
        controls_grid.addWidget(self.scope_selector, 0, 1)
        controls_grid.addWidget(metric_label, 0, 2)
        controls_grid.addWidget(self.metric_selector, 0, 3)
        controls_grid.addWidget(model_label, 0, 4)
        controls_grid.addWidget(self.model_selector, 0, 5)

        controls_grid.setColumnStretch(0, 0)
        controls_grid.setColumnStretch(1, 2)
        controls_grid.setColumnStretch(2, 0)
        controls_grid.setColumnStretch(3, 2)
        controls_grid.setColumnStretch(4, 0)
        controls_grid.setColumnStretch(5, 3)

        controls_layout.addLayout(controls_grid)
        main_layout.addWidget(controls_card)

        kpi_grid = QGridLayout()
        kpi_grid.setHorizontalSpacing(12)
        kpi_grid.setVerticalSpacing(0)

        self.scope_card = MetricCard(
            "Scope",
            "Forecast view",
            bg_color="#eff6ff",
            border_color="#bfdbfe",
            value_color="#1d4ed8",
        )
        self.metric_card = MetricCard(
            "Metric",
            "Forecast target",
            bg_color="#eef2ff",
            border_color="#c7d2fe",
            value_color="#3730a3",
        )
        self.model_card = MetricCard(
            "Model",
            "Selected method",
            bg_color="#f5f3ff",
            border_color="#ddd6fe",
            value_color="#5b21b6",
        )
        self.mae_card = MetricCard(
            "MAE",
            "Mean absolute error",
            bg_color="#fff7ed",
            border_color="#fed7aa",
            value_color="#9a3412",
        )
        self.rmse_card = MetricCard(
            "RMSE",
            "Root mean squared error",
            bg_color="#fff7ed",
            border_color="#fed7aa",
            value_color="#9a3412",
        )

        kpi_grid.addWidget(self.scope_card, 0, 0)
        kpi_grid.addWidget(self.metric_card, 0, 1)
        kpi_grid.addWidget(self.model_card, 0, 2)
        kpi_grid.addWidget(self.mae_card, 0, 3)
        kpi_grid.addWidget(self.rmse_card, 0, 4)

        kpi_grid.setColumnStretch(0, 1)
        kpi_grid.setColumnStretch(1, 1)
        kpi_grid.setColumnStretch(2, 2)
        kpi_grid.setColumnStretch(3, 1)
        kpi_grid.setColumnStretch(4, 1)

        main_layout.addLayout(kpi_grid)

        chart_card = self._make_info_card("Forecast Chart")
        chart_card.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

        chart_layout = chart_card.layout()

        self.chart_subtitle = QLabel(
            "Historical values, test prediction overlay, and 3-month future forecast."
        )
        self.chart_subtitle.setWordWrap(False)
        self.chart_subtitle.setStyleSheet(
            "font-size: 12px; color: #4b5563;"
        )

        chart_layout.addWidget(self.chart_subtitle)

        self.forecast_canvas = ForecastChartCanvas(self)
        chart_layout.addWidget(self.forecast_canvas, 1)

        main_layout.addWidget(chart_card, 1)

    def _make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 10, 16, 10)
        layout.setSpacing(8)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(title)

        return card

    def set_dashboard_data(self, forecast_dashboard_bundle: dict) -> None:
        self._validate_bundle(forecast_dashboard_bundle)

        self._current_bundle = forecast_dashboard_bundle

        selected_scope = str(forecast_dashboard_bundle["selected_scope"])
        selected_metric = str(forecast_dashboard_bundle["selected_metric"])
        selected_model = str(forecast_dashboard_bundle["selected_model"])

        history_df = forecast_dashboard_bundle["history"].copy()
        test_predictions_df = forecast_dashboard_bundle[
            "test_predictions"
        ].copy()
        future_forecast_df = forecast_dashboard_bundle[
            "future_forecast"
        ].copy()
        displayed_error_metrics = forecast_dashboard_bundle[
            "displayed_error_metrics"
        ]

        scope_label = self._scope_label_from_value(selected_scope)
        metric_label = self._metric_label_from_value(selected_metric)
        model_label = self._model_label_from_value(selected_model)

        self.scope_badge.set_badge_style(scope_label, "#dbeafe", "#1d4ed8")

        self._set_scope_selector(selected_scope)
        self._set_metric_selector(selected_metric)
        self._set_model_selector(selected_model)

        self.scope_card.set_value(scope_label, "Forecast view")
        self.metric_card.set_value(metric_label, "Forecast target")
        self.model_card.set_value(model_label, selected_model)

        self.mae_card.set_value(
            self._format_error_metric(
                displayed_error_metrics.get("mae"),
                selected_metric,
            ),
            "Mean absolute error",
        )
        self.rmse_card.set_value(
            self._format_error_metric(
                displayed_error_metrics.get("rmse"),
                selected_metric,
            ),
            "Root mean squared error",
        )

        self.forecast_canvas.plot_forecast(
            history_df=history_df,
            test_predictions_df=test_predictions_df,
            future_forecast_df=future_forecast_df,
            scope_label=scope_label,
            metric_label=selected_metric,
            model_label=selected_model,
        )

        history_count = 0 if history_df is None else len(history_df)
        test_count = 0 if test_predictions_df is None else len(
            test_predictions_df
        )
        future_count = 0 if future_forecast_df is None else len(
            future_forecast_df
        )

        self.chart_subtitle.setText(
            f"{history_count} historical points | "
            f"{test_count} test predictions | "
            f"{future_count} future forecast points | "
            f"MAE {self._format_error_metric(displayed_error_metrics.get('mae'), selected_metric)} | "
            f"RMSE {self._format_error_metric(displayed_error_metrics.get('rmse'), selected_metric)}"
        )

    def _set_scope_selector(self, selected_scope: str) -> None:
        target_index = -1

        for i in range(self.scope_selector.count()):
            if self.scope_selector.itemData(i) == selected_scope:
                target_index = i
                break

        if target_index >= 0:
            self.scope_selector.blockSignals(True)
            self.scope_selector.setCurrentIndex(target_index)
            self.scope_selector.blockSignals(False)

    def _set_metric_selector(self, selected_metric: str) -> None:
        target_index = self.metric_selector.findData(selected_metric)

        if target_index >= 0:
            self.metric_selector.blockSignals(True)
            self.metric_selector.setCurrentIndex(target_index)
            self.metric_selector.blockSignals(False)

    def _set_model_selector(self, selected_model: str) -> None:
        target_index = self.model_selector.findData(selected_model)

        if target_index >= 0:
            self.model_selector.blockSignals(True)
            self.model_selector.setCurrentIndex(target_index)
            self.model_selector.blockSignals(False)

    def _on_scope_changed(self, index: int) -> None:
        if index < 0:
            return

        scope_value = self.scope_selector.itemData(index)

        if scope_value is not None:
            self.scope_changed.emit(str(scope_value))

    def _on_metric_changed(self, index: int) -> None:
        if index < 0:
            return

        metric_value = self.metric_selector.itemData(index)

        if metric_value is not None:
            self.metric_changed.emit(str(metric_value))

    def _on_model_changed(self, index: int) -> None:
        if index < 0:
            return

        model_value = self.model_selector.itemData(index)

        if model_value is not None:
            self.model_changed.emit(str(model_value))

    def _validate_bundle(self, bundle: dict) -> None:
        required_keys = [
            "selected_scope",
            "selected_metric",
            "selected_model",
            "history",
            "test_predictions",
            "future_forecast",
            "displayed_error_metrics",
        ]

        for key in required_keys:
            if key not in bundle:
                raise ValueError(
                    f"forecast_dashboard_bundle is missing required key: '{key}'"
                )

        if bundle["selected_scope"] not in [value for _, value in SCOPE_OPTIONS]:
            raise ValueError(
                f"Invalid selected_scope: {bundle['selected_scope']}"
            )

        if bundle["selected_metric"] not in [
            value for _, value in METRIC_OPTIONS
        ]:
            raise ValueError(
                f"Invalid selected_metric: {bundle['selected_metric']}"
            )

        if bundle["selected_model"] not in [
            value for _, value in MODEL_OPTIONS
        ]:
            raise ValueError(
                f"Invalid selected_model: {bundle['selected_model']}"
            )

        history_df = bundle["history"]
        test_predictions_df = bundle["test_predictions"]
        future_forecast_df = bundle["future_forecast"]

        if not isinstance(history_df, pd.DataFrame):
            raise ValueError("history must be a pandas DataFrame.")
        if not isinstance(test_predictions_df, pd.DataFrame):
            raise ValueError("test_predictions must be a pandas DataFrame.")
        if not isinstance(future_forecast_df, pd.DataFrame):
            raise ValueError("future_forecast must be a pandas DataFrame.")

        for column_name in ["month", "actual_value", "model_value"]:
            if column_name not in history_df.columns:
                raise ValueError(
                    f"history is missing required column: '{column_name}'"
                )

        for column_name in ["month", "predicted_value"]:
            if column_name not in test_predictions_df.columns:
                raise ValueError(
                    f"test_predictions is missing required column: '{column_name}'"
                )

        for column_name in ["month", "forecast_value"]:
            if column_name not in future_forecast_df.columns:
                raise ValueError(
                    f"future_forecast is missing required column: '{column_name}'"
                )

        displayed_error_metrics = bundle["displayed_error_metrics"]

        if not isinstance(displayed_error_metrics, dict):
            raise ValueError("displayed_error_metrics must be a dictionary.")

        for metric_name in ["mae", "rmse"]:
            if metric_name not in displayed_error_metrics:
                raise ValueError(
                    f"displayed_error_metrics is missing required key: '{metric_name}'"
                )

    def _scope_label_from_value(self, selected_scope: str) -> str:
        for display_text, internal_value in SCOPE_OPTIONS:
            if internal_value == selected_scope:
                return display_text

        return selected_scope

    def _metric_label_from_value(self, selected_metric: str) -> str:
        for display_text, internal_value in METRIC_OPTIONS:
            if internal_value == selected_metric:
                return display_text

        return selected_metric

    def _model_label_from_value(self, selected_model: str) -> str:
        for display_text, internal_value in MODEL_OPTIONS:
            if internal_value == selected_model:
                return display_text

        return selected_model

    def _format_number(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"

        return f"{float(value):.4f}"

    def _format_error_metric(self, value, selected_metric: str) -> str:
        if value is None or pd.isna(value):
            return "N/A"

        numeric_value = float(value)

        if selected_metric in ["revenue", "cost"]:
            return f"${numeric_value:,.2f}"

        if selected_metric == "gross_margin_pct":
            return f"{numeric_value:.2f}%"

        return f"{numeric_value:.2f}"


if __name__ == "__main__":
    import sys

    demo_history = pd.DataFrame({
        "month": pd.date_range(start="2023-01-01", periods=36, freq="MS"),
        "actual_value": [100 + i * 4.5 for i in range(36)],
        "model_value": [100 + i * 4.5 for i in range(36)],
    })

    demo_test_predictions = pd.DataFrame({
        "month": pd.date_range(start="2025-10-01", periods=3, freq="MS"),
        "actual_value": [250.0, 254.0, 259.0],
        "evaluation_actual": [250.0, 254.0, 259.0],
        "predicted_value": [248.0, 255.5, 260.0],
    })

    demo_future_forecast = pd.DataFrame({
        "month": pd.date_range(start="2026-01-01", periods=3, freq="MS"),
        "forecast_value": [263.0, 267.5, 272.0],
    })

    demo_bundle = {
        "selected_scope": "company",
        "selected_metric": "revenue",
        "selected_model": "linear_regression_lag3",
        "history": demo_history,
        "test_predictions": demo_test_predictions,
        "future_forecast": demo_future_forecast,
        "displayed_error_metrics": {
            "mae": 2.1667,
            "rmse": 2.1985,
        },
    }

    app = QApplication(sys.argv)

    widget = ForecastDashboard(demo_bundle)
    widget.resize(1450, 900)
    widget.scope_changed.connect(print)
    widget.metric_changed.connect(print)
    widget.model_changed.connect(print)
    widget.show()

    sys.exit(app.exec())
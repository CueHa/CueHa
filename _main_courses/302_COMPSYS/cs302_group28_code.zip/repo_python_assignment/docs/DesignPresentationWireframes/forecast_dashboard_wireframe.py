import sys
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QFont, QColor, QPainter, QPen, QBrush
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )
        self.setFixedHeight(28)

    def set_badge_style(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class MetricCard(QFrame):
    def __init__(self, title: str, value: str, subtitle: str):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)

        title_label = QLabel(title)
        title_label.setWordWrap(True)
        title_label.setStyleSheet(
            "font-size: 12px; font-weight: 800; color: #111827;")
        value_label = QLabel(value)
        value_label.setStyleSheet(
            "font-size: 22px; font-weight: 800; color: #111827;")
        subtitle_label = QLabel(subtitle)
        subtitle_label.setWordWrap(True)
        subtitle_label.setStyleSheet("font-size: 11px; color: #6b7280;")

        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(subtitle_label)
        layout.addStretch()


class ForecastModelCard(QFrame):
    def __init__(self, model_name: str, error_label: str, error_value: str, selected: bool = False):
        super().__init__()
        border_color = "#2563eb" if selected else "#d9dee7"
        bg_color = "#eff6ff" if selected else "#ffffff"

        self.setStyleSheet(
            f"""
            QFrame {{
                background-color: {bg_color};
                border: 1px solid {border_color};
                border-radius: 12px;
            }}
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)

        title_row = QHBoxLayout()
        title_row.setSpacing(8)

        title = QLabel(model_name)
        title.setStyleSheet(
            "font-size: 13px; font-weight: 800; color: #111827;")

        if selected:
            badge = StatusBadge("Selected", "#dbeafe", "#1d4ed8")
            badge.setFixedWidth(86)
            title_row.addWidget(title)
            title_row.addWidget(badge)
            title_row.addStretch()
        else:
            title_row.addWidget(title)
            title_row.addStretch()

        metric_label = QLabel(error_label)
        metric_label.setStyleSheet("font-size: 11px; color: #6b7280;")

        metric_value = QLabel(error_value)
        metric_value.setStyleSheet(
            "font-size: 20px; font-weight: 800; color: #111827;")

        footer = QLabel(
            "Used for forecast comparison and error-based model selection")
        footer.setWordWrap(True)
        footer.setStyleSheet("font-size: 11px; color: #6b7280;")

        layout.addLayout(title_row)
        layout.addWidget(metric_label)
        layout.addWidget(metric_value)
        layout.addWidget(footer)
        layout.addStretch()


class ForecastChartPlaceholder(QFrame):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(420)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

    def paintEvent(self, event):
        super().paintEvent(event)

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = self.rect()
        margin_left = 58
        margin_right = 28
        margin_top = 58
        margin_bottom = 56

        chart_left = margin_left
        chart_top = margin_top
        chart_width = rect.width() - margin_left - margin_right
        chart_height = rect.height() - margin_top - margin_bottom

        painter.setPen(QColor("#111827"))
        title_font = QFont("Segoe UI", 11)
        title_font.setBold(True)
        painter.setFont(title_font)
        painter.drawText(
            18, 28, "Forecast Output, Historical Data + 3-Month Forecast")

        subtitle_font = QFont("Segoe UI", 9)
        painter.setFont(subtitle_font)
        painter.setPen(QColor("#6b7280"))
        painter.drawText(
            18, 44, "Selected metric: Revenue, scope: Company Wide, models: Moving Average and Linear Trend")

        plot_rect = QRectF(chart_left, chart_top, chart_width, chart_height)
        painter.setBrush(QBrush(QColor("#f8fafc")))
        painter.setPen(QPen(QColor("#e5e7eb"), 1))
        painter.drawRoundedRect(plot_rect, 8, 8)

        painter.setPen(QPen(QColor("#e5e7eb"), 1))
        for i in range(5):
            y = chart_top + i * (chart_height / 4)
            painter.drawLine(chart_left, int(
                y), chart_left + chart_width, int(y))

        for i in range(7):
            x = chart_left + i * (chart_width / 6)
            painter.drawLine(int(x), chart_top, int(x),
                             chart_top + chart_height)

        painter.setPen(QColor("#6b7280"))
        painter.setFont(QFont("Segoe UI", 8))
        y_labels = ["$0", "$50k", "$100k", "$150k", "$200k"]
        for i, label in enumerate(reversed(y_labels)):
            y = chart_top + i * (chart_height / 4)
            painter.drawText(12, int(y) + 4, label)

        x_positions = [
            ("M1", 0.00),
            ("M8", 0.18),
            ("M15", 0.36),
            ("M22", 0.54),
            ("M29", 0.72),
            ("M36", 0.89),
            ("F+1", 0.94),
            ("F+3", 1.00),
        ]
        for label, fraction in x_positions:
            x = chart_left + fraction * chart_width
            text_x = int(x) - 10
            if label == "F+3":
                text_x -= 10
            painter.drawText(text_x, chart_top + chart_height + 22, label)

        history_values = [
            0.16, 0.18, 0.20, 0.19, 0.21, 0.23, 0.22, 0.24, 0.26,
            0.25, 0.27, 0.29, 0.31, 0.30, 0.33, 0.35, 0.34, 0.36,
            0.38, 0.37, 0.40, 0.43, 0.44, 0.46, 0.45, 0.49, 0.51,
            0.54, 0.53, 0.57, 0.60, 0.63, 0.62, 0.66, 0.69, 0.72
        ]
        model_a_forecast = [0.74, 0.76, 0.79]
        model_b_forecast = [0.75, 0.78, 0.82]

        history_points = self.build_points(plot_rect, history_values, 39)
        model_a_points = self.build_forecast_points(
            plot_rect, history_values[-1], model_a_forecast, 39)
        model_b_points = self.build_forecast_points(
            plot_rect, history_values[-1], model_b_forecast, 39)

        split_fraction = 35 / 38
        split_x = plot_rect.left() + split_fraction * plot_rect.width()
        painter.setPen(QPen(QColor("#94a3b8"), 1.5, Qt.PenStyle.DashLine))
        painter.drawLine(int(split_x), chart_top, int(
            split_x), chart_top + chart_height)

        painter.setPen(QColor("#475569"))
        painter.setFont(QFont("Segoe UI", 8))
        painter.drawText(int(split_x) - 48, chart_top - 8, "Forecast boundary")

        self.draw_series(painter, history_points,
                         QColor("#334155"), 2.8, point_step=4)
        self.draw_series(painter, model_a_points, QColor(
            "#2563eb"), 2.6, dashed=True, point_step=1)
        self.draw_series(painter, model_b_points, QColor(
            "#0f766e"), 2.6, dashed=True, point_step=1)

        self.draw_confidence_band(painter, model_b_points, QColor("#d1fae5"))

        legend_y = 18
        legend_x = rect.width() - 350
        self.draw_legend_item(painter, legend_x, legend_y,
                              QColor("#334155"), "Historical")
        self.draw_legend_item(painter, legend_x + 92,
                              legend_y, QColor("#2563eb"), "Model A")
        self.draw_legend_item(painter, legend_x + 176,
                              legend_y, QColor("#0f766e"), "Model B")
        self.draw_legend_item(painter, legend_x + 260,
                              legend_y, QColor("#10b981"), "Range")

    def build_points(self, plot_rect: QRectF, values: list[float], total_slots: int) -> list[QPointF]:
        points = []
        count = len(values)
        for i, val in enumerate(values):
            x = plot_rect.left() + (i / (total_slots - 1)) * plot_rect.width()
            y = plot_rect.bottom() - (val * plot_rect.height())
            points.append(QPointF(x, y))
        return points

    def build_forecast_points(
        self,
        plot_rect: QRectF,
        last_history_value: float,
        forecast_values: list[float],
        total_slots: int,
    ) -> list[QPointF]:
        points = []
        start_index = 35
        combined = [last_history_value] + forecast_values
        for offset, val in enumerate(combined):
            slot_index = start_index + offset
            x = plot_rect.left() + (slot_index / (total_slots - 1)) * plot_rect.width()
            y = plot_rect.bottom() - (val * plot_rect.height())
            points.append(QPointF(x, y))
        return points

    def draw_series(
        self,
        painter: QPainter,
        points: list[QPointF],
        color: QColor,
        width: float,
        dashed: bool = False,
        point_step: int = 4,
    ):
        pen_style = Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine
        painter.setPen(QPen(color, width, pen_style))

        for i in range(len(points) - 1):
            painter.drawLine(points[i], points[i + 1])

        painter.setBrush(QBrush(color))
        painter.setPen(QPen(color, 1))
        for point in points[::point_step]:
            painter.drawEllipse(point, 3, 3)

    def draw_confidence_band(self, painter: QPainter, forecast_points: list[QPointF], color: QColor):
        if len(forecast_points) < 2:
            return

        painter.setBrush(QBrush(color))
        painter.setPen(QPen(QColor("#a7f3d0"), 1))

        upper = []
        lower = []
        offsets = [-14, -18, -22, -26]
        offsets_lower = [14, 18, 22, 26]

        for point, off in zip(forecast_points, offsets):
            upper.append(QPointF(point.x(), point.y() + off))
        for point, off in zip(reversed(forecast_points), reversed(offsets_lower)):
            lower.append(QPointF(point.x(), point.y() + off))

        polygon_points = upper + lower
        painter.drawPolygon(*polygon_points)

    def draw_legend_item(self, painter: QPainter, x: int, y: int, color: QColor, label: str):
        painter.setBrush(QBrush(color))
        painter.setPen(QPen(color, 1))
        painter.drawRoundedRect(x, y, 16, 8, 3, 3)

        painter.setPen(QColor("#374151"))
        painter.setFont(QFont("Segoe UI", 8))
        painter.drawText(x + 22, y + 9, label)


class ForecastDashboardWireframeWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("RoastWorks Sales Analytics Dashboard")
        self.resize(1450, 900)
        self.setMinimumSize(1260, 780)

        self.setStyleSheet(
            """
            QMainWindow {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 12px;
                color: #111827;
                min-height: 20px;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
            }
            QCheckBox {
                font-size: 12px;
                color: #111827;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
            }
            QCheckBox::indicator:unchecked {
                border: 1px solid #94a3b8;
                background: white;
                border-radius: 4px;
            }
            QCheckBox::indicator:checked {
                border: 1px solid #2563eb;
                background: #2563eb;
                border-radius: 4px;
            }
            """
        )

        self.central = QWidget()
        self.setCentralWidget(self.central)

        self.root_layout = QHBoxLayout(self.central)
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.root_layout.setSpacing(0)

        self.build_sidebar()
        self.build_main_area()

    def build_sidebar(self):
        sidebar = QFrame()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet(
            """
            QFrame {
                background-color: #111827;
                border: none;
            }
            """
        )

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 20, 18, 20)
        layout.setSpacing(14)

        app_title = QLabel("RoastWorks\nAnalytics")
        app_title.setStyleSheet(
            """
            font-size: 22px;
            font-weight: 800;
            color: white;
            line-height: 1.2;
            """
        )
        layout.addWidget(app_title)

        subtitle = QLabel("Methodology & Design\nGUI Wireframe")
        subtitle.setStyleSheet("font-size: 12px; color: #cbd5e1;")
        layout.addWidget(subtitle)

        layout.addSpacing(22)

        self.nav_import = self.make_nav_button("Import")
        self.nav_company = self.make_nav_button("Company Dashboard")
        self.nav_units = self.make_nav_button("Business Units")
        self.nav_forecast = self.make_nav_button("Forecasting", active=True)

        layout.addWidget(self.nav_import)
        layout.addWidget(self.nav_company)
        layout.addWidget(self.nav_units)
        layout.addWidget(self.nav_forecast)

        layout.addStretch()

        footer = QLabel("PyQt6 Desktop Mockup\nNon-functional analytics UI")
        footer.setStyleSheet("font-size: 11px; color: #94a3b8;")
        layout.addWidget(footer)

        self.root_layout.addWidget(sidebar)

    def make_nav_button(self, text: str, active: bool = False) -> QPushButton:
        button = QPushButton(text)
        button.setFixedHeight(42)
        button.setCursor(Qt.CursorShape.PointingHandCursor)

        if active:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    text-align: left;
                    padding-left: 14px;
                    font-size: 13px;
                    font-weight: 700;
                }
                """
            )
        else:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #1f2937;
                    color: #d1d5db;
                    border: 1px solid #374151;
                    border-radius: 8px;
                    text-align: left;
                    padding-left: 14px;
                    font-size: 13px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #273449;
                }
                """
            )

        return button

    def build_main_area(self):
        main_container = QWidget()
        main_layout = QVBoxLayout(main_container)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(18)

        header_card = QFrame()
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )
        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 16, 18, 16)
        header_layout.setSpacing(16)

        title_block = QVBoxLayout()
        title = QLabel("Forecasting Dashboard")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;")
        subtitle = QLabel(
            "Compare forecasting models, show forecast error metrics, and project at least 3 months ahead for company-wide or business-unit views."
        )
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")
        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        top_badges = QVBoxLayout()
        badges_row = QHBoxLayout()
        badges_row.setSpacing(8)

        self.loaded_badge = StatusBadge(
            "Loaded: 36 months / 3 CSVs", "#dcfce7", "#166534")
        self.loaded_badge.setFixedWidth(180)

        self.scope_badge = StatusBadge("Forecast View", "#dbeafe", "#1d4ed8")
        self.scope_badge.setFixedWidth(110)

        self.metric_badge = StatusBadge(
            "Error metric visible", "#fef3c7", "#92400e")
        self.metric_badge.setFixedWidth(140)

        badges_row.addWidget(self.loaded_badge)
        badges_row.addWidget(self.scope_badge)
        badges_row.addWidget(self.metric_badge)
        badges_row.addStretch()

        action_row = QHBoxLayout()
        action_row.setSpacing(8)

        self.export_button = QPushButton("Export View")
        self.export_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.export_button.setFixedHeight(36)
        self.export_button.setStyleSheet(
            """
            QPushButton {
                background-color: #0f766e;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 12px;
                font-weight: 700;
                padding: 0 14px;
            }
            QPushButton:hover {
                background-color: #0d9488;
            }
            """
        )

        action_row.addStretch()
        action_row.addWidget(self.export_button)

        top_badges.addLayout(badges_row)
        top_badges.addLayout(action_row)

        header_layout.addLayout(top_badges)
        main_layout.addWidget(header_card)

        controls_card = self.make_info_card("Forecast Controls")
        controls_layout = controls_card.layout()

        controls_grid = QGridLayout()
        controls_grid.setHorizontalSpacing(14)
        controls_grid.setVerticalSpacing(12)

        scope_label = QLabel("Scope")
        scope_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;")
        self.scope_selector = QComboBox()
        self.scope_selector.addItems(
            ["Company Wide", "Commercial", "Domestic", "Cafe"])

        metric_label = QLabel("Metric")
        metric_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;")
        self.metric_selector = QComboBox()
        self.metric_selector.addItems(["Revenue", "Cost", "Gross Margin"])

        horizon_label = QLabel("Forecast Horizon")
        horizon_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;")
        self.horizon_selector = QComboBox()
        self.horizon_selector.addItems(["3 Months", "6 Months"])

        model_label = QLabel("Forecast Models")
        model_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;")

        model_widget = QWidget()
        model_row = QHBoxLayout(model_widget)
        model_row.setContentsMargins(0, 0, 0, 0)
        model_row.setSpacing(16)

        self.model_a_checkbox = QCheckBox("Moving Average")
        self.model_a_checkbox.setChecked(True)
        self.model_b_checkbox = QCheckBox("Linear Trend")
        self.model_b_checkbox.setChecked(True)

        model_row.addWidget(self.model_a_checkbox)
        model_row.addWidget(self.model_b_checkbox)
        model_row.addStretch()

        controls_grid.addWidget(scope_label, 0, 0)
        controls_grid.addWidget(self.scope_selector, 0, 1)
        controls_grid.addWidget(metric_label, 0, 2)
        controls_grid.addWidget(self.metric_selector, 0, 3)
        controls_grid.addWidget(horizon_label, 1, 0)
        controls_grid.addWidget(self.horizon_selector, 1, 1)
        controls_grid.addWidget(model_label, 1, 2)
        controls_grid.addWidget(model_widget, 1, 3)

        controls_grid.setColumnStretch(0, 1)
        controls_grid.setColumnStretch(1, 2)
        controls_grid.setColumnStretch(2, 1)
        controls_grid.setColumnStretch(3, 3)

        controls_layout.addLayout(controls_grid)
        main_layout.addWidget(controls_card)

        kpi_grid = QGridLayout()
        kpi_grid.setHorizontalSpacing(14)
        kpi_grid.setVerticalSpacing(14)

        kpi_grid.addWidget(MetricCard("Current Forecast Scope", "Company Wide",
                           "Applies to company-wide and business-unit forecasting"), 0, 0)
        kpi_grid.addWidget(MetricCard("Selected Metric", "Revenue",
                           "Metric selector can switch to cost or gross margin"), 0, 1)
        kpi_grid.addWidget(MetricCard("Forecast Horizon", "3 Months",
                           "Minimum required forecast horizon is explicitly visible"), 0, 2)

        main_layout.addLayout(kpi_grid)

        bottom_grid = QGridLayout()
        bottom_grid.setHorizontalSpacing(18)
        bottom_grid.setVerticalSpacing(18)

        chart_card = ForecastChartPlaceholder()
        bottom_grid.addWidget(chart_card, 0, 0, 2, 1)

        model_a_card = ForecastModelCard(
            "Model A, Moving Average", "RMSE", "4.82", selected=False)
        model_b_card = ForecastModelCard(
            "Model B, Linear Trend", "RMSE", "3.91", selected=True)

        bottom_grid.addWidget(model_a_card, 0, 1)
        bottom_grid.addWidget(model_b_card, 0, 2)

        comparison_card = self.make_info_card("Model Comparison")
        comparison_layout = comparison_card.layout()

        comparison_header = QLabel(
            "Displayed error metric supports model selection")
        comparison_header.setWordWrap(True)
        comparison_header.setStyleSheet(
            "font-size: 12px; color: #374151; font-weight: 700;")
        comparison_layout.addWidget(comparison_header)

        comparison_table = self.make_comparison_table()
        comparison_layout.addWidget(comparison_table)

        helper_text = QLabel(
            "The forecast chart includes historical data, forecast extension, and visually distinct lines for each selected model."
        )
        helper_text.setWordWrap(True)
        helper_text.setStyleSheet("font-size: 11px; color: #6b7280;")
        comparison_layout.addWidget(helper_text)

        bottom_grid.addWidget(comparison_card, 1, 1, 1, 2)

        bottom_grid.setColumnStretch(0, 7)
        bottom_grid.setColumnStretch(1, 3)
        bottom_grid.setColumnStretch(2, 3)

        main_layout.addLayout(bottom_grid)

        self.root_layout.addWidget(main_container)

    def make_comparison_table(self) -> QWidget:
        container = QWidget()
        layout = QGridLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)

        headers = ["Model", "RMSE", "MAPE", "Status"]
        rows = [
            ["Moving Average", "4.82", "6.4%", "Available"],
            ["Linear Trend", "3.91", "5.1%", "Selected"],
        ]

        for col, header in enumerate(headers):
            label = QLabel(header)
            label.setStyleSheet(
                "font-size: 11px; font-weight: 800; color: #111827;")
            layout.addWidget(label, 0, col)

        for row_index, row_values in enumerate(rows, start=1):
            for col, value in enumerate(row_values):
                cell = QLabel(value)
                if col == 3 and value == "Selected":
                    cell.setStyleSheet(
                        "font-size: 11px; color: #1d4ed8; font-weight: 700; background-color: #dbeafe; border: 1px solid #bfdbfe; border-radius: 8px; padding: 4px 8px;"
                    )
                    cell.setAlignment(Qt.AlignmentFlag.AlignCenter)
                elif col == 3:
                    cell.setStyleSheet(
                        "font-size: 11px; color: #374151; background-color: #f3f4f6; border: 1px solid #e5e7eb; border-radius: 8px; padding: 4px 8px;"
                    )
                    cell.setAlignment(Qt.AlignmentFlag.AlignCenter)
                else:
                    cell.setStyleSheet("font-size: 11px; color: #374151;")
                layout.addWidget(cell, row_index, col)

        return container

    def make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;")
        layout.addWidget(title)

        return card


def main():
    app = QApplication(sys.argv)

    font = QFont("Segoe UI", 10)
    app.setFont(font)

    window = ForecastDashboardWireframeWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()

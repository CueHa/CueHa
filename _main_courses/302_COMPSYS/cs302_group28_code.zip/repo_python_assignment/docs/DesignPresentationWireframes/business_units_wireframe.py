import sys
from PyQt6.QtCore import Qt, QRectF, QPointF
from PyQt6.QtGui import QFont, QColor, QPainter, QPen, QBrush
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )
        self.setFixedHeight(28)

    def set_badge_style(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class BusinessUnitKPICard(QFrame):
    def __init__(self, unit_name: str, last_month: str, this_month: str, change: str, change_positive: bool = True):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title_label = QLabel(f"{unit_name} Gross Profit")
        title_label.setWordWrap(True)
        title_label.setStyleSheet(
            "font-size: 12px; font-weight: 800; color: #111827;")
        layout.addWidget(title_label)

        values_row = QHBoxLayout()
        values_row.setSpacing(10)

        last_block = self.make_metric_block("Last Month", last_month)
        this_block = self.make_metric_block("This Month", this_month)

        values_row.addWidget(last_block)
        values_row.addWidget(this_block)
        layout.addLayout(values_row)

        change_row = QHBoxLayout()
        change_row.setSpacing(8)

        change_label = QLabel("Change")
        change_label.setStyleSheet("font-size: 11px; color: #6b7280;")
        change_row.addWidget(change_label)

        badge_bg = "#dcfce7" if change_positive else "#fee2e2"
        badge_fg = "#166534" if change_positive else "#991b1b"
        change_badge = StatusBadge(change, badge_bg, badge_fg)
        change_badge.setFixedWidth(110)
        change_row.addWidget(change_badge)
        change_row.addStretch()

        layout.addLayout(change_row)

    def make_metric_block(self, label: str, value: str) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        label_widget = QLabel(label)
        label_widget.setStyleSheet("font-size: 11px; color: #6b7280;")
        value_widget = QLabel(value)
        value_widget.setStyleSheet(
            "font-size: 16px; font-weight: 800; color: #111827;")

        layout.addWidget(label_widget)
        layout.addWidget(value_widget)
        return widget


class MiniLegendRow(QWidget):
    def __init__(self):
        super().__init__()
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(12)

        row.addWidget(self.make_item("#2563eb", "Revenue"))
        row.addWidget(self.make_item("#ef4444", "Cost"))
        row.addWidget(self.make_item("#0f766e", "Gross Profit"))
        row.addStretch()

    def make_item(self, color: str, text: str) -> QWidget:
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        swatch = QLabel()
        swatch.setFixedSize(12, 12)
        swatch.setStyleSheet(
            f"""
            QLabel {{
                background-color: {color};
                border-radius: 3px;
                border: 1px solid #d1d5db;
            }}
            """
        )

        label = QLabel(text)
        label.setStyleSheet(
            "font-size: 11px; color: #374151; font-weight: 600;")

        layout.addWidget(swatch)
        layout.addWidget(label)
        return widget


class BusinessUnitChartCard(QFrame):
    def __init__(self, title: str, revenue_points: list[float], cost_points: list[float], profit_points: list[float]):
        super().__init__()
        self.title = title
        self.revenue_points = revenue_points
        self.cost_points = cost_points
        self.profit_points = profit_points

        self.setMinimumHeight(255)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

    def paintEvent(self, event):
        super().paintEvent(event)

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = self.rect()
        margin_left = 44
        margin_right = 18
        margin_top = 48
        margin_bottom = 40

        chart_left = margin_left
        chart_top = margin_top
        chart_width = rect.width() - margin_left - margin_right
        chart_height = rect.height() - margin_top - margin_bottom

        painter.setPen(QColor("#111827"))
        title_font = QFont("Segoe UI", 10)
        title_font.setBold(True)
        painter.setFont(title_font)
        painter.drawText(16, 26, self.title)

        subtitle_font = QFont("Segoe UI", 8)
        painter.setFont(subtitle_font)
        painter.setPen(QColor("#6b7280"))
        painter.drawText(
            16, 40, "Revenue, cost, and gross profit across 36 months")

        plot_rect = QRectF(chart_left, chart_top, chart_width, chart_height)
        painter.setBrush(QBrush(QColor("#f8fafc")))
        painter.setPen(QPen(QColor("#e5e7eb"), 1))
        painter.drawRoundedRect(plot_rect, 8, 8)

        painter.setPen(QPen(QColor("#e5e7eb"), 1))
        for i in range(5):
            y = chart_top + i * (chart_height / 4)
            painter.drawLine(chart_left, int(
                y), chart_left + chart_width, int(y))

        for i in range(6):
            x = chart_left + i * (chart_width / 5)
            painter.drawLine(int(x), chart_top, int(x),
                             chart_top + chart_height)

        painter.setPen(QColor("#6b7280"))
        painter.setFont(QFont("Segoe UI", 7))
        x_labels = ["M1", "M8", "M15", "M22", "M29", "M36"]
        for i, label in enumerate(x_labels):
            x = chart_left + i * (chart_width / 5)
            painter.drawText(int(x) - 8, chart_top + chart_height + 18, label)

        self.draw_series(painter, plot_rect,
                         self.revenue_points, QColor("#2563eb"), 2.2)
        self.draw_series(painter, plot_rect, self.cost_points,
                         QColor("#ef4444"), 2.2)
        self.draw_series(painter, plot_rect,
                         self.profit_points, QColor("#0f766e"), 2.2)

        legend_y = 16
        legend_x = rect.width() - 198
        self.draw_legend_item(painter, legend_x, legend_y,
                              QColor("#2563eb"), "Revenue")
        self.draw_legend_item(painter, legend_x + 62,
                              legend_y, QColor("#ef4444"), "Cost")
        self.draw_legend_item(painter, legend_x + 108,
                              legend_y, QColor("#0f766e"), "Profit")

    def draw_series(self, painter: QPainter, plot_rect: QRectF, values: list[float], color: QColor, width: float):
        painter.setPen(QPen(color, width))
        points = []
        count = len(values)

        for i, val in enumerate(values):
            x = plot_rect.left() + (i / (count - 1)) * plot_rect.width()
            y = plot_rect.bottom() - (val * plot_rect.height())
            points.append(QPointF(x, y))

        for i in range(len(points) - 1):
            painter.drawLine(points[i], points[i + 1])

        painter.setBrush(QBrush(color))
        for point in points[::6]:
            painter.drawEllipse(point, 2.5, 2.5)

    def draw_legend_item(self, painter: QPainter, x: int, y: int, color: QColor, label: str):
        painter.setBrush(QBrush(color))
        painter.setPen(QPen(color, 1))
        painter.drawRoundedRect(x, y, 12, 6, 2, 2)

        painter.setPen(QColor("#374151"))
        painter.setFont(QFont("Segoe UI", 7))
        painter.drawText(x + 16, y + 7, label)


class BusinessUnitDashboardWireframeWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("RoastWorks Sales Analytics Dashboard")
        self.resize(1420, 860)
        self.setMinimumSize(1240, 760)

        self.setStyleSheet(
            """
            QMainWindow {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 12px;
                color: #111827;
                min-height: 20px;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
            }
            """
        )

        self.central = QWidget()
        self.setCentralWidget(self.central)

        self.root_layout = QHBoxLayout(self.central)
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.root_layout.setSpacing(0)

        self.build_sidebar()
        self.build_main_area()

    def build_sidebar(self):
        sidebar = QFrame()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet(
            """
            QFrame {
                background-color: #111827;
                border: none;
            }
            """
        )

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 20, 18, 20)
        layout.setSpacing(14)

        app_title = QLabel("RoastWorks\nAnalytics")
        app_title.setStyleSheet(
            """
            font-size: 22px;
            font-weight: 800;
            color: white;
            line-height: 1.2;
            """
        )
        layout.addWidget(app_title)

        subtitle = QLabel("Methodology & Design\nGUI Wireframe")
        subtitle.setStyleSheet("font-size: 12px; color: #cbd5e1;")
        layout.addWidget(subtitle)

        layout.addSpacing(22)

        self.nav_import = self.make_nav_button("Import")
        self.nav_company = self.make_nav_button("Company Dashboard")
        self.nav_units = self.make_nav_button("Business Units", active=True)
        self.nav_forecast = self.make_nav_button("Forecasting")

        layout.addWidget(self.nav_import)
        layout.addWidget(self.nav_company)
        layout.addWidget(self.nav_units)
        layout.addWidget(self.nav_forecast)

        layout.addStretch()

        footer = QLabel("PyQt6 Desktop Mockup\nNon-functional analytics UI")
        footer.setStyleSheet("font-size: 11px; color: #94a3b8;")
        layout.addWidget(footer)

        self.root_layout.addWidget(sidebar)

    def make_nav_button(self, text: str, active: bool = False) -> QPushButton:
        button = QPushButton(text)
        button.setFixedHeight(42)
        button.setCursor(Qt.CursorShape.PointingHandCursor)

        if active:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    text-align: left;
                    padding-left: 14px;
                    font-size: 13px;
                    font-weight: 700;
                }
                """
            )
        else:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #1f2937;
                    color: #d1d5db;
                    border: 1px solid #374151;
                    border-radius: 8px;
                    text-align: left;
                    padding-left: 14px;
                    font-size: 13px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #273449;
                }
                """
            )

        return button

    def build_main_area(self):
        main_container = QWidget()
        main_layout = QVBoxLayout(main_container)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(18)

        header_card = QFrame()
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )
        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 16, 18, 16)
        header_layout.setSpacing(16)

        title_block = QVBoxLayout()
        title = QLabel("Business Unit Performance Dashboard")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;")
        subtitle = QLabel(
            "Compare Commercial, Domestic, and Cafe performance across the selected month while keeping all three units visible."
        )
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")
        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        filter_block = QVBoxLayout()
        filter_block.setSpacing(8)

        filter_top = QHBoxLayout()
        filter_top.setSpacing(8)

        self.loaded_badge = StatusBadge(
            "Loaded: 36 months / 3 CSVs", "#dcfce7", "#166534")
        self.loaded_badge.setFixedWidth(180)
        filter_top.addWidget(self.loaded_badge)

        self.scope_badge = StatusBadge("Business Units", "#dbeafe", "#1d4ed8")
        self.scope_badge.setFixedWidth(120)
        filter_top.addWidget(self.scope_badge)

        self.month_context_badge = StatusBadge(
            "KPI cards use selected month", "#fef3c7", "#92400e")
        self.month_context_badge.setFixedWidth(180)
        filter_top.addWidget(self.month_context_badge)

        filter_top.addStretch()

        month_row = QHBoxLayout()
        month_row.setSpacing(8)

        month_label = QLabel("Month")
        month_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;")

        self.month_selector = QComboBox()
        self.month_selector.addItems([
            "December 2025",
            "November 2025",
            "October 2025",
            "September 2025",
            "August 2025",
            "July 2025",
        ])
        self.month_selector.setFixedWidth(180)

        self.export_button = QPushButton("Export View")
        self.export_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.export_button.setFixedHeight(36)
        self.export_button.setStyleSheet(
            """
            QPushButton {
                background-color: #0f766e;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 12px;
                font-weight: 700;
                padding: 0 14px;
            }
            QPushButton:hover {
                background-color: #0d9488;
            }
            """
        )

        month_row.addWidget(month_label)
        month_row.addWidget(self.month_selector)
        month_row.addWidget(self.export_button)

        filter_block.addLayout(filter_top)
        filter_block.addLayout(month_row)
        header_layout.addLayout(filter_block)

        main_layout.addWidget(header_card)

        kpi_grid = QGridLayout()
        kpi_grid.setHorizontalSpacing(14)
        kpi_grid.setVerticalSpacing(14)

        commercial_card = BusinessUnitKPICard(
            "Commercial", "$26,400", "$29,150", "+10.4%", True)
        domestic_card = BusinessUnitKPICard(
            "Domestic", "$18,750", "$20,300", "+8.3%", True)
        cafe_card = BusinessUnitKPICard(
            "Cafe", "$13,750", "$16,890", "+22.8%", True)

        kpi_grid.addWidget(commercial_card, 0, 0)
        kpi_grid.addWidget(domestic_card, 0, 1)
        kpi_grid.addWidget(cafe_card, 0, 2)

        main_layout.addLayout(kpi_grid)

        chart_grid = QGridLayout()
        chart_grid.setHorizontalSpacing(16)
        chart_grid.setVerticalSpacing(16)

        commercial_revenue = [
            0.20, 0.22, 0.24, 0.23, 0.25, 0.28, 0.27, 0.29, 0.31,
            0.30, 0.32, 0.34, 0.36, 0.37, 0.38, 0.40, 0.39, 0.42,
            0.44, 0.43, 0.45, 0.47, 0.49, 0.50, 0.52, 0.54, 0.55,
            0.57, 0.58, 0.60, 0.62, 0.63, 0.65, 0.66, 0.68, 0.70
        ]
        commercial_cost = [
            0.13, 0.14, 0.15, 0.15, 0.16, 0.18, 0.17, 0.18, 0.20,
            0.19, 0.20, 0.21, 0.22, 0.23, 0.23, 0.24, 0.24, 0.25,
            0.26, 0.26, 0.27, 0.28, 0.29, 0.30, 0.31, 0.32, 0.33,
            0.34, 0.34, 0.35, 0.36, 0.37, 0.38, 0.38, 0.39, 0.40
        ]
        commercial_profit = [
            0.07, 0.08, 0.09, 0.08, 0.09, 0.10, 0.10, 0.11, 0.11,
            0.11, 0.12, 0.13, 0.14, 0.14, 0.15, 0.16, 0.15, 0.17,
            0.18, 0.17, 0.18, 0.19, 0.20, 0.20, 0.21, 0.22, 0.22,
            0.23, 0.24, 0.25, 0.26, 0.26, 0.27, 0.28, 0.29, 0.30
        ]

        domestic_revenue = [
            0.16, 0.17, 0.18, 0.19, 0.18, 0.20, 0.19, 0.21, 0.22,
            0.23, 0.22, 0.24, 0.25, 0.26, 0.25, 0.27, 0.28, 0.29,
            0.30, 0.29, 0.31, 0.32, 0.33, 0.34, 0.33, 0.35, 0.36,
            0.37, 0.38, 0.39, 0.40, 0.41, 0.42, 0.43, 0.44, 0.45
        ]
        domestic_cost = [
            0.10, 0.11, 0.11, 0.12, 0.12, 0.13, 0.13, 0.14, 0.15,
            0.15, 0.15, 0.16, 0.17, 0.17, 0.17, 0.18, 0.18, 0.19,
            0.20, 0.20, 0.20, 0.21, 0.21, 0.22, 0.22, 0.23, 0.23,
            0.24, 0.24, 0.25, 0.25, 0.26, 0.26, 0.27, 0.27, 0.28
        ]
        domestic_profit = [
            0.06, 0.06, 0.07, 0.07, 0.06, 0.07, 0.06, 0.07, 0.07,
            0.08, 0.07, 0.08, 0.08, 0.09, 0.08, 0.09, 0.10, 0.10,
            0.10, 0.09, 0.11, 0.11, 0.12, 0.12, 0.11, 0.12, 0.13,
            0.13, 0.14, 0.14, 0.15, 0.15, 0.16, 0.16, 0.17, 0.17
        ]

        cafe_revenue = [
            0.11, 0.12, 0.12, 0.13, 0.14, 0.13, 0.15, 0.16, 0.17,
            0.16, 0.18, 0.19, 0.18, 0.20, 0.21, 0.22, 0.21, 0.23,
            0.24, 0.25, 0.24, 0.26, 0.27, 0.28, 0.27, 0.29, 0.30,
            0.31, 0.30, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.39
        ]
        cafe_cost = [
            0.07, 0.07, 0.08, 0.08, 0.09, 0.08, 0.09, 0.10, 0.10,
            0.10, 0.11, 0.12, 0.11, 0.12, 0.13, 0.13, 0.13, 0.14,
            0.14, 0.15, 0.14, 0.15, 0.16, 0.16, 0.16, 0.17, 0.17,
            0.18, 0.18, 0.18, 0.19, 0.19, 0.20, 0.20, 0.21, 0.22
        ]
        cafe_profit = [
            0.04, 0.05, 0.04, 0.05, 0.05, 0.05, 0.06, 0.06, 0.07,
            0.06, 0.07, 0.07, 0.07, 0.08, 0.08, 0.09, 0.08, 0.09,
            0.10, 0.10, 0.10, 0.11, 0.11, 0.12, 0.11, 0.12, 0.13,
            0.13, 0.12, 0.14, 0.14, 0.15, 0.15, 0.16, 0.16, 0.17
        ]

        commercial_chart = BusinessUnitChartCard(
            "Commercial Performance Over Time",
            commercial_revenue,
            commercial_cost,
            commercial_profit,
        )
        domestic_chart = BusinessUnitChartCard(
            "Domestic Performance Over Time",
            domestic_revenue,
            domestic_cost,
            domestic_profit,
        )
        cafe_chart = BusinessUnitChartCard(
            "Cafe Performance Over Time",
            cafe_revenue,
            cafe_cost,
            cafe_profit,
        )

        chart_grid.addWidget(commercial_chart, 0, 0)
        chart_grid.addWidget(domestic_chart, 0, 1)
        chart_grid.addWidget(cafe_chart, 1, 0, 1, 2)

        chart_grid.setColumnStretch(0, 1)
        chart_grid.setColumnStretch(1, 1)

        main_layout.addLayout(chart_grid)

        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(14)

        legend_card = self.make_info_card("Shared Chart Legend")
        legend_layout = legend_card.layout()
        legend_layout.addWidget(MiniLegendRow())
        bottom_row.addWidget(legend_card, 2)

        note_card = self.make_info_card("Selected Month Context")
        note_layout = note_card.layout()
        note_text = QLabel(
            "The KPI cards at the top reflect the selected month.\n"
            "The charts below retain the full historical view for each business unit."
        )
        note_text.setWordWrap(True)
        note_text.setStyleSheet(
            "font-size: 12px; color: #374151; line-height: 1.5;")
        note_layout.addWidget(note_text)
        bottom_row.addWidget(note_card, 3)

        main_layout.addLayout(bottom_row)

        self.root_layout.addWidget(main_container)

    def make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;")
        layout.addWidget(title)

        return card


def main():
    app = QApplication(sys.argv)

    font = QFont("Segoe UI", 10)
    app.setFont(font)

    window = BusinessUnitDashboardWireframeWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()

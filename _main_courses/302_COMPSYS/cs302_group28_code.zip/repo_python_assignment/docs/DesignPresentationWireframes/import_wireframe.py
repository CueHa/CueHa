import importlib.util
import sys
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


LOCKED_FORECAST_MODELS = [
    "linear_regression_lag3",
    "exponential_smoothing",
    "naive",
]


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(28)
        self.set_badge_style(text, bg_color, text_color)

    def set_badge_style(self, text: str, bg_color: str, text_color: str = "#1f2937") -> None:
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class FileRow(QFrame):
    def __init__(self, label_text: str, placeholder_name: str):
        super().__init__()

        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 10px;
            }
            """
        )

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(14, 12, 14, 12)
        main_layout.setSpacing(10)

        title = QLabel(label_text)
        title.setStyleSheet(
            "font-size: 13px; font-weight: 700; color: #1f2937; border: none;"
        )
        main_layout.addWidget(title)

        row_layout = QHBoxLayout()
        row_layout.setSpacing(10)

        self.path_input = QLineEdit()
        self.path_input.setPlaceholderText(f"Select {placeholder_name}")
        self.path_input.setMinimumHeight(38)
        self.path_input.setStyleSheet(
            """
            QLineEdit {
                background-color: #f8fafc;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 0 10px;
                font-size: 12px;
                color: #111827;
            }
            """
        )

        self.browse_button = QPushButton("Browse")
        self.browse_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_button.setFixedHeight(38)
        self.browse_button.setFixedWidth(100)
        self.browse_button.setStyleSheet(
            """
            QPushButton {
                background-color: #2563eb;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 12px;
                font-weight: 700;
                padding: 0 14px;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
            """
        )

        self.status_badge = StatusBadge("Missing", "#fee2e2", "#991b1b")
        self.status_badge.setFixedWidth(110)

        row_layout.addWidget(self.path_input, 1)
        row_layout.addWidget(self.browse_button)
        row_layout.addWidget(self.status_badge)

        main_layout.addLayout(row_layout)

    def set_path(self, path: str) -> None:
        self.path_input.setText(path)
        self.update_status()

    def get_path(self) -> str:
        return self.path_input.text().strip()

    def update_status(self) -> None:
        path = self.get_path()

        if not path:
            self.status_badge.set_badge_style("Missing", "#fee2e2", "#991b1b")
        elif path.lower().endswith(".csv"):
            self.status_badge.set_badge_style(
                "CSV Ready", "#dcfce7", "#166534")
        else:
            self.status_badge.set_badge_style(
                "Invalid Type", "#fef3c7", "#92400e")


class FileSelectionScreen(QWidget):
    """
    Clean controller screen for selecting files and triggering the backend pipeline.

    This widget does not perform finance or forecasting logic directly.
    It only calls the backend node functions in sequence.

    Success path:
    Node 1 -> Node 2 -> Node 3 -> Node 4 -> Node 5 -> Node 6 -> Node 7
    then emits pipeline_ready(...) and optionally calls on_pipeline_ready(...)

    Node 9 integration:
    Because Node 9 is not defined here, this screen exposes a callback and a signal.
    The parent / app shell can connect either one.
    """

    pipeline_ready = pyqtSignal(dict)
    pipeline_failed = pyqtSignal(list)

    def __init__(
        self,
        on_pipeline_ready: Optional[Callable[[dict], None]] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)

        self.on_pipeline_ready = on_pipeline_ready

        self.setStyleSheet(
            """
            QWidget {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            """
        )

        self._build_ui()
        self._connect_buttons()

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(18)

        header_card = QFrame()
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )
        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 16, 18, 16)

        title_block = QVBoxLayout()
        title = QLabel("Import / File Selection")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;")

        subtitle = QLabel(
            "Select the three required CSV files, validate them, and trigger the backend pipeline."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")

        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        self.data_status_badge = StatusBadge(
            "0 / 3 files ready", "#e5e7eb", "#374151")
        self.data_status_badge.setFixedWidth(140)
        header_layout.addWidget(self.data_status_badge)

        main_layout.addWidget(header_card)

        body_layout = QGridLayout()
        body_layout.setHorizontalSpacing(18)
        body_layout.setVerticalSpacing(18)

        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(14)

        section_title = QLabel("Required Input Files")
        section_title.setStyleSheet(
            "font-size: 16px; font-weight: 800; color: #111827;")
        left_layout.addWidget(section_title)

        self.row_commercial = FileRow("Commercial CSV", "Data_Commercial.csv")
        self.row_domestic = FileRow("Domestic CSV", "Data_Domestic.csv")
        self.row_cafe = FileRow("Cafe CSV", "Data_Cafe.csv")

        left_layout.addWidget(self.row_commercial)
        left_layout.addWidget(self.row_domestic)
        left_layout.addWidget(self.row_cafe)

        self.load_button = QPushButton("Validate and Load")
        self.load_button.setFixedHeight(46)
        self.load_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.load_button.setStyleSheet(
            """
            QPushButton {
                background-color: #0f766e;
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 14px;
                font-weight: 800;
                padding: 0 16px;
            }
            QPushButton:hover {
                background-color: #0d9488;
            }
            QPushButton:disabled {
                background-color: #94a3b8;
            }
            """
        )
        left_layout.addWidget(self.load_button)

        helper_note = QLabel(
            "Expected files: Commercial, Domestic, and Cafe CSVs. The backend will validate structure and reject wrong slot assignment."
        )
        helper_note.setWordWrap(True)
        helper_note.setStyleSheet("font-size: 12px; color: #6b7280;")
        left_layout.addWidget(helper_note)

        body_layout.addWidget(left_panel, 0, 0)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(14)

        summary_card = self._make_info_card("Status / Error Display")
        summary_layout = summary_card.layout()

        self.status_text = QTextEdit()
        self.status_text.setReadOnly(True)
        self.status_text.setMinimumHeight(220)
        self.status_text.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.status_text.setStyleSheet(
            """
            QTextEdit {
                background-color: #f8fafc;
                border: 1px solid #d7deea;
                border-radius: 8px;
                font-size: 12px;
                color: #334155;
                padding: 8px;
            }
            """
        )
        self.status_text.setPlainText(
            "No files selected yet.\n\n"
            "Expected flow:\n"
            "1. Select Commercial CSV\n"
            "2. Select Domestic CSV\n"
            "3. Select Cafe CSV\n"
            "4. Validate and load\n"
            "5. Enter the main dashboard application if successful"
        )
        summary_layout.addWidget(self.status_text)
        right_layout.addWidget(summary_card)

        preview_card = self._make_info_card("Pipeline Overview")
        preview_layout = preview_card.layout()

        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setMinimumHeight(180)
        self.preview_text.setStyleSheet(
            """
            QTextEdit {
                background-color: #f8fafc;
                border: 1px solid #d7deea;
                border-radius: 8px;
                font-size: 12px;
                color: #334155;
                padding: 8px;
            }
            """
        )
        self.preview_text.setPlainText(
            "No dataset loaded.\n\n"
            "This area will show selected paths, row counts, available months, and readiness for dashboard entry."
        )
        preview_layout.addWidget(self.preview_text)
        right_layout.addWidget(preview_card)

        body_layout.addWidget(right_panel, 0, 1)

        body_layout.setColumnStretch(0, 7)
        body_layout.setColumnStretch(1, 5)

        main_layout.addLayout(body_layout)

    def _make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;")
        layout.addWidget(title)

        return card

    def _connect_buttons(self) -> None:
        self.row_commercial.browse_button.clicked.connect(
            lambda: self._select_file(
                self.row_commercial, "Select Commercial CSV")
        )
        self.row_domestic.browse_button.clicked.connect(
            lambda: self._select_file(self.row_domestic, "Select Domestic CSV")
        )
        self.row_cafe.browse_button.clicked.connect(
            lambda: self._select_file(self.row_cafe, "Select Cafe CSV")
        )

        self.load_button.clicked.connect(self._load_pipeline)

    def _select_file(self, file_row: FileRow, dialog_title: str) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            dialog_title,
            "",
            "CSV Files (*.csv);;All Files (*)",
        )

        if file_path:
            file_row.set_path(file_path)
            self._update_data_status()
            self._update_preview_paths_only()

    def _update_data_status(self) -> None:
        rows = [self.row_commercial, self.row_domestic, self.row_cafe]
        ready_count = 0

        for row in rows:
            row.update_status()
            if row.get_path().lower().endswith(".csv"):
                ready_count += 1

        if ready_count == 0:
            self.data_status_badge.set_badge_style(
                "0 / 3 files ready", "#e5e7eb", "#374151")
        elif ready_count < 3:
            self.data_status_badge.set_badge_style(
                f"{ready_count} / 3 files ready", "#fef3c7", "#92400e")
        else:
            self.data_status_badge.set_badge_style(
                "3 / 3 files ready", "#dcfce7", "#166534")

    def _update_preview_paths_only(self) -> None:
        preview = (
            "Selected files\n\n"
            f"Commercial: {self.row_commercial.get_path() or '[not selected]'}\n\n"
            f"Domestic: {self.row_domestic.get_path() or '[not selected]'}\n\n"
            f"Cafe: {self.row_cafe.get_path() or '[not selected]'}"
        )
        self.preview_text.setPlainText(preview)

    def _load_pipeline(self) -> None:
        self.load_button.setEnabled(False)
        self.status_text.setPlainText("Starting backend pipeline...\n")

        try:
            backend = self._load_backend_functions()

            commercial_path = self.row_commercial.get_path()
            domestic_path = self.row_domestic.get_path()
            cafe_path = self.row_cafe.get_path()

            self._append_status("Running Node 1: input validation...")
            validation_result = backend["validate_input_files"](
                commercial_path,
                domestic_path,
                cafe_path,
            )

            if not validation_result["ok"]:
                errors = validation_result["errors"]
                self._show_validation_errors(errors)
                self.pipeline_failed.emit(errors)
                return

            raw_data = validation_result["raw_data"]

            self._append_status(
                "Running Node 2: cleaning and standardising...")
            cleaned_data = backend["clean_and_standardise"](raw_data)

            self._append_status("Running Node 3: merge unified dataset...")
            unified_df = backend["merge_datasets"](cleaned_data)

            self._append_status(
                "Running Node 4: per-row financial calculations...")
            enriched_df = backend["calculate_row_financials"](unified_df)

            self._append_status("Running Node 5: monthly analytics engine...")
            analytics_store = backend["build_monthly_analytics"](enriched_df)

            self._append_status("Running Node 6: forecasting engine...")
            forecast_store = backend["build_forecast_store"](
                analytics_store,
                LOCKED_FORECAST_MODELS,
                horizon=3,
            )

            self._append_status("Building initial UI state...")
            ui_state = self._build_initial_ui_state(analytics_store)

            self._append_status(
                "Running Node 7: dashboard data preparation...")
            dashboard_store = backend["prepare_dashboard_data"](
                enriched_df,
                analytics_store,
                forecast_store,
                ui_state,
            )

            pipeline_package = {
                "raw_data": raw_data,
                "cleaned_data": cleaned_data,
                "unified_df": unified_df,
                "enriched_df": enriched_df,
                "analytics_store": analytics_store,
                "forecast_store": forecast_store,
                "ui_state": ui_state,
                "dashboard_store": dashboard_store,
            }

            self._append_status("Pipeline completed successfully.")
            self._append_status("Ready to enter main dashboard application.")

            self._show_success_preview(
                cleaned_data=cleaned_data,
                analytics_store=analytics_store,
                ui_state=ui_state,
            )

            if self.on_pipeline_ready is not None:
                self.on_pipeline_ready(pipeline_package)

            self.pipeline_ready.emit(pipeline_package)

        except Exception as exc:
            error_message = f"Pipeline failed.\n\n{type(exc).__name__}: {exc}"
            self.status_text.setPlainText(error_message)
            self.pipeline_failed.emit([str(exc)])

        finally:
            self.load_button.setEnabled(True)

    def _show_validation_errors(self, errors: list[str]) -> None:
        lines = ["Validation failed.\n"]
        for error in errors:
            lines.append(f"• {error}")
        self.status_text.setPlainText("\n".join(lines))

        preview = (
            "Selected files\n\n"
            f"Commercial: {self.row_commercial.get_path() or '[not selected]'}\n\n"
            f"Domestic: {self.row_domestic.get_path() or '[not selected]'}\n\n"
            f"Cafe: {self.row_cafe.get_path() or '[not selected]'}"
        )
        self.preview_text.setPlainText(preview)

    def _show_success_preview(
        self,
        cleaned_data: dict,
        analytics_store: dict,
        ui_state: dict,
    ) -> None:
        available_months = analytics_store.get("available_months", [])

        latest_month = "N/A"
        if available_months:
            latest_month = str(available_months[-1])

        preview = (
            "Dataset successfully prepared.\n\n"
            f"Commercial rows: {len(cleaned_data['commercial'])}\n"
            f"Domestic rows: {len(cleaned_data['domestic'])}\n"
            f"Cafe rows: {len(cleaned_data['cafe'])}\n\n"
            f"Available months: {len(available_months)}\n"
            f"Latest month: {latest_month}\n\n"
            "Initial UI state\n"
            f"- selected_month: {ui_state['selected_month']}\n"
            f"- selected_business_unit: {ui_state['selected_business_unit']}\n"
            f"- selected_forecast_scope: {ui_state['selected_forecast_scope']}\n"
            f"- selected_forecast_metric: {ui_state['selected_forecast_metric']}\n"
            f"- selected_forecast_model: {ui_state['selected_forecast_model']}"
        )
        self.preview_text.setPlainText(preview)

    def _append_status(self, text: str) -> None:
        current = self.status_text.toPlainText().rstrip()
        if current:
            current += "\n"
        current += text
        self.status_text.setPlainText(current)

    def _build_initial_ui_state(self, analytics_store: dict) -> dict:
        available_months = analytics_store.get("available_months", [])
        if not available_months:
            raise ValueError(
                "analytics_store does not contain any available months.")

        selected_month = str(available_months[-1])

        return {
            "selected_month": selected_month,
            "selected_business_unit": "Commercial",
            "selected_forecast_scope": "company",
            "selected_forecast_metric": "revenue",
            "selected_forecast_model": "linear_regression_lag3",
        }

    def _load_backend_functions(self) -> dict:
        """
        Dynamically load backend functions from locked node filenames.

        This is necessary because filenames like '01_input_validation.py'
        cannot be imported with normal Python import syntax.
        """
        base_dir = Path(__file__).resolve().parent

        return {
            "validate_input_files": self._load_function(
                base_dir / "01_input_validation.py",
                "validate_input_files",
            ),
            "clean_and_standardise": self._load_function(
                base_dir / "02_data_cleaning_standardising.py",
                "clean_and_standardise",
            ),
            "merge_datasets": self._load_function(
                base_dir / "03_merge_unified_dataset.py",
                "merge_datasets",
            ),
            "calculate_row_financials": self._load_function(
                base_dir / "04_per_row_financial_calculations.py",
                "calculate_row_financials",
            ),
            "build_monthly_analytics": self._load_function(
                base_dir / "05_monthly_analytics_engine.py",
                "build_monthly_analytics",
            ),
            "build_forecast_store": self._load_function(
                base_dir / "06_forecasting_engine.py",
                "build_forecast_store",
            ),
            "prepare_dashboard_data": self._load_function(
                base_dir / "07_dashboard_data_preparation.py",
                "prepare_dashboard_data",
            ),
        }

    def _load_function(self, file_path: Path, function_name: str):
        if not file_path.exists():
            raise FileNotFoundError(
                f"Required backend file not found: {file_path.name}")

        module_name = f"dynamic_{file_path.stem.replace('-', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, file_path)

        if spec is None or spec.loader is None:
            raise ImportError(
                f"Could not load module spec for {file_path.name}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if not hasattr(module, function_name):
            raise AttributeError(
                f"Function '{function_name}' not found in {file_path.name}"
            )

        return getattr(module, function_name)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    screen = FileSelectionScreen()
    screen.resize(1280, 760)
    screen.show()

    sys.exit(app.exec())

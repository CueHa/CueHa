import math
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.holtwinters import ExponentialSmoothing


REQUIRED_MODELS = [
    "linear_regression_lag3",
    "exponential_smoothing",
    "naive",
]

REQUIRED_SCOPES = [
    "company",
    "commercial",
    "domestic",
    "cafe",
]

REQUIRED_METRICS = [
    "revenue",
    "cost",
    "gross_margin_pct",
]


def build_forecast_store(
    analytics_store: Dict[str, object],
    models: List[str],
    horizon: int = 3,
) -> Dict[Tuple[str, str, str], Dict[str, object]]:
    """
    Precompute forecast results for all required scope/metric/model combinations.

    Returns:
    {
        (scope, metric, model_name): {
            "history": history_df,
            "test_predictions": test_pred_df,
            "future_forecast": future_forecast_df,
            "metrics": {
                "mae": float,
                "rmse": float
            }
        },
        ...
    }
    """
    _validate_inputs(analytics_store, models, horizon)

    forecast_store: Dict[Tuple[str, str, str], Dict[str, object]] = {}

    for scope in REQUIRED_SCOPES:
        for metric in REQUIRED_METRICS:
            history_df, model_series_df = _extract_series(
                analytics_store, scope, metric)

            for model_name in models:
                result = _run_single_forecast_pipeline(
                    history_df=history_df,
                    model_series_df=model_series_df,
                    model_name=model_name,
                    horizon=horizon,
                )
                forecast_store[(scope, metric, model_name)] = result

    return forecast_store


def _validate_inputs(
    analytics_store: Dict[str, object],
    models: List[str],
    horizon: int,
) -> None:
    if not isinstance(analytics_store, dict):
        raise ValueError("analytics_store must be a dictionary.")

    required_keys = [
        "monthly_company",
        "monthly_by_unit",
        "available_months",
    ]
    for key in required_keys:
        if key not in analytics_store:
            raise ValueError(
                f"analytics_store is missing required key: '{key}'")

    monthly_company = analytics_store["monthly_company"]
    monthly_by_unit = analytics_store["monthly_by_unit"]

    if not isinstance(monthly_company, pd.DataFrame):
        raise ValueError(
            "analytics_store['monthly_company'] must be a pandas DataFrame.")
    if not isinstance(monthly_by_unit, pd.DataFrame):
        raise ValueError(
            "analytics_store['monthly_by_unit'] must be a pandas DataFrame.")

    required_company_columns = [
        "month",
        "revenue",
        "cost",
        "gross_profit",
        "gross_margin_pct",
        "unique_domestic_customers",
        "active_commercial_customers",
        "mom_revenue_growth_pct",
    ]
    required_by_unit_columns = [
        "month",
        "business_unit",
        "revenue",
        "cost",
        "gross_profit",
        "gross_margin_pct",
    ]

    if list(monthly_company.columns) != required_company_columns:
        raise ValueError(
            "monthly_company does not match the expected schema.\n"
            f"Expected: {required_company_columns}\n"
            f"Actual:   {list(monthly_company.columns)}"
        )

    if list(monthly_by_unit.columns) != required_by_unit_columns:
        raise ValueError(
            "monthly_by_unit does not match the expected schema.\n"
            f"Expected: {required_by_unit_columns}\n"
            f"Actual:   {list(monthly_by_unit.columns)}"
        )

    if sorted(models) != sorted(REQUIRED_MODELS):
        raise ValueError(
            f"models must be exactly {REQUIRED_MODELS}. Got: {models}"
        )

    if horizon <= 0:
        raise ValueError("horizon must be a positive integer.")


def _extract_series(
    analytics_store: Dict[str, object],
    scope: str,
    metric: str,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Return:
    - history_df: raw visible history
    - model_series_df: cleaned model-input history used for forecasting
    """
    monthly_company = analytics_store["monthly_company"]
    monthly_by_unit = analytics_store["monthly_by_unit"]
    available_months = pd.to_datetime(
        pd.Index(analytics_store["available_months"])).sort_values()

    if scope == "company":
        source_df = monthly_company[["month", metric]].copy()
    else:
        business_unit_name = scope.capitalize()
        source_df = monthly_by_unit[
            monthly_by_unit["business_unit"] == business_unit_name
        ][["month", metric]].copy()

    source_df["month"] = pd.to_datetime(source_df["month"])
    source_df = source_df.sort_values("month")

    aligned_df = pd.DataFrame({"month": available_months})
    aligned_df = aligned_df.merge(source_df, on="month", how="left")

    aligned_df.rename(columns={metric: "actual_value"}, inplace=True)

    model_values = _build_model_input_series(
        actual_series=aligned_df["actual_value"],
        metric=metric,
    )

    model_series_df = pd.DataFrame({
        "month": aligned_df["month"],
        "model_value": model_values,
    })

    history_df = pd.DataFrame({
        "month": aligned_df["month"],
        "actual_value": aligned_df["actual_value"],
        "model_value": model_values,
    })

    return history_df, model_series_df


def _build_model_input_series(actual_series: pd.Series, metric: str) -> pd.Series:
    """
    Build a forecastable numeric series.

    Rules:
    - revenue / cost: missing month => 0.0
    - gross_margin_pct: interpolate through missing values, then ffill/bfill,
      then 0.0 only if everything is still missing
    """
    working = pd.to_numeric(actual_series, errors="coerce").copy()

    if metric in ["revenue", "cost"]:
        working = working.fillna(0.0)
        return working.astype(float)

    # gross_margin_pct
    if working.notna().sum() == 0:
        return pd.Series([0.0] * len(working), index=working.index, dtype="float64")

    working = working.interpolate(limit_direction="both")
    working = working.ffill().bfill()
    working = working.fillna(0.0)

    return working.astype(float)


def _run_single_forecast_pipeline(
    history_df: pd.DataFrame,
    model_series_df: pd.DataFrame,
    model_name: str,
    horizon: int,
) -> Dict[str, object]:
    months = pd.to_datetime(model_series_df["month"]).reset_index(drop=True)
    values = pd.to_numeric(model_series_df["model_value"], errors="raise").astype(
        float).reset_index(drop=True)

    if len(values) <= horizon:
        raise ValueError(
            f"Not enough observations for horizon={horizon}. "
            f"Need more than {horizon} monthly points."
        )

    train_values = values.iloc[:-horizon].to_numpy(dtype=float)
    test_values = values.iloc[-horizon:].to_numpy(dtype=float)
    test_months = months.iloc[-horizon:].reset_index(drop=True)

    test_predictions = _forecast_with_model(
        model_name=model_name,
        train_values=train_values,
        horizon=horizon,
    )

    mae_value = _mae(test_values, test_predictions)
    rmse_value = _rmse(test_values, test_predictions)

    full_values = values.to_numpy(dtype=float)
    future_predictions = _forecast_with_model(
        model_name=model_name,
        train_values=full_values,
        horizon=horizon,
    )

    future_months = _generate_future_months(
        last_month=months.iloc[-1], horizon=horizon)

    raw_actual_test = history_df["actual_value"].iloc[-horizon:].reset_index(
        drop=True)
    eval_actual_test = pd.Series(test_values)

    test_predictions_df = pd.DataFrame({
        "month": test_months,
        "actual_value": raw_actual_test,
        "evaluation_actual": eval_actual_test,
        "predicted_value": test_predictions,
    })

    future_forecast_df = pd.DataFrame({
        "month": future_months,
        "forecast_value": future_predictions,
    })

    return {
        "history": history_df.copy(),
        "test_predictions": test_predictions_df,
        "future_forecast": future_forecast_df,
        "metrics": {
            "mae": float(mae_value),
            "rmse": float(rmse_value),
        },
    }


def _forecast_with_model(
    model_name: str,
    train_values: np.ndarray,
    horizon: int,
) -> np.ndarray:
    if model_name == "naive":
        return _forecast_naive(train_values, horizon)

    if model_name == "linear_regression_lag3":
        return _forecast_linear_regression_lag3(train_values, horizon)

    if model_name == "exponential_smoothing":
        return _forecast_exponential_smoothing(train_values, horizon)

    raise ValueError(f"Unsupported model: {model_name}")


def _forecast_naive(train_values: np.ndarray, horizon: int) -> np.ndarray:
    last_value = float(train_values[-1])
    return np.array([last_value] * horizon, dtype=float)


def _forecast_linear_regression_lag3(train_values: np.ndarray, horizon: int) -> np.ndarray:
    if len(train_values) < 4:
        raise ValueError(
            "linear_regression_lag3 requires at least 4 training observations."
        )

    x_train = []
    y_train = []

    for i in range(3, len(train_values)):
        lag_1 = train_values[i - 1]
        lag_2 = train_values[i - 2]
        lag_3 = train_values[i - 3]

        x_train.append([lag_1, lag_2, lag_3])
        y_train.append(train_values[i])

    x_train = np.array(x_train, dtype=float)
    y_train = np.array(y_train, dtype=float)

    model = LinearRegression()
    model.fit(x_train, y_train)

    recursive_history = list(train_values.astype(float))
    predictions = []

    for _ in range(horizon):
        features = np.array([[
            recursive_history[-1],
            recursive_history[-2],
            recursive_history[-3],
        ]], dtype=float)

        next_value = float(model.predict(features)[0])
        predictions.append(next_value)
        recursive_history.append(next_value)

    return np.array(predictions, dtype=float)


def _forecast_exponential_smoothing(train_values: np.ndarray, horizon: int) -> np.ndarray:
    """
    Primary form:
        additive trend + additive seasonality with seasonal_periods=12

    Fallback form:
        additive trend only

    Final safety fallback:
        no trend, no seasonality
    """
    train_values = np.asarray(train_values, dtype=float)

    # Primary: additive trend + additive seasonality
    if len(train_values) >= 24:
        try:
            fitted_model = ExponentialSmoothing(
                train_values,
                trend="add",
                seasonal="add",
                seasonal_periods=12,
                initialization_method="estimated",
            ).fit(optimized=True)

            return np.asarray(fitted_model.forecast(horizon), dtype=float)
        except Exception:
            pass

    # Fallback: additive trend only
    try:
        fitted_model = ExponentialSmoothing(
            train_values,
            trend="add",
            seasonal=None,
            initialization_method="estimated",
        ).fit(optimized=True)

        return np.asarray(fitted_model.forecast(horizon), dtype=float)
    except Exception:
        pass

    # Final safety fallback
    fitted_model = ExponentialSmoothing(
        train_values,
        trend=None,
        seasonal=None,
        initialization_method="estimated",
    ).fit(optimized=True)

    return np.asarray(fitted_model.forecast(horizon), dtype=float)


def _generate_future_months(last_month: pd.Timestamp, horizon: int) -> pd.DatetimeIndex:
    last_month = pd.Timestamp(last_month)
    start_month = last_month + pd.offsets.MonthBegin(1)

    return pd.date_range(
        start=start_month,
        periods=horizon,
        freq="MS",
    )


def _mae(actual: np.ndarray, predicted: np.ndarray) -> float:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    return float(np.mean(np.abs(actual - predicted)))


def _rmse(actual: np.ndarray, predicted: np.ndarray) -> float:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    return float(math.sqrt(np.mean((actual - predicted) ** 2)))

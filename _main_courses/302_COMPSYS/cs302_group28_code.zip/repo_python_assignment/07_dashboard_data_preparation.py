from typing import Dict, List, Optional

import pandas as pd


VALID_BUSINESS_UNITS = ["Commercial", "Domestic", "Cafe"]
VALID_FORECAST_SCOPES = ["company", "commercial", "domestic", "cafe"]
VALID_FORECAST_METRICS = ["revenue", "cost", "gross_margin_pct"]
VALID_FORECAST_MODELS = [
    "linear_regression_lag3",
    "exponential_smoothing",
    "naive",
]


REQUIRED_ENRICHED_COLUMNS = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
    "revenue",
    "cost",
    "gross_profit",
]

REQUIRED_MONTHLY_COMPANY_COLUMNS = [
    "month",
    "revenue",
    "cost",
    "gross_profit",
    "gross_margin_pct",
    "unique_domestic_customers",
    "active_commercial_customers",
    "mom_revenue_growth_pct",
]

REQUIRED_MONTHLY_BY_UNIT_COLUMNS = [
    "month",
    "business_unit",
    "revenue",
    "cost",
    "gross_profit",
    "gross_margin_pct",
]


def prepare_dashboard_data(
    enriched_df: pd.DataFrame,
    analytics_store: Dict[str, object],
    forecast_store: Dict[tuple, Dict[str, object]],
    ui_state: Dict[str, object],
) -> Dict[str, Dict[str, object]]:
    """
    Convert backend tables into GUI-ready bundles.

    This is an adapter layer only.
    It must not recalculate finance or train models.
    """
    _validate_inputs(enriched_df, analytics_store, forecast_store, ui_state)

    monthly_company = analytics_store["monthly_company"].copy()
    monthly_by_unit = analytics_store["monthly_by_unit"].copy()

    monthly_company["month"] = pd.to_datetime(monthly_company["month"])
    monthly_by_unit["month"] = pd.to_datetime(monthly_by_unit["month"])

    available_months = pd.to_datetime(
        pd.Index(analytics_store["available_months"])).sort_values()

    selected_month = _resolve_selected_month(
        selected_month_value=ui_state.get("selected_month"),
        available_months=available_months,
    )

    selected_business_unit = _resolve_business_unit(
        ui_state.get("selected_business_unit")
    )

    selected_forecast_scope = _resolve_forecast_scope(
        ui_state.get("selected_forecast_scope", "company")
    )

    selected_forecast_metric = _resolve_forecast_metric(
        ui_state.get("selected_forecast_metric", "revenue")
    )

    selected_forecast_model = _resolve_forecast_model(
        ui_state.get("selected_forecast_model", "naive")
    )

    company_dashboard = _build_company_dashboard_bundle(
        monthly_company=monthly_company,
        selected_month=selected_month,
    )

    business_unit_dashboard = _build_business_unit_dashboard_bundle(
        monthly_by_unit=monthly_by_unit,
        selected_month=selected_month,
        selected_business_unit=selected_business_unit,
    )

    forecast_dashboard = _build_forecast_dashboard_bundle(
        forecast_store=forecast_store,
        selected_scope=selected_forecast_scope,
        selected_metric=selected_forecast_metric,
        selected_model=selected_forecast_model,
    )

    return {
        "company_dashboard": company_dashboard,
        "business_unit_dashboard": business_unit_dashboard,
        "forecast_dashboard": forecast_dashboard,
    }


def _build_company_dashboard_bundle(
    monthly_company: pd.DataFrame,
    selected_month: pd.Timestamp,
) -> Dict[str, object]:
    monthly_company = monthly_company.sort_values(
        "month").reset_index(drop=True)

    selected_row = monthly_company.loc[
        monthly_company["month"] == selected_month
    ]

    if selected_row.empty:
        raise ValueError(
            f"No company monthly data found for selected month: {selected_month}")

    selected_row = selected_row.iloc[0]

    month_index = monthly_company.index[
        monthly_company["month"] == selected_month
    ][0]

    previous_row = None
    if month_index > 0:
        previous_row = monthly_company.iloc[month_index - 1]

    trend_36_month = monthly_company.tail(36).reset_index(drop=True).copy()

    selected_month_kpis = {
        "month": selected_row["month"],
        "revenue": selected_row["revenue"],
        "cost": selected_row["cost"],
        "gross_profit": selected_row["gross_profit"],
        "gross_margin_pct": selected_row["gross_margin_pct"],
    }

    month_on_month_comparison = {
        "current_month": selected_row["month"],
        "previous_month": None if previous_row is None else previous_row["month"],
        "current_values": {
            "revenue": selected_row["revenue"],
            "cost": selected_row["cost"],
            "gross_profit": selected_row["gross_profit"],
            "gross_margin_pct": selected_row["gross_margin_pct"],
        },
        "previous_values": None if previous_row is None else {
            "revenue": previous_row["revenue"],
            "cost": previous_row["cost"],
            "gross_profit": previous_row["gross_profit"],
            "gross_margin_pct": previous_row["gross_margin_pct"],
        },
        "mom_revenue_growth_pct": selected_row["mom_revenue_growth_pct"],
    }

    selected_month_customer_metrics = {
        "unique_domestic_customers": selected_row["unique_domestic_customers"],
        "active_commercial_customers": selected_row["active_commercial_customers"],
    }

    return {
        "selected_month": selected_row["month"],
        "selected_month_kpis": selected_month_kpis,
        "trend_36_month": trend_36_month,
        "month_on_month_comparison": month_on_month_comparison,
        "selected_month_customer_metrics": selected_month_customer_metrics,
    }


def _build_business_unit_dashboard_bundle(
    monthly_by_unit: pd.DataFrame,
    selected_month: pd.Timestamp,
    selected_business_unit: str,
) -> Dict[str, object]:
    unit_df = monthly_by_unit.loc[
        monthly_by_unit["business_unit"] == selected_business_unit
    ].sort_values("month").reset_index(drop=True)

    if unit_df.empty:
        raise ValueError(
            f"No monthly data found for business unit: {selected_business_unit}")

    selected_row = unit_df.loc[unit_df["month"] == selected_month]

    selected_month_available = not selected_row.empty

    if selected_month_available:
        selected_row = selected_row.iloc[0]
        selected_month_kpis = {
            "month": selected_row["month"],
            "business_unit": selected_row["business_unit"],
            "revenue": selected_row["revenue"],
            "cost": selected_row["cost"],
            "gross_profit": selected_row["gross_profit"],
            "gross_margin_pct": selected_row["gross_margin_pct"],
        }
    else:
        selected_month_kpis = {
            "month": selected_month,
            "business_unit": selected_business_unit,
            "revenue": None,
            "cost": None,
            "gross_profit": None,
            "gross_margin_pct": None,
        }

    monthly_trend = unit_df.tail(36).reset_index(drop=True).copy()

    unit_summary = {
        "business_unit": selected_business_unit,
        "first_month": unit_df["month"].min(),
        "latest_month": unit_df["month"].max(),
        "available_month_count": int(len(unit_df)),
        "selected_month_available": selected_month_available,
    }

    return {
        "selected_business_unit": selected_business_unit,
        "selected_month": selected_month,
        "selected_month_kpis": selected_month_kpis,
        "monthly_trend": monthly_trend,
        "unit_summary": unit_summary,
    }


def _build_forecast_dashboard_bundle(
    forecast_store: Dict[tuple, Dict[str, object]],
    selected_scope: str,
    selected_metric: str,
    selected_model: str,
) -> Dict[str, object]:
    forecast_key = (selected_scope, selected_metric, selected_model)

    if forecast_key not in forecast_store:
        raise ValueError(
            f"Forecast selection not found in forecast_store: {forecast_key}"
        )

    selected_forecast = forecast_store[forecast_key]

    return {
        "selected_scope": selected_scope,
        "selected_metric": selected_metric,
        "selected_model": selected_model,
        "history": selected_forecast["history"].copy(),
        "test_predictions": selected_forecast["test_predictions"].copy(),
        "future_forecast": selected_forecast["future_forecast"].copy(),
        "displayed_error_metrics": {
            "mae": selected_forecast["metrics"]["mae"],
            "rmse": selected_forecast["metrics"]["rmse"],
        },
    }


def _resolve_selected_month(
    selected_month_value: object,
    available_months: pd.DatetimeIndex,
) -> pd.Timestamp:
    if len(available_months) == 0:
        raise ValueError("No available months found in analytics_store.")

    if selected_month_value is None:
        return pd.Timestamp(available_months[-1])

    try:
        normalized = pd.Timestamp(
            selected_month_value).to_period("M").to_timestamp()
    except Exception as exc:
        raise ValueError(
            f"Invalid selected_month value: {selected_month_value}") from exc

    if normalized not in set(available_months):
        raise ValueError(
            f"selected_month {normalized} is not in available_months."
        )

    return normalized


def _resolve_business_unit(value: object) -> str:
    if value is None:
        raise ValueError("ui_state must include 'selected_business_unit'.")

    if value not in VALID_BUSINESS_UNITS:
        raise ValueError(
            f"selected_business_unit must be one of {VALID_BUSINESS_UNITS}. Got: {value}"
        )

    return str(value)


def _resolve_forecast_scope(value: object) -> str:
    if value not in VALID_FORECAST_SCOPES:
        raise ValueError(
            f"selected_forecast_scope must be one of {VALID_FORECAST_SCOPES}. Got: {value}"
        )

    return str(value)


def _resolve_forecast_metric(value: object) -> str:
    if value not in VALID_FORECAST_METRICS:
        raise ValueError(
            f"selected_forecast_metric must be one of {VALID_FORECAST_METRICS}. Got: {value}"
        )

    return str(value)


def _resolve_forecast_model(value: object) -> str:
    if value not in VALID_FORECAST_MODELS:
        raise ValueError(
            f"selected_forecast_model must be one of {VALID_FORECAST_MODELS}. Got: {value}"
        )

    return str(value)


def _validate_inputs(
    enriched_df: pd.DataFrame,
    analytics_store: Dict[str, object],
    forecast_store: Dict[tuple, Dict[str, object]],
    ui_state: Dict[str, object],
) -> None:
    if not isinstance(enriched_df, pd.DataFrame):
        raise ValueError("enriched_df must be a pandas DataFrame.")

    if list(enriched_df.columns) != REQUIRED_ENRICHED_COLUMNS:
        raise ValueError(
            "enriched_df does not match the expected schema.\n"
            f"Expected: {REQUIRED_ENRICHED_COLUMNS}\n"
            f"Actual:   {list(enriched_df.columns)}"
        )

    if not isinstance(analytics_store, dict):
        raise ValueError("analytics_store must be a dictionary.")

    required_analytics_keys = [
        "monthly_company",
        "monthly_by_unit",
        "available_months",
    ]
    for key in required_analytics_keys:
        if key not in analytics_store:
            raise ValueError(
                f"analytics_store is missing required key: '{key}'")

    monthly_company = analytics_store["monthly_company"]
    monthly_by_unit = analytics_store["monthly_by_unit"]

    if not isinstance(monthly_company, pd.DataFrame):
        raise ValueError(
            "analytics_store['monthly_company'] must be a DataFrame.")
    if not isinstance(monthly_by_unit, pd.DataFrame):
        raise ValueError(
            "analytics_store['monthly_by_unit'] must be a DataFrame.")

    if list(monthly_company.columns) != REQUIRED_MONTHLY_COMPANY_COLUMNS:
        raise ValueError(
            "monthly_company does not match expected schema.\n"
            f"Expected: {REQUIRED_MONTHLY_COMPANY_COLUMNS}\n"
            f"Actual:   {list(monthly_company.columns)}"
        )

    if list(monthly_by_unit.columns) != REQUIRED_MONTHLY_BY_UNIT_COLUMNS:
        raise ValueError(
            "monthly_by_unit does not match expected schema.\n"
            f"Expected: {REQUIRED_MONTHLY_BY_UNIT_COLUMNS}\n"
            f"Actual:   {list(monthly_by_unit.columns)}"
        )

    if not isinstance(forecast_store, dict):
        raise ValueError("forecast_store must be a dictionary.")

    if not isinstance(ui_state, dict):
        raise ValueError("ui_state must be a dictionary.")

from typing import Dict

import pandas as pd


UNIFIED_SCHEMA_COLUMNS = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
]


NUMERIC_COLUMNS = [
    "qty",
    "list_unit_price",
    "discount_pct",
    "unit_cost",
]


def clean_and_standardise(raw_data: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    """
    Convert the three raw DataFrames into the locked unified internal schema,
    while keeping them separate.

    Expected input:
    {
        "commercial": df,
        "domestic": df,
        "cafe": df
    }

    Returns:
    {
        "commercial": cleaned_commercial_df,
        "domestic": cleaned_domestic_df,
        "cafe": cleaned_cafe_df
    }
    """
    commercial_df = _clean_commercial(raw_data["commercial"])
    domestic_df = _clean_domestic(raw_data["domestic"])
    cafe_df = _clean_cafe(raw_data["cafe"])

    return {
        "commercial": commercial_df,
        "domestic": domestic_df,
        "cafe": cafe_df,
    }


def _clean_commercial(df: pd.DataFrame) -> pd.DataFrame:
    working_df = df.copy(deep=True)
    working_df = _strip_column_whitespace(working_df)
    working_df = _parse_date_column(working_df, "Commercial")

    working_df["source_row_id"] = working_df.index
    working_df["source_unit"] = "Commercial"
    working_df["business_unit"] = "Commercial"

    cleaned_df = pd.DataFrame({
        "source_unit": working_df["source_unit"],
        "source_row_id": working_df["source_row_id"],
        "transaction_id": working_df["invoice_id"],
        "date": working_df["date"],
        "business_unit": working_df["business_unit"],
        "customer_id": working_df["customer_id"],
        "salesperson_id": working_df["salesperson_id"],
        "segment": working_df["segment"],
        "cafe_location": None,
        "sku": working_df["sku"],
        "qty": working_df["qty"],
        "list_unit_price": working_df["list_unit_price"],
        "discount_pct": working_df["discount_pct"],
        "unit_cost": working_df["unit_cost"],
    })

    cleaned_df = _convert_numeric_columns(cleaned_df, "Commercial")
    cleaned_df["net_unit_price"] = cleaned_df["list_unit_price"] * (
        1 - cleaned_df["discount_pct"]
    )

    return _finalise_schema(cleaned_df)


def _clean_domestic(df: pd.DataFrame) -> pd.DataFrame:
    working_df = df.copy(deep=True)
    working_df = _strip_column_whitespace(working_df)
    working_df = _parse_date_column(working_df, "Domestic")

    working_df["source_row_id"] = working_df.index
    working_df["source_unit"] = "Domestic"
    working_df["business_unit"] = "Domestic"

    cleaned_df = pd.DataFrame({
        "source_unit": working_df["source_unit"],
        "source_row_id": working_df["source_row_id"],
        "transaction_id": working_df["order_id"],
        "date": working_df["date"],
        "business_unit": working_df["business_unit"],
        "customer_id": working_df["customer_id"],
        "salesperson_id": working_df["salesperson_id"],
        "segment": working_df["segment"],
        "cafe_location": None,
        "sku": working_df["sku"],
        "qty": working_df["qty"],
        "list_unit_price": working_df["list_unit_price"],
        "discount_pct": working_df["discount_pct"],
        "unit_cost": working_df["unit_cost"],
    })

    cleaned_df = _convert_numeric_columns(cleaned_df, "Domestic")
    cleaned_df["net_unit_price"] = cleaned_df["list_unit_price"] * (
        1 - cleaned_df["discount_pct"]
    )

    return _finalise_schema(cleaned_df)


def _clean_cafe(df: pd.DataFrame) -> pd.DataFrame:
    working_df = df.copy(deep=True)
    working_df = _strip_column_whitespace(working_df)
    working_df = _parse_date_column(working_df, "Cafe")

    working_df["source_row_id"] = working_df.index
    working_df["source_unit"] = "Cafe"
    working_df["business_unit"] = "Cafe"

    cleaned_df = pd.DataFrame({
        "source_unit": working_df["source_unit"],
        "source_row_id": working_df["source_row_id"],
        "transaction_id": "CAFE_" + working_df["source_row_id"].astype(str),
        "date": working_df["date"],
        "business_unit": working_df["business_unit"],
        "customer_id": None,
        "salesperson_id": None,
        "segment": "Cafe",
        "cafe_location": working_df["cafe_location"],
        "sku": working_df["sku"],
        "qty": working_df["qty_sold"],
        "list_unit_price": working_df["list_unit_price"],
        "discount_pct": 0.0,
        "unit_cost": working_df["unit_cost"],
    })

    cleaned_df = _convert_numeric_columns(cleaned_df, "Cafe")
    cleaned_df["net_unit_price"] = cleaned_df["list_unit_price"]

    return _finalise_schema(cleaned_df)


def _strip_column_whitespace(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(column).strip() for column in df.columns]
    return df


def _parse_date_column(df: pd.DataFrame, source_name: str) -> pd.DataFrame:
    """
    Parse the date column to datetime.

    dayfirst=True is used because the sample files are in dd/mm/yyyy format.
    """
    parsed_dates = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)

    invalid_mask = parsed_dates.isna() & df["date"].notna()
    if invalid_mask.any():
        bad_rows = df.index[invalid_mask].tolist()
        raise ValueError(
            f"{source_name} contains invalid date values in rows: {bad_rows}"
        )

    df["date"] = parsed_dates
    return df


def _convert_numeric_columns(df: pd.DataFrame, source_name: str) -> pd.DataFrame:
    for column_name in NUMERIC_COLUMNS:
        converted_series = pd.to_numeric(df[column_name], errors="coerce")

        invalid_mask = converted_series.isna() & df[column_name].notna()
        if invalid_mask.any():
            bad_rows = df.index[invalid_mask].tolist()
            raise ValueError(
                f"{source_name} contains non-numeric values in '{column_name}' "
                f"at rows: {bad_rows}"
            )

        df[column_name] = converted_series

    return df


def _finalise_schema(df: pd.DataFrame) -> pd.DataFrame:
    """
    Enforce exact unified column order.
    """
    return df[UNIFIED_SCHEMA_COLUMNS].copy()

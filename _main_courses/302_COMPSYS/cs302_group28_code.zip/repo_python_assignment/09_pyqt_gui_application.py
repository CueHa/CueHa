import importlib.util
import sys
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)


class MainWindow(QMainWindow):
    """
    Main application shell.

    Responsibilities:
    - Own the main application window
    - Store shared ui_state
    - Store backend data references
    - Navigate between dashboard pages
    - Re-run Node 7 when shared selections change
    - Push refreshed bundles into dashboard widgets

    This class does NOT:
    - read raw CSV files
    - fit forecast models
    - run aggregation math itself
    """

    def __init__(self, pipeline_package: dict):
        super().__init__()

        self._validate_pipeline_package(pipeline_package)

        self.pipeline_package = pipeline_package
        self.enriched_df = pipeline_package["enriched_df"]
        self.analytics_store = pipeline_package["analytics_store"]
        self.forecast_store = pipeline_package["forecast_store"]
        self.ui_state = dict(pipeline_package["ui_state"])
        self.dashboard_store = dict(pipeline_package["dashboard_store"])

        self.prepare_dashboard_data = self._load_function(
            "07_dashboard_data_preparation.py",
            "prepare_dashboard_data",
        )

        self.CompanyWideDashboard = self._load_object(
            "10_company_wide_dashboard.py",
            "CompanyWideDashboard",
        )
        self.BusinessUnitDashboard = self._load_object(
            "11_business_unit_dashboard.py",
            "BusinessUnitDashboard",
        )
        self.ForecastDashboard = self._load_object(
            "12_forecast_dashboard.py",
            "ForecastDashboard",
        )

        self.setWindowTitle("RoastWorks Sales Analytics")
        self.resize(1450, 900)
        self.setMinimumSize(1260, 780)

        self.setStyleSheet(
            """
            QMainWindow {
                background-color: #eef2f7;
            }

            QLabel {
                background: transparent;
                border: none;
            }

            QStatusBar {
                background-color: #ffffff;
                color: #475569;
                border-top: 1px solid #d9dee7;
                font-size: 12px;
                padding-left: 8px;
            }
            """
        )

        self._build_ui()
        self._create_pages()
        self._connect_dashboard_signals()
        self._set_active_page("company")

        self.statusBar().showMessage("Dashboard loaded successfully.")

    def _build_ui(self) -> None:
        self.central = QWidget()
        self.setCentralWidget(self.central)

        self.root_layout = QHBoxLayout(self.central)
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.root_layout.setSpacing(0)

        self._build_sidebar()
        self._build_stack_area()

    def _build_sidebar(self) -> None:
        self.sidebar = QFrame()
        self.sidebar.setObjectName("Sidebar")
        self.sidebar.setFixedWidth(235)
        self.sidebar.setStyleSheet(
            """
            QFrame#Sidebar {
                background-color: #111827;
                border: none;
            }

            QFrame#Sidebar QLabel {
                background: transparent;
                border: none;
            }
            """
        )

        layout = QVBoxLayout(self.sidebar)
        layout.setContentsMargins(18, 22, 18, 20)
        layout.setSpacing(12)

        app_title = QLabel("RoastWorks")
        app_title.setStyleSheet(
            """
            QLabel {
                font-size: 24px;
                font-weight: 800;
                color: white;
                background: transparent;
                border: none;
            }
            """
        )
        layout.addWidget(app_title)

        subtitle = QLabel("Sales Analytics Dashboard")
        subtitle.setStyleSheet(
            """
            QLabel {
                font-size: 12px;
                font-weight: 600;
                color: #cbd5e1;
                background: transparent;
                border: none;
            }
            """
        )
        layout.addWidget(subtitle)

        layout.addSpacing(24)

        nav_label = QLabel("Dashboards")
        nav_label.setStyleSheet(
            """
            QLabel {
                font-size: 11px;
                font-weight: 800;
                color: #64748b;
                letter-spacing: 1px;
                text-transform: uppercase;
                background: transparent;
                border: none;
            }
            """
        )
        layout.addWidget(nav_label)

        self.nav_company = self._make_nav_button(
            "Company Overview", active=True)
        self.nav_units = self._make_nav_button("Business Units")
        self.nav_forecast = self._make_nav_button("Forecasting")

        self.nav_company.clicked.connect(
            lambda: self._set_active_page("company")
        )
        self.nav_units.clicked.connect(
            lambda: self._set_active_page("business_unit")
        )
        self.nav_forecast.clicked.connect(
            lambda: self._set_active_page("forecast")
        )

        layout.addWidget(self.nav_company)
        layout.addWidget(self.nav_units)
        layout.addWidget(self.nav_forecast)

        layout.addStretch()

        self.shared_state_label = QLabel()
        self.shared_state_label.setWordWrap(True)
        self.shared_state_label.setStyleSheet(
            """
            QLabel {
                background-color: #0f172a;
                border: 1px solid #1e293b;
                border-radius: 10px;
                padding: 12px;
                font-size: 11px;
                color: #cbd5e1;
                line-height: 1.35;
            }
            """
        )
        layout.addWidget(self.shared_state_label)

        self.root_layout.addWidget(self.sidebar)

    def _build_stack_area(self) -> None:
        self.stack = QStackedWidget()
        self.stack.setObjectName("DashboardStack")
        self.stack.setStyleSheet(
            """
            QStackedWidget#DashboardStack {
                background-color: #eef2f7;
                border: none;
            }
            """
        )
        self.root_layout.addWidget(self.stack, 1)

    def _create_pages(self) -> None:
        available_months = self.analytics_store["available_months"]

        self.company_page = self.CompanyWideDashboard(
            company_dashboard_bundle=self.dashboard_store["company_dashboard"],
            available_months=available_months,
        )

        self.business_unit_page = self.BusinessUnitDashboard(
            business_unit_dashboard_bundle=self.dashboard_store["business_unit_dashboard"],
            available_months=available_months,
        )

        self.forecast_page = self.ForecastDashboard(
            forecast_dashboard_bundle=self.dashboard_store["forecast_dashboard"],
        )

        self.stack.addWidget(self.company_page)
        self.stack.addWidget(self.business_unit_page)
        self.stack.addWidget(self.forecast_page)

        self.page_indices = {
            "company": 0,
            "business_unit": 1,
            "forecast": 2,
        }

        self._update_shared_state_footer()

    def _connect_dashboard_signals(self) -> None:
        self.company_page.month_changed.connect(self._handle_month_changed)

        self.business_unit_page.month_changed.connect(
            self._handle_month_changed
        )
        self.business_unit_page.business_unit_changed.connect(
            self._handle_business_unit_changed
        )

        self.forecast_page.scope_changed.connect(
            self._handle_forecast_scope_changed
        )
        self.forecast_page.metric_changed.connect(
            self._handle_forecast_metric_changed
        )
        self.forecast_page.model_changed.connect(
            self._handle_forecast_model_changed
        )

    def _set_active_page(self, page_name: str) -> None:
        if page_name not in self.page_indices:
            raise ValueError(f"Unknown page name: {page_name}")

        self.stack.setCurrentIndex(self.page_indices[page_name])
        self._update_nav_styles(page_name)
        self.statusBar().showMessage(
            f"Viewing {page_name.replace('_', ' ').title()} dashboard."
        )

    def _update_nav_styles(self, active_page: str) -> None:
        self._apply_nav_style(self.nav_company, active_page == "company")
        self._apply_nav_style(self.nav_units, active_page == "business_unit")
        self._apply_nav_style(self.nav_forecast, active_page == "forecast")

    def _apply_nav_style(self, button: QPushButton, active: bool) -> None:
        if active:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 9px;
                    text-align: left;
                    padding-left: 14px;
                    padding-right: 12px;
                    font-size: 13px;
                    font-weight: 800;
                    min-height: 44px;
                }

                QPushButton:hover {
                    background-color: #1d4ed8;
                }
                """
            )
        else:
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #1f2937;
                    color: #d1d5db;
                    border: 1px solid #374151;
                    border-radius: 9px;
                    text-align: left;
                    padding-left: 14px;
                    padding-right: 12px;
                    font-size: 13px;
                    font-weight: 650;
                    min-height: 44px;
                }

                QPushButton:hover {
                    background-color: #273449;
                    color: white;
                }
                """
            )

    def _make_nav_button(self, text: str, active: bool = False) -> QPushButton:
        button = QPushButton(text)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._apply_nav_style(button, active)
        return button

    def _handle_month_changed(self, month_value: str) -> None:
        self.ui_state["selected_month"] = month_value
        self._refresh_dashboards("Updated selected month.")

    def _handle_business_unit_changed(self, business_unit: str) -> None:
        self.ui_state["selected_business_unit"] = business_unit
        self._refresh_dashboards("Updated selected business unit.")

    def _handle_forecast_scope_changed(self, forecast_scope: str) -> None:
        self.ui_state["selected_forecast_scope"] = forecast_scope
        self._refresh_dashboards("Updated forecast view.")

    def _handle_forecast_metric_changed(self, forecast_metric: str) -> None:
        self.ui_state["selected_forecast_metric"] = forecast_metric
        self._refresh_dashboards("Updated forecast metric.")

    def _handle_forecast_model_changed(self, forecast_model: str) -> None:
        self.ui_state["selected_forecast_model"] = forecast_model
        self._refresh_dashboards("Updated forecast model.")

    def _refresh_dashboards(self, status_message: str) -> None:
        try:
            self.dashboard_store = self.prepare_dashboard_data(
                self.enriched_df,
                self.analytics_store,
                self.forecast_store,
                self.ui_state,
            )

            self.company_page.set_dashboard_data(
                self.dashboard_store["company_dashboard"]
            )
            self.business_unit_page.set_dashboard_data(
                self.dashboard_store["business_unit_dashboard"]
            )
            self.forecast_page.set_dashboard_data(
                self.dashboard_store["forecast_dashboard"]
            )

            self._update_shared_state_footer()
            self.statusBar().showMessage(status_message)

        except Exception as exc:
            self.statusBar().showMessage("Could not update dashboard.")
            QMessageBox.critical(
                self,
                "Dashboard Update Error",
                f"Could not refresh dashboards.\n\n{type(exc).__name__}: {exc}",
            )

    def _update_shared_state_footer(self) -> None:
        self.shared_state_label.setText(
            "Current Selection\n\n"
            f"Month: {self.ui_state.get('selected_month', 'N/A')}\n"
            f"Business Unit: {self.ui_state.get('selected_business_unit', 'N/A')}\n"
            f"Forecast View: {self.ui_state.get('selected_forecast_scope', 'N/A')}\n"
            f"Forecast Metric: {self.ui_state.get('selected_forecast_metric', 'N/A')}\n"
            f"Forecast Model: {self.ui_state.get('selected_forecast_model', 'N/A')}"
        )

    def _validate_pipeline_package(self, pipeline_package: dict) -> None:
        required_keys = [
            "enriched_df",
            "analytics_store",
            "forecast_store",
            "ui_state",
            "dashboard_store",
        ]

        if not isinstance(pipeline_package, dict):
            raise ValueError("pipeline_package must be a dictionary.")

        for key in required_keys:
            if key not in pipeline_package:
                raise ValueError(
                    f"pipeline_package is missing required key: '{key}'"
                )

    def _load_function(self, filename: str, function_name: str):
        module = self._load_module_from_file(filename)

        if not hasattr(module, function_name):
            raise AttributeError(
                f"Function '{function_name}' not found in {filename}"
            )

        return getattr(module, function_name)

    def _load_object(self, filename: str, object_name: str):
        module = self._load_module_from_file(filename)

        if not hasattr(module, object_name):
            raise AttributeError(
                f"Object '{object_name}' not found in {filename}"
            )

        return getattr(module, object_name)

    def _load_module_from_file(self, filename: str):
        base_dir = Path(__file__).resolve().parent
        file_path = base_dir / filename

        if not file_path.exists():
            raise FileNotFoundError(f"Required file not found: {filename}")

        module_name = f"dynamic_{file_path.stem.replace('-', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, file_path)

        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load module spec for {filename}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module


if __name__ == "__main__":
    QMessageBox.information(
        None,
        "RoastWorks Sales Analytics",
        "This dashboard opens after the required CSV files have been loaded.",
    )
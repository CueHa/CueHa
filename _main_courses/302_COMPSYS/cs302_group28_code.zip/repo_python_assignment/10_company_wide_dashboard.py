from typing import Optional, Sequence

import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(28)
        self.set_badge_style(text, bg_color, text_color)

    def set_badge_style(self, text: str, bg_color: str, text_color: str = "#1f2937") -> None:
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class ComparisonKPICard(QFrame):
    def __init__(self, title: str):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        self.title_label = QLabel(title)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet(
            "font-size: 12px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(self.title_label)

        values_row = QHBoxLayout()
        values_row.setSpacing(10)

        self.previous_value_label = self._make_metric_block("Previous Month")
        self.current_value_label = self._make_metric_block("Selected Month")

        values_row.addWidget(self.previous_value_label["container"])
        values_row.addWidget(self.current_value_label["container"])
        layout.addLayout(values_row)

        change_row = QHBoxLayout()
        change_row.setSpacing(8)

        change_label = QLabel("Change")
        change_label.setStyleSheet("font-size: 11px; color: #6b7280;")
        change_row.addWidget(change_label)

        self.change_badge = StatusBadge("N/A", "#f3f4f6", "#374151")
        self.change_badge.setFixedWidth(120)
        change_row.addWidget(self.change_badge)

        change_row.addStretch()
        layout.addLayout(change_row)

    def _make_metric_block(self, label_text: str) -> dict:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        label = QLabel(label_text)
        label.setStyleSheet("font-size: 11px; color: #6b7280;")

        value = QLabel("N/A")
        value.setStyleSheet(
            "font-size: 16px; font-weight: 800; color: #111827;"
        )

        layout.addWidget(label)
        layout.addWidget(value)

        return {
            "container": container,
            "value_label": value,
        }

    def set_values(
        self,
        previous_value: str,
        current_value: str,
        change_text: str,
        change_positive: Optional[bool],
    ) -> None:
        self.previous_value_label["value_label"].setText(previous_value)
        self.current_value_label["value_label"].setText(current_value)

        if change_positive is None:
            self.change_badge.set_badge_style(
                change_text, "#f3f4f6", "#374151"
            )
        elif change_positive:
            self.change_badge.set_badge_style(
                change_text, "#dcfce7", "#166534"
            )
        else:
            self.change_badge.set_badge_style(
                change_text, "#fee2e2", "#991b1b"
            )


class SingleKPICard(QFrame):
    def __init__(self, title: str, subtitle: str = ""):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        self.title_label = QLabel(title)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet(
            "font-size: 12px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(self.title_label)

        self.value_label = QLabel("N/A")
        self.value_label.setStyleSheet(
            "font-size: 22px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(self.value_label)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setStyleSheet(
            "font-size: 11px; color: #6b7280;"
        )
        layout.addWidget(self.subtitle_label)

        layout.addStretch()

    def set_value(self, value_text: str, subtitle_text: Optional[str] = None) -> None:
        self.value_label.setText(value_text)
        if subtitle_text is not None:
            self.subtitle_label.setText(subtitle_text)


class CompanyTrendCanvas(FigureCanvas):
    def __init__(self, parent: Optional[QWidget] = None):
        self.figure = Figure(figsize=(7, 4), tight_layout=True)
        self.axes = self.figure.add_subplot(111)
        super().__init__(self.figure)
        self.setParent(parent)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

    def plot_company_trend(self, trend_df: pd.DataFrame) -> None:
        self.axes.clear()

        if trend_df is None or trend_df.empty:
            self.axes.text(
                0.5,
                0.5,
                "No trend data available",
                ha="center",
                va="center",
                transform=self.axes.transAxes,
            )
            self.axes.set_xticks([])
            self.axes.set_yticks([])
            self.draw()
            return

        working_df = trend_df.copy()
        working_df["month"] = pd.to_datetime(working_df["month"])
        working_df = working_df.sort_values("month")

        self.axes.plot(
            working_df["month"],
            working_df["revenue"],
            label="Revenue",
            linewidth=2.5,
            color="#2563eb",
        )
        self.axes.plot(
            working_df["month"],
            working_df["cost"],
            label="Cost",
            linewidth=2.5,
            color="#ef4444",
        )
        self.axes.plot(
            working_df["month"],
            working_df["gross_profit"],
            label="Gross Profit",
            linewidth=2.5,
            color="#0f766e",
        )

        self.axes.set_facecolor("#f8fafc")
        self.axes.grid(True, alpha=0.25)
        self.axes.set_xlabel("Month")
        self.axes.set_ylabel("Value")
        self.axes.legend()

        for spine in self.axes.spines.values():
            spine.set_color("#d1d5db")

        self.figure.autofmt_xdate()
        self.draw()


class CompanyWideDashboard(QWidget):
    month_changed = pyqtSignal(str)

    def __init__(
        self,
        company_dashboard_bundle: Optional[dict] = None,
        available_months: Optional[Sequence] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)

        self._current_bundle: Optional[dict] = None
        self._available_months: list[pd.Timestamp] = []

        self.setStyleSheet(
            """
            QWidget {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 12px;
                color: #111827;
                min-height: 20px;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
            }
            """
        )

        self._build_ui()

        if available_months is not None:
            self.set_available_months(available_months)

        if company_dashboard_bundle is not None:
            self.set_dashboard_data(company_dashboard_bundle)

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(18)

        header_card = QFrame()
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 16, 18, 16)
        header_layout.setSpacing(16)

        title_block = QVBoxLayout()
        title_block.setSpacing(4)

        title = QLabel("Company Overview")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;"
        )

        subtitle = QLabel(
            "Company-level sales performance for the selected month, with revenue, cost, and gross profit trends."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")

        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        filter_block = QVBoxLayout()
        filter_block.setSpacing(8)

        filter_top = QHBoxLayout()
        filter_top.setSpacing(8)

        self.loaded_badge = StatusBadge(
            "Loaded: 0 months", "#dcfce7", "#166534"
        )
        self.loaded_badge.setFixedWidth(150)
        filter_top.addWidget(self.loaded_badge)

        self.scope_badge = StatusBadge("Company Wide", "#dbeafe", "#1d4ed8")
        self.scope_badge.setFixedWidth(120)
        filter_top.addWidget(self.scope_badge)

        filter_top.addStretch()

        month_row = QHBoxLayout()
        month_row.setSpacing(8)

        month_label = QLabel("Month")
        month_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.month_selector = QComboBox()
        self.month_selector.setFixedWidth(180)
        self.month_selector.currentIndexChanged.connect(self._on_month_changed)

        month_row.addWidget(month_label)
        month_row.addWidget(self.month_selector)

        filter_block.addLayout(filter_top)
        filter_block.addLayout(month_row)

        header_layout.addLayout(filter_block)
        main_layout.addWidget(header_card)

        self.revenue_card = ComparisonKPICard("Total Revenue")
        self.cost_card = ComparisonKPICard("Total Cost")
        self.gross_profit_card = ComparisonKPICard("Total Gross Profit")
        self.gross_margin_card = ComparisonKPICard("Gross Margin")
        self.domestic_customers_card = SingleKPICard(
            "Unique Domestic Customers",
            "Selected month count",
        )
        self.commercial_customers_card = SingleKPICard(
            "Active Commercial Customers",
            "Selected month count",
        )
        self.mom_growth_card = SingleKPICard(
            "Month-on-Month Revenue Growth",
            "Selected month KPI",
        )

        kpi_grid = QGridLayout()
        kpi_grid.setHorizontalSpacing(14)
        kpi_grid.setVerticalSpacing(14)

        kpi_grid.addWidget(self.revenue_card, 0, 0)
        kpi_grid.addWidget(self.cost_card, 0, 1)
        kpi_grid.addWidget(self.gross_profit_card, 0, 2)
        kpi_grid.addWidget(self.gross_margin_card, 0, 3)

        kpi_grid.addWidget(self.domestic_customers_card, 1, 0)
        kpi_grid.addWidget(self.commercial_customers_card, 1, 1)
        kpi_grid.addWidget(self.mom_growth_card, 1, 2)

        main_layout.addLayout(kpi_grid)

        bottom_grid = QGridLayout()
        bottom_grid.setHorizontalSpacing(18)
        bottom_grid.setVerticalSpacing(18)

        chart_card = self._make_info_card(
            "Company Trend, 36-Month History"
        )
        chart_layout = chart_card.layout()

        self.chart_subtitle = QLabel(
            "Revenue, cost, and gross profit across the available monthly history."
        )
        self.chart_subtitle.setWordWrap(True)
        self.chart_subtitle.setStyleSheet("font-size: 12px; color: #4b5563;")
        chart_layout.addWidget(self.chart_subtitle)

        self.trend_canvas = CompanyTrendCanvas(self)
        chart_layout.addWidget(self.trend_canvas)

        bottom_grid.addWidget(chart_card, 0, 0)

        side_panel = QWidget()
        side_layout = QVBoxLayout(side_panel)
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.setSpacing(14)

        summary_card = self._make_info_card("Quick Summary")
        summary_layout = summary_card.layout()

        self.summary_text = QLabel("No data loaded.")
        self.summary_text.setWordWrap(True)
        self.summary_text.setStyleSheet(
            "font-size: 12px; color: #374151; line-height: 1.5;"
        )
        summary_layout.addWidget(self.summary_text)
        side_layout.addWidget(summary_card)

        legend_card = self._make_info_card("Chart Legend")
        legend_layout = legend_card.layout()
        legend_layout.addWidget(self._make_legend_row("#2563eb", "Revenue"))
        legend_layout.addWidget(self._make_legend_row("#ef4444", "Cost"))
        legend_layout.addWidget(
            self._make_legend_row("#0f766e", "Gross Profit")
        )
        side_layout.addWidget(legend_card)

        side_layout.addStretch()

        bottom_grid.addWidget(side_panel, 0, 1)
        bottom_grid.setColumnStretch(0, 9)
        bottom_grid.setColumnStretch(1, 4)

        main_layout.addLayout(bottom_grid)

    def _make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(title)

        return card

    def _make_legend_row(self, color: str, text: str) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)

        swatch = QLabel()
        swatch.setFixedSize(16, 16)
        swatch.setStyleSheet(
            f"""
            QLabel {{
                background-color: {color};
                border-radius: 4px;
                border: 1px solid #d1d5db;
            }}
            """
        )

        label = QLabel(text)
        label.setStyleSheet(
            "font-size: 12px; color: #374151; font-weight: 600;"
        )

        row.addWidget(swatch)
        row.addWidget(label)
        row.addStretch()

        return widget

    def set_available_months(self, available_months: Sequence) -> None:
        normalized_months = []

        for month_value in available_months:
            month_ts = pd.Timestamp(month_value).to_period("M").to_timestamp()
            normalized_months.append(month_ts)

        self._available_months = sorted(set(normalized_months))
        self._refresh_month_selector()

    def set_dashboard_data(self, company_dashboard_bundle: dict) -> None:
        self._validate_bundle(company_dashboard_bundle)

        self._current_bundle = company_dashboard_bundle

        selected_month = pd.Timestamp(
            company_dashboard_bundle["selected_month"]
        ).to_period("M").to_timestamp()
        selected_month_kpis = company_dashboard_bundle["selected_month_kpis"]
        selected_month_customer_metrics = company_dashboard_bundle[
            "selected_month_customer_metrics"
        ]
        month_on_month_comparison = company_dashboard_bundle[
            "month_on_month_comparison"
        ]
        trend_36_month = company_dashboard_bundle["trend_36_month"].copy()

        trend_36_month["month"] = pd.to_datetime(trend_36_month["month"])
        trend_36_month = trend_36_month.sort_values(
            "month").reset_index(drop=True)

        self.loaded_badge.set_badge_style(
            f"Loaded: {len(trend_36_month)} months",
            "#dcfce7",
            "#166534",
        )

        self._set_selector_to_month(selected_month)

        previous_values = month_on_month_comparison.get("previous_values")

        self.revenue_card.set_values(
            previous_value=self._format_currency(
                None if previous_values is None else previous_values.get(
                    "revenue")
            ),
            current_value=self._format_currency(
                selected_month_kpis.get("revenue")
            ),
            change_text=self._build_difference_text(
                previous_value=None if previous_values is None else previous_values.get(
                    "revenue"
                ),
                current_value=selected_month_kpis.get("revenue"),
                is_percentage=False,
                is_points=False,
            ),
            change_positive=self._difference_positive(
                previous_value=None if previous_values is None else previous_values.get(
                    "revenue"
                ),
                current_value=selected_month_kpis.get("revenue"),
            ),
        )

        self.cost_card.set_values(
            previous_value=self._format_currency(
                None if previous_values is None else previous_values.get(
                    "cost")
            ),
            current_value=self._format_currency(
                selected_month_kpis.get("cost")
            ),
            change_text=self._build_difference_text(
                previous_value=None if previous_values is None else previous_values.get(
                    "cost"
                ),
                current_value=selected_month_kpis.get("cost"),
                is_percentage=False,
                is_points=False,
            ),
            change_positive=self._difference_positive(
                previous_value=None if previous_values is None else previous_values.get(
                    "cost"
                ),
                current_value=selected_month_kpis.get("cost"),
            ),
        )

        self.gross_profit_card.set_values(
            previous_value=self._format_currency(
                None if previous_values is None else previous_values.get(
                    "gross_profit")
            ),
            current_value=self._format_currency(
                selected_month_kpis.get("gross_profit")
            ),
            change_text=self._build_difference_text(
                previous_value=None if previous_values is None else previous_values.get(
                    "gross_profit"
                ),
                current_value=selected_month_kpis.get("gross_profit"),
                is_percentage=False,
                is_points=False,
            ),
            change_positive=self._difference_positive(
                previous_value=None if previous_values is None else previous_values.get(
                    "gross_profit"
                ),
                current_value=selected_month_kpis.get("gross_profit"),
            ),
        )

        self.gross_margin_card.set_values(
            previous_value=self._format_percentage(
                None if previous_values is None else previous_values.get(
                    "gross_margin_pct"
                )
            ),
            current_value=self._format_percentage(
                selected_month_kpis.get("gross_margin_pct")
            ),
            change_text=self._build_difference_text(
                previous_value=None if previous_values is None else previous_values.get(
                    "gross_margin_pct"
                ),
                current_value=selected_month_kpis.get("gross_margin_pct"),
                is_percentage=False,
                is_points=True,
            ),
            change_positive=self._difference_positive(
                previous_value=None if previous_values is None else previous_values.get(
                    "gross_margin_pct"
                ),
                current_value=selected_month_kpis.get("gross_margin_pct"),
            ),
        )

        self.domestic_customers_card.set_value(
            self._format_integer(
                selected_month_customer_metrics.get(
                    "unique_domestic_customers")
            ),
            subtitle_text="Selected month count",
        )

        self.commercial_customers_card.set_value(
            self._format_integer(
                selected_month_customer_metrics.get(
                    "active_commercial_customers")
            ),
            subtitle_text="Selected month count",
        )

        self.mom_growth_card.set_value(
            self._format_percentage(
                month_on_month_comparison.get("mom_revenue_growth_pct")
            ),
            subtitle_text="Selected month KPI",
        )

        self.trend_canvas.plot_company_trend(trend_36_month)

        self.summary_text.setText(
            f"Selected month: {selected_month.strftime('%B %Y')}\n\n"
            f"This view combines Commercial, Domestic, and Cafe results.\n"
            f"The KPI cards compare the selected month against the previous month where available.\n\n"
            f"The trend chart shows {len(trend_36_month)} monthly points of company history."
        )

    def _refresh_month_selector(self) -> None:
        self.month_selector.blockSignals(True)
        self.month_selector.clear()

        for month_ts in self._available_months:
            self.month_selector.addItem(
                month_ts.strftime("%B %Y"),
                month_ts.strftime("%Y-%m-%d"),
            )

        self.month_selector.setEnabled(len(self._available_months) > 0)
        self.month_selector.blockSignals(False)

    def _set_selector_to_month(self, month_value: pd.Timestamp) -> None:
        if not self._available_months:
            return

        target_data = month_value.strftime("%Y-%m-%d")
        index = self.month_selector.findData(target_data)

        if index >= 0:
            self.month_selector.blockSignals(True)
            self.month_selector.setCurrentIndex(index)
            self.month_selector.blockSignals(False)

    def _on_month_changed(self, index: int) -> None:
        if index < 0:
            return

        month_data = self.month_selector.itemData(index)
        if month_data is None:
            return

        self.month_changed.emit(str(month_data))

    def _validate_bundle(self, bundle: dict) -> None:
        required_keys = [
            "selected_month",
            "selected_month_kpis",
            "trend_36_month",
            "month_on_month_comparison",
            "selected_month_customer_metrics",
        ]

        for key in required_keys:
            if key not in bundle:
                raise ValueError(
                    f"company_dashboard_bundle is missing required key: '{key}'"
                )

        selected_kpi_keys = [
            "month",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
        ]
        for key in selected_kpi_keys:
            if key not in bundle["selected_month_kpis"]:
                raise ValueError(
                    f"selected_month_kpis is missing required key: '{key}'"
                )

        customer_metric_keys = [
            "unique_domestic_customers",
            "active_commercial_customers",
        ]
        for key in customer_metric_keys:
            if key not in bundle["selected_month_customer_metrics"]:
                raise ValueError(
                    f"selected_month_customer_metrics is missing required key: '{key}'"
                )

        if "mom_revenue_growth_pct" not in bundle["month_on_month_comparison"]:
            raise ValueError(
                "month_on_month_comparison is missing 'mom_revenue_growth_pct'"
            )

        trend_df = bundle["trend_36_month"]
        if not isinstance(trend_df, pd.DataFrame):
            raise ValueError("trend_36_month must be a pandas DataFrame.")

        required_trend_columns = ["month", "revenue", "cost", "gross_profit"]
        for column_name in required_trend_columns:
            if column_name not in trend_df.columns:
                raise ValueError(
                    f"trend_36_month is missing required column: '{column_name}'"
                )

    def _format_currency(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"${value:,.2f}"

    def _format_percentage(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"{value:.2f}%"

    def _format_integer(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"{int(value)}"

    def _difference_positive(self, previous_value, current_value) -> Optional[bool]:
        if previous_value is None or current_value is None:
            return None
        if pd.isna(previous_value) or pd.isna(current_value):
            return None
        return current_value >= previous_value

    def _build_difference_text(
        self,
        previous_value,
        current_value,
        is_percentage: bool,
        is_points: bool,
    ) -> str:
        if previous_value is None or current_value is None:
            return "N/A"
        if pd.isna(previous_value) or pd.isna(current_value):
            return "N/A"

        difference = current_value - previous_value

        if is_points:
            sign = "+" if difference >= 0 else ""
            return f"{sign}{difference:.2f} pts"

        if is_percentage:
            sign = "+" if difference >= 0 else ""
            return f"{sign}{difference:.2f}%"

        sign = "+" if difference >= 0 else "-"
        return f"{sign}${abs(difference):,.2f}"


if __name__ == "__main__":
    import sys

    demo_trend_df = pd.DataFrame({
        "month": pd.date_range(start="2023-01-01", periods=36, freq="MS"),
        "revenue": [100000 + i * 2200 for i in range(36)],
        "cost": [65000 + i * 1500 for i in range(36)],
        "gross_profit": [35000 + i * 700 for i in range(36)],
    })

    demo_bundle = {
        "selected_month": "2025-12-01",
        "selected_month_kpis": {
            "month": "2025-12-01",
            "revenue": 177000.0,
            "cost": 117500.0,
            "gross_profit": 59500.0,
            "gross_margin_pct": 33.62,
        },
        "trend_36_month": demo_trend_df,
        "month_on_month_comparison": {
            "current_month": "2025-12-01",
            "previous_month": "2025-11-01",
            "current_values": {
                "revenue": 177000.0,
                "cost": 117500.0,
                "gross_profit": 59500.0,
                "gross_margin_pct": 33.62,
            },
            "previous_values": {
                "revenue": 174800.0,
                "cost": 116100.0,
                "gross_profit": 58700.0,
                "gross_margin_pct": 33.58,
            },
            "mom_revenue_growth_pct": 1.26,
        },
        "selected_month_customer_metrics": {
            "unique_domestic_customers": 1356,
            "active_commercial_customers": 81,
        },
    }

    demo_months = pd.date_range(start="2023-01-01", periods=36, freq="MS")

    app = QApplication(sys.argv)

    widget = CompanyWideDashboard(
        company_dashboard_bundle=demo_bundle,
        available_months=demo_months,
    )
    widget.resize(1380, 820)
    widget.month_changed.connect(print)
    widget.show()

    sys.exit(app.exec())
import sys
import importlib.util
from pathlib import Path

import pandas as pd
from PyQt6.QtWidgets import QApplication


base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load Nodes 1 to 5, Node 7, and Node 11
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py", "node4_financials")
node5 = load_module("05_monthly_analytics_engine.py", "node5_monthly")
node7 = load_module("07_dashboard_data_preparation.py", "node7_dashboard")
node11 = load_module("11_business_unit_dashboard.py",
                     "node11_business_unit_dashboard")


def build_mock_forecast_store():
    history_df = pd.DataFrame({
        "month": pd.to_datetime(["2019-07-01", "2019-08-01", "2019-09-01"]),
        "actual_value": [100.0, 120.0, 140.0],
        "model_value": [100.0, 120.0, 140.0],
    })

    test_predictions_df = pd.DataFrame({
        "month": pd.to_datetime(["2019-10-01", "2019-11-01", "2019-12-01"]),
        "actual_value": [150.0, 160.0, 170.0],
        "evaluation_actual": [150.0, 160.0, 170.0],
        "predicted_value": [148.0, 159.0, 171.0],
    })

    future_forecast_df = pd.DataFrame({
        "month": pd.to_datetime(["2020-01-01", "2020-02-01", "2020-03-01"]),
        "forecast_value": [172.0, 175.0, 178.0],
    })

    base_entry = {
        "history": history_df,
        "test_predictions": test_predictions_df,
        "future_forecast": future_forecast_df,
        "metrics": {
            "mae": 2.0,
            "rmse": 2.1602469,
        },
    }

    scopes = ["company", "commercial", "domestic", "cafe"]
    metrics = ["revenue", "cost", "gross_margin_pct"]
    models = ["linear_regression_lag3", "exponential_smoothing", "naive"]

    forecast_store = {}
    for scope in scopes:
        for metric in metrics:
            for model in models:
                forecast_store[(scope, metric, model)] = {
                    "history": base_entry["history"].copy(),
                    "test_predictions": base_entry["test_predictions"].copy(),
                    "future_forecast": base_entry["future_forecast"].copy(),
                    "metrics": dict(base_entry["metrics"]),
                }

    return forecast_store


print("\n=== RUNNING REAL PIPELINE FOR NODE 11 ===")

# Node 1
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("\nNode 1 failed. Dashboard cannot launch.")
    raise SystemExit(1)

# Node 2
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])
print("\n=== NODE 2 CLEANING RESULT ===")
for name, df in cleaned_data.items():
    print(f"{name}: {df.shape}")

# Node 3
unified_df = node3.merge_datasets(cleaned_data)
print("\n=== NODE 3 MERGE RESULT ===")
print("unified_df shape:", unified_df.shape)

# Node 4
enriched_df = node4.calculate_row_financials(unified_df)
print("\n=== NODE 4 FINANCIAL RESULT ===")
print("enriched_df shape:", enriched_df.shape)

# Node 5
analytics_store = node5.build_monthly_analytics(enriched_df)
print("\n=== NODE 5 MONTHLY ANALYTICS RESULT ===")
print("monthly_company shape:", analytics_store["monthly_company"].shape)
print("monthly_by_unit shape:", analytics_store["monthly_by_unit"].shape)
print("available_months:", len(analytics_store["available_months"]))

# Mock forecast store only because Node 7 requires it
forecast_store = build_mock_forecast_store()

available_months = analytics_store["available_months"]
initial_month = pd.Timestamp(available_months[-1]).strftime("%Y-%m-%d")

ui_state = {
    "selected_month": initial_month,
    "selected_business_unit": "Commercial",
    "selected_forecast_scope": "company",
    "selected_forecast_metric": "revenue",
    "selected_forecast_model": "naive",
}

dashboard_store = node7.prepare_dashboard_data(
    enriched_df=enriched_df,
    analytics_store=analytics_store,
    forecast_store=forecast_store,
    ui_state=ui_state,
)

print("\n=== NODE 7 DASHBOARD PREP RESULT ===")
print("dashboard keys:", list(dashboard_store.keys()))
print("business_unit dashboard keys:", list(
    dashboard_store["business_unit_dashboard"].keys()))

app = QApplication(sys.argv)

widget = node11.BusinessUnitDashboard(
    business_unit_dashboard_bundle=dashboard_store["business_unit_dashboard"],
    available_months=available_months,
)


def refresh_business_unit_dashboard():
    refreshed_dashboard_store = node7.prepare_dashboard_data(
        enriched_df=enriched_df,
        analytics_store=analytics_store,
        forecast_store=forecast_store,
        ui_state=ui_state,
    )

    widget.set_dashboard_data(
        refreshed_dashboard_store["business_unit_dashboard"])

    print("\n=== DASHBOARD UPDATED ===")
    print("Selected unit:", ui_state["selected_business_unit"])
    print("Selected month:", ui_state["selected_month"])
    print("Revenue:", widget.revenue_card.value_label.text())
    print("Cost:", widget.cost_card.value_label.text())
    print("Gross Profit:", widget.gross_profit_card.value_label.text())
    print("Gross Margin:", widget.gross_margin_card.value_label.text())


def on_business_unit_changed(selected_unit_str: str):
    ui_state["selected_business_unit"] = selected_unit_str
    refresh_business_unit_dashboard()


def on_month_changed(selected_month_str: str):
    ui_state["selected_month"] = selected_month_str
    refresh_business_unit_dashboard()


widget.business_unit_changed.connect(on_business_unit_changed)
widget.month_changed.connect(on_month_changed)

print("\n=== NODE 11 LAUNCHING ===")
print("Initial unit:", ui_state["selected_business_unit"])
print("Initial month:", ui_state["selected_month"])

widget.resize(1380, 820)
widget.show()

sys.exit(app.exec())

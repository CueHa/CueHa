from pprint import pprint
import importlib.util
from pathlib import Path

base_folder = Path(__file__).resolve().parent

# Load Node 1
validation_module_path = base_folder / "01_input_validation.py"
validation_spec = importlib.util.spec_from_file_location(
    "input_validation", validation_module_path)
validation_module = importlib.util.module_from_spec(validation_spec)
validation_spec.loader.exec_module(validation_module)

# Load Node 2
cleaning_module_path = base_folder / "02_data_cleaning_standardising.py"
cleaning_spec = importlib.util.spec_from_file_location(
    "data_cleaning_standardising", cleaning_module_path)
cleaning_module = importlib.util.module_from_spec(cleaning_spec)
cleaning_spec.loader.exec_module(cleaning_module)

# Step 1: validate input files
validation_result = validation_module.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("\nNode 1 failed, so Node 2 was not run.")
    raise SystemExit(1)

# Step 2: run Node 2
cleaned_result = cleaning_module.clean_and_standardise(
    validation_result["raw_data"])

print("\n=== NODE 2 CLEANING RESULT ===")
for name, df in cleaned_result.items():
    print(f"\n{name.upper()}")
    print("shape:", df.shape)
    print("columns:", list(df.columns))
    print("dtypes:")
    print(df.dtypes)
    print("\nhead:")
    print(df.head(3))

# Step 3: hard checks
expected_columns = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
]

print("\n=== HARD CHECKS ===")
all_ok = True

for name, df in cleaned_result.items():
    if list(df.columns) != expected_columns:
        all_ok = False
        print(f"{name}: FAIL, columns do not match expected unified schema")
    else:
        print(f"{name}: PASS, unified schema columns match")

    if str(df["date"].dtype).startswith("datetime64"):
        print(f"{name}: PASS, date parsed to datetime")
    else:
        all_ok = False
        print(f"{name}: FAIL, date is not datetime")

    numeric_columns = ["qty", "list_unit_price",
                       "discount_pct", "net_unit_price", "unit_cost"]
    for col in numeric_columns:
        if str(df[col].dtype) in ["int64", "float64", "Int64", "Float64"]:
            print(f"{name}: PASS, {col} is numeric")
        else:
            all_ok = False
            print(f"{name}: FAIL, {col} is not numeric")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 2 meets the minimum pass condition.")
else:
    print("FAIL: Node 2 does not meet the minimum pass condition.")

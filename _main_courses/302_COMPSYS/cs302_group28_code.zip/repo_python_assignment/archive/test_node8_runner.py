from PyQt6.QtWidgets import QApplication
from pathlib import Path
import importlib.util
import sys
import os
os.environ["QT_QPA_PLATFORM"] = "offscreen"


base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


node8 = load_module("08_pyqt_file_selection_screen.py", "node8_file_selection")

app = QApplication(sys.argv)

screen = node8.FileSelectionScreen()

results = {
    "failed_errors": None,
    "pipeline_package": None,
}


def on_failed(errors):
    results["failed_errors"] = errors


def on_ready(package):
    results["pipeline_package"] = package


screen.pipeline_failed.connect(on_failed)
screen.pipeline_ready.connect(on_ready)

all_ok = True

print("\n=== TEST 1: VALIDATION FAILURE PATH ===")
screen.row_commercial.set_path(str(base_folder / "DOES_NOT_EXIST.csv"))
screen.row_domestic.set_path(str(base_folder / "Data_Domestic.csv"))
screen.row_cafe.set_path(str(base_folder / "Data_Cafe.csv"))
screen._update_data_status()
screen._update_preview_paths_only()

screen._load_pipeline()
app.processEvents()

status_text = screen.status_text.toPlainText()

print("Status text:")
print(status_text)

if results["failed_errors"] is not None and len(results["failed_errors"]) > 0:
    print("PASS: pipeline_failed emitted readable validation errors")
else:
    all_ok = False
    print("FAIL: pipeline_failed did not emit validation errors")

if "Validation failed" in status_text or "does not exist" in status_text:
    print("PASS: status area shows useful validation error text")
else:
    all_ok = False
    print("FAIL: status area did not show useful validation error text")

# Reset capture state
results["failed_errors"] = None
results["pipeline_package"] = None

print("\n=== TEST 2: SUCCESS PATH ===")
screen.row_commercial.set_path(str(base_folder / "Data_Commercial.csv"))
screen.row_domestic.set_path(str(base_folder / "Data_Domestic.csv"))
screen.row_cafe.set_path(str(base_folder / "Data_Cafe.csv"))
screen._update_data_status()
screen._update_preview_paths_only()

screen._load_pipeline()
app.processEvents()

status_text = screen.status_text.toPlainText()
preview_text = screen.preview_text.toPlainText()

print("Status text:")
print(status_text)

print("\nPreview text:")
print(preview_text)

required_package_keys = [
    "raw_data",
    "cleaned_data",
    "unified_df",
    "enriched_df",
    "analytics_store",
    "forecast_store",
    "ui_state",
    "dashboard_store",
]

if results["pipeline_package"] is not None:
    print("PASS: pipeline_ready emitted a package")
else:
    all_ok = False
    print("FAIL: pipeline_ready did not emit a package")

if results["pipeline_package"] is not None:
    missing_keys = [
        key for key in required_package_keys
        if key not in results["pipeline_package"]
    ]
    if not missing_keys:
        print("PASS: pipeline package contains all expected keys")
    else:
        all_ok = False
        print("FAIL: pipeline package missing keys:", missing_keys)

if "Pipeline completed successfully." in status_text:
    print("PASS: status area shows successful pipeline completion")
else:
    all_ok = False
    print("FAIL: status area did not show successful completion")

if "Dataset successfully prepared." in preview_text:
    print("PASS: preview area shows success summary")
else:
    all_ok = False
    print("FAIL: preview area did not show success summary")

if results["pipeline_package"] is not None:
    ui_state = results["pipeline_package"]["ui_state"]

    expected_ui_keys = [
        "selected_month",
        "selected_business_unit",
        "selected_forecast_scope",
        "selected_forecast_metric",
        "selected_forecast_model",
    ]

    missing_ui_keys = [key for key in expected_ui_keys if key not in ui_state]
    if not missing_ui_keys:
        print("PASS: initial ui_state contains all required keys")
    else:
        all_ok = False
        print("FAIL: ui_state missing keys:", missing_ui_keys)

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 8 meets the minimum pass condition.")
else:
    print("FAIL: Node 8 does not meet the minimum pass condition.")

screen.close()
app.quit()

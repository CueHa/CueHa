import importlib.util
from pathlib import Path

base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load nodes
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")

# Step 1: validate raw files
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("Node 1 failed. Stopping.")
    raise SystemExit(1)

# Step 2: clean/standardise
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])

print("\n=== NODE 2 CLEANING RESULT ===")
for name, df in cleaned_data.items():
    print(f"{name}: shape = {df.shape}")

# Step 3: merge unified dataset
unified_df = node3.merge_datasets(cleaned_data)

print("\n=== NODE 3 MERGE RESULT ===")
print("unified shape:", unified_df.shape)
print("columns:", list(unified_df.columns))
print("index starts at:", unified_df.index.min())
print("index ends at:", unified_df.index.max())
print("\nhead:")
print(unified_df.head(5))

# Hard checks
expected_row_count = (
    len(cleaned_data["commercial"])
    + len(cleaned_data["domestic"])
    + len(cleaned_data["cafe"])
)

all_ok = True

print("\n=== HARD CHECKS ===")

if len(unified_df) == expected_row_count:
    print(f"PASS: row count matches expected total ({expected_row_count})")
else:
    all_ok = False
    print(
        f"FAIL: row count mismatch, expected {expected_row_count}, got {len(unified_df)}")

if list(unified_df.columns) == node3.UNIFIED_SCHEMA_COLUMNS:
    print("PASS: unified schema columns match exactly")
else:
    all_ok = False
    print("FAIL: unified schema columns do not match")

if list(unified_df.index) == list(range(len(unified_df))):
    print("PASS: index was reset correctly")
else:
    all_ok = False
    print("FAIL: index was not reset correctly")

sorted_check = unified_df.sort_values(
    by=["date", "business_unit", "source_row_id"],
    kind="mergesort"
).reset_index(drop=True)

if unified_df.equals(sorted_check):
    print("PASS: rows are sorted by date, business_unit, source_row_id")
else:
    all_ok = False
    print("FAIL: rows are not sorted as expected")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 3 meets the minimum pass condition.")
else:
    print("FAIL: Node 3 does not meet the minimum pass condition.")

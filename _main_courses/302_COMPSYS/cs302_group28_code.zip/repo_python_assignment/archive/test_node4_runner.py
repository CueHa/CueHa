import importlib.util
from pathlib import Path

base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load nodes
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py",
                    "node4_row_financials")

# Step 1: validate
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("Node 1 failed. Stopping.")
    raise SystemExit(1)

# Step 2: clean
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])

print("\n=== NODE 2 CLEANING RESULT ===")
for name, df in cleaned_data.items():
    print(f"{name}: shape = {df.shape}")

# Step 3: merge
unified_df = node3.merge_datasets(cleaned_data)

print("\n=== NODE 3 MERGE RESULT ===")
print("unified shape:", unified_df.shape)

# Step 4: row financial calculations
enriched_df = node4.calculate_row_financials(unified_df)

print("\n=== NODE 4 FINANCIAL RESULT ===")
print("enriched shape:", enriched_df.shape)
print("columns:", list(enriched_df.columns))

print("\nhead:")
print(enriched_df.head(5))

print("\nSelected financial columns:")
print(enriched_df[["qty", "net_unit_price", "unit_cost",
      "revenue", "cost", "gross_profit"]].head(5))

# Hard checks
all_ok = True

print("\n=== HARD CHECKS ===")

required_new_columns = ["revenue", "cost", "gross_profit"]
for col in required_new_columns:
    if col in enriched_df.columns:
        print(f"PASS: column '{col}' exists")
    else:
        all_ok = False
        print(f"FAIL: column '{col}' is missing")

if "gross_margin_pct" not in enriched_df.columns:
    print("PASS: gross_margin_pct was not added")
else:
    all_ok = False
    print("FAIL: gross_margin_pct should not exist")

# Spot-check first 3 rows manually by recomputing
for i in range(3):
    qty = enriched_df.loc[i, "qty"]
    net_unit_price = enriched_df.loc[i, "net_unit_price"]
    unit_cost = enriched_df.loc[i, "unit_cost"]

    expected_revenue = qty * net_unit_price
    expected_cost = qty * unit_cost
    expected_gross_profit = expected_revenue - expected_cost

    actual_revenue = enriched_df.loc[i, "revenue"]
    actual_cost = enriched_df.loc[i, "cost"]
    actual_gross_profit = enriched_df.loc[i, "gross_profit"]

    if actual_revenue == expected_revenue:
        print(f"PASS: row {i} revenue correct")
    else:
        all_ok = False
        print(f"FAIL: row {i} revenue incorrect")

    if actual_cost == expected_cost:
        print(f"PASS: row {i} cost correct")
    else:
        all_ok = False
        print(f"FAIL: row {i} cost incorrect")

    if actual_gross_profit == expected_gross_profit:
        print(f"PASS: row {i} gross_profit correct")
    else:
        all_ok = False
        print(f"FAIL: row {i} gross_profit incorrect")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 4 meets the minimum pass condition.")
else:
    print("FAIL: Node 4 does not meet the minimum pass condition.")

import importlib.util
from pathlib import Path
import numpy as np
import pandas as pd

base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def floats_match(a, b, atol=1e-6):
    return np.isclose(a, b, rtol=0, atol=atol, equal_nan=True)


# Load nodes
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py", "node4_financials")
node5 = load_module("05_monthly_analytics_engine.py", "node5_monthly")

# Step 1: validate
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("Node 1 failed. Stopping.")
    raise SystemExit(1)

# Step 2: clean
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])

# Step 3: merge
unified_df = node3.merge_datasets(cleaned_data)

# Step 4: row financials
enriched_df = node4.calculate_row_financials(unified_df)

# Step 5: monthly analytics
monthly_result = node5.build_monthly_analytics(enriched_df)

monthly_company = monthly_result["monthly_company"]
monthly_by_unit = monthly_result["monthly_by_unit"]
monthly_cafe_location = monthly_result["monthly_cafe_location"]
available_months = monthly_result["available_months"]

print("\n=== NODE 5 MONTHLY RESULT ===")
print("monthly_company shape:", monthly_company.shape)
print("monthly_by_unit shape:", monthly_by_unit.shape)
print("monthly_cafe_location shape:", monthly_cafe_location.shape)
print("available_months count:", len(available_months))

print("\nmonthly_company head:")
print(monthly_company.head(5))

print("\nmonthly_by_unit head:")
print(monthly_by_unit.head(5))

print("\nmonthly_cafe_location head:")
print(monthly_cafe_location.head(5))

all_ok = True

print("\n=== HARD CHECKS ===")

# Check required keys
required_keys = [
    "monthly_company",
    "monthly_by_unit",
    "monthly_cafe_location",
    "available_months",
]

for key in required_keys:
    if key in monthly_result:
        print(f"PASS: '{key}' returned")
    else:
        all_ok = False
        print(f"FAIL: '{key}' missing")

# Check monthly_company columns
expected_monthly_company_cols = [
    "month",
    "revenue",
    "cost",
    "gross_profit",
    "gross_margin_pct",
    "unique_domestic_customers",
    "active_commercial_customers",
    "mom_revenue_growth_pct",
]
if list(monthly_company.columns) == expected_monthly_company_cols:
    print("PASS: monthly_company columns correct")
else:
    all_ok = False
    print("FAIL: monthly_company columns incorrect")

# Check monthly_by_unit columns
expected_monthly_by_unit_cols = [
    "month",
    "business_unit",
    "revenue",
    "cost",
    "gross_profit",
    "gross_margin_pct",
]
if list(monthly_by_unit.columns) == expected_monthly_by_unit_cols:
    print("PASS: monthly_by_unit columns correct")
else:
    all_ok = False
    print("FAIL: monthly_by_unit columns incorrect")

# Check monthly_cafe_location columns
expected_monthly_cafe_cols = [
    "month",
    "cafe_location",
    "revenue",
    "cost",
    "gross_profit",
    "gross_margin_pct",
]
if list(monthly_cafe_location.columns) == expected_monthly_cafe_cols:
    print("PASS: monthly_cafe_location columns correct")
else:
    all_ok = False
    print("FAIL: monthly_cafe_location columns incorrect")

# Check available_months consistency
if available_months == monthly_company["month"].tolist():
    print("PASS: available_months matches monthly_company month list")
else:
    all_ok = False
    print("FAIL: available_months does not match monthly_company month list")

# Check infinities are not present
company_numeric_cols = ["revenue", "cost", "gross_profit",
                        "gross_margin_pct", "mom_revenue_growth_pct"]
for col in company_numeric_cols:
    if np.isinf(monthly_company[col].to_numpy(dtype="float64", na_value=np.nan)).any():
        all_ok = False
        print(f"FAIL: monthly_company['{col}'] contains infinity")
    else:
        print(f"PASS: monthly_company['{col}'] does not contain infinity")

# Manual check for one month
test_month = monthly_company.loc[0, "month"]
month_key = enriched_df["date"].dt.to_period("M").dt.to_timestamp()
month_rows = enriched_df[month_key == test_month].copy()

manual_revenue = month_rows["revenue"].sum()
manual_cost = month_rows["cost"].sum()
manual_gross_profit_from_rows = month_rows["gross_profit"].sum()
manual_gross_profit_from_difference = manual_revenue - manual_cost

company_row = monthly_company[monthly_company["month"] == test_month].iloc[0]

print(f"\n=== MANUAL CHECK FOR {test_month.date()} ===")
print("manual_revenue:", manual_revenue)
print("table_revenue: ", company_row["revenue"])
print("manual_cost:   ", manual_cost)
print("table_cost:    ", company_row["cost"])
print("manual_gp_sum: ", manual_gross_profit_from_rows)
print("manual_gp_diff:", manual_gross_profit_from_difference)
print("table_gp:      ", company_row["gross_profit"])

if floats_match(company_row["revenue"], manual_revenue):
    print(f"PASS: manual revenue check passed for {test_month.date()}")
else:
    all_ok = False
    print(f"FAIL: manual revenue check failed for {test_month.date()}")

if floats_match(company_row["cost"], manual_cost):
    print(f"PASS: manual cost check passed for {test_month.date()}")
else:
    all_ok = False
    print(f"FAIL: manual cost check failed for {test_month.date()}")

# Accept either valid gross profit identity:
# 1. aggregated row gross_profit sum
# 2. aggregated revenue - aggregated cost
gp_matches_row_sum = floats_match(
    company_row["gross_profit"], manual_gross_profit_from_rows)
gp_matches_difference = floats_match(
    company_row["gross_profit"], manual_gross_profit_from_difference)

if gp_matches_row_sum or gp_matches_difference:
    print(f"PASS: manual gross_profit check passed for {test_month.date()}")
else:
    all_ok = False
    print(f"FAIL: manual gross_profit check failed for {test_month.date()}")

# Check company gross_margin_pct formula safely
if company_row["revenue"] == 0:
    if pd.isna(company_row["gross_margin_pct"]):
        print(
            f"PASS: gross_margin_pct is NaN when revenue is zero for {test_month.date()}")
    else:
        all_ok = False
        print(
            f"FAIL: gross_margin_pct should be NaN when revenue is zero for {test_month.date()}")
else:
    expected_margin = (
        company_row["gross_profit"] / company_row["revenue"]) * 100
    if floats_match(company_row["gross_margin_pct"], expected_margin):
        print(
            f"PASS: gross_margin_pct formula correct for {test_month.date()}")
    else:
        all_ok = False
        print(
            f"FAIL: gross_margin_pct formula incorrect for {test_month.date()}")

# Check first month MoM is NaN
first_mom = monthly_company.loc[0, "mom_revenue_growth_pct"]
if pd.isna(first_mom):
    print("PASS: first month mom_revenue_growth_pct is NaN")
else:
    all_ok = False
    print("FAIL: first month mom_revenue_growth_pct should be NaN")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 5 meets the minimum pass condition.")
else:
    print("FAIL: Node 5 does not meet the minimum pass condition.")

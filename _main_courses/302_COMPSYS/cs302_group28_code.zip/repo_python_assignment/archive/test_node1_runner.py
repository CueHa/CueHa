from pprint import pprint
import importlib.util
from pathlib import Path

base_folder = Path(__file__).resolve().parent
module_path = base_folder / "01_input_validation.py"

spec = importlib.util.spec_from_file_location("input_validation", module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

result = module.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== VALIDATION RESULT ===")
pprint(result)

print("\n=== SUMMARY ===")
print("ok:", result["ok"])
print("errors:", result["errors"])

if result["ok"]:
    print("\nCommercial shape:", result["raw_data"]["commercial"].shape)
    print("Domestic shape:", result["raw_data"]["domestic"].shape)
    print("Cafe shape:", result["raw_data"]["cafe"].shape)

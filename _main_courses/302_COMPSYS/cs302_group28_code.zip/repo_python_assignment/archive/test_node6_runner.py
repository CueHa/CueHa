import importlib.util
from pathlib import Path
import math
import numpy as np
import pandas as pd

base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def is_finite_number(value):
    return isinstance(value, (int, float, np.floating)) and math.isfinite(float(value))


# Load nodes
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py", "node4_financials")
node5 = load_module("05_monthly_analytics_engine.py", "node5_monthly")
node6 = load_module("06_forecasting_engine.py", "node6_forecasting")

# Step 1: validate raw files
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("Node 1 failed. Stopping.")
    raise SystemExit(1)

# Step 2: clean
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])

# Step 3: merge
unified_df = node3.merge_datasets(cleaned_data)

# Step 4: row financials
enriched_df = node4.calculate_row_financials(unified_df)

# Step 5: monthly analytics
analytics_store = node5.build_monthly_analytics(enriched_df)

# Step 6: build forecast store
models = ["linear_regression_lag3", "exponential_smoothing", "naive"]
forecast_store = node6.build_forecast_store(
    analytics_store=analytics_store,
    models=models,
    horizon=3,
)

print("\n=== NODE 6 FORECAST STORE RESULT ===")
print("total forecast entries:", len(forecast_store))

expected_entry_count = 4 * 3 * 3
print("expected entries:", expected_entry_count)

# Show one sample per model for company revenue
sample_keys = [
    ("company", "revenue", "naive"),
    ("company", "revenue", "linear_regression_lag3"),
    ("company", "revenue", "exponential_smoothing"),
]

for key in sample_keys:
    entry = forecast_store[key]
    print(f"\n=== SAMPLE ENTRY {key} ===")
    print("history length:", len(entry["history"]))
    print("test_predictions length:", len(entry["test_predictions"]))
    print("future_forecast length:", len(entry["future_forecast"]))
    print("metrics:", entry["metrics"])
    print("\ntest_predictions:")
    print(entry["test_predictions"])
    print("\nfuture_forecast:")
    print(entry["future_forecast"])

all_ok = True

print("\n=== HARD CHECKS ===")

# Check total number of entries
if len(forecast_store) == expected_entry_count:
    print(f"PASS: forecast_store contains {expected_entry_count} entries")
else:
    all_ok = False
    print(
        f"FAIL: forecast_store should contain {expected_entry_count} entries, got {len(forecast_store)}")

required_scopes = ["company", "commercial", "domestic", "cafe"]
required_metrics = ["revenue", "cost", "gross_margin_pct"]
required_models = ["linear_regression_lag3", "exponential_smoothing", "naive"]

# Check every required key exists
for scope in required_scopes:
    for metric in required_metrics:
        for model_name in required_models:
            key = (scope, metric, model_name)
            if key in forecast_store:
                print(f"PASS: key exists {key}")
            else:
                all_ok = False
                print(f"FAIL: missing key {key}")

# Minimum pass condition, company revenue for all three models
for model_name in required_models:
    key = ("company", "revenue", model_name)
    entry = forecast_store[key]

    history_df = entry["history"]
    test_predictions_df = entry["test_predictions"]
    future_forecast_df = entry["future_forecast"]
    metrics = entry["metrics"]

    if len(test_predictions_df) == 3:
        print(f"PASS: {key} has 3 test predictions")
    else:
        all_ok = False
        print(
            f"FAIL: {key} should have 3 test predictions, got {len(test_predictions_df)}")

    if len(future_forecast_df) == 3:
        print(f"PASS: {key} has 3 future forecast months")
    else:
        all_ok = False
        print(
            f"FAIL: {key} should have 3 future forecast months, got {len(future_forecast_df)}")

    if "mae" in metrics and "rmse" in metrics:
        print(f"PASS: {key} metrics contain mae and rmse")
    else:
        all_ok = False
        print(f"FAIL: {key} metrics missing mae and/or rmse")

    if "mae" in metrics and is_finite_number(metrics["mae"]):
        print(f"PASS: {key} mae is finite")
    else:
        all_ok = False
        print(f"FAIL: {key} mae is not finite")

    if "rmse" in metrics and is_finite_number(metrics["rmse"]):
        print(f"PASS: {key} rmse is finite")
    else:
        all_ok = False
        print(f"FAIL: {key} rmse is not finite")

    expected_history_cols = ["month", "actual_value", "model_value"]
    if list(history_df.columns) == expected_history_cols:
        print(f"PASS: {key} history columns correct")
    else:
        all_ok = False
        print(f"FAIL: {key} history columns incorrect")

    expected_test_cols = ["month", "actual_value",
                          "evaluation_actual", "predicted_value"]
    if list(test_predictions_df.columns) == expected_test_cols:
        print(f"PASS: {key} test_predictions columns correct")
    else:
        all_ok = False
        print(f"FAIL: {key} test_predictions columns incorrect")

    expected_future_cols = ["month", "forecast_value"]
    if list(future_forecast_df.columns) == expected_future_cols:
        print(f"PASS: {key} future_forecast columns correct")
    else:
        all_ok = False
        print(f"FAIL: {key} future_forecast columns incorrect")

# Basic month continuity check on one sample
sample_entry = forecast_store[("company", "revenue", "naive")]
future_months = pd.to_datetime(
    sample_entry["future_forecast"]["month"]).reset_index(drop=True)

if len(future_months) == 3:
    delta_1 = future_months.iloc[1] - future_months.iloc[0]
    delta_2 = future_months.iloc[2] - future_months.iloc[1]

    if delta_1.days in [28, 29, 30, 31] and delta_2.days in [28, 29, 30, 31]:
        print("PASS: future forecast months move forward monthly")
    else:
        all_ok = False
        print("FAIL: future forecast months are not monthly")
else:
    all_ok = False
    print("FAIL: could not verify future month continuity")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 6 meets the minimum pass condition.")
else:
    print("FAIL: Node 6 does not meet the minimum pass condition.")

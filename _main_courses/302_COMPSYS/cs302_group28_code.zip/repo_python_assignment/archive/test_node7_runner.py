import importlib.util
from pathlib import Path
import pandas as pd

base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load nodes
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py", "node4_financials")
node5 = load_module("05_monthly_analytics_engine.py", "node5_monthly")
node6 = load_module("06_forecasting_engine.py", "node6_forecasting")
node7 = load_module("07_dashboard_data_preparation.py", "node7_dashboard")

# Step 1: validate
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("Node 1 failed. Stopping.")
    raise SystemExit(1)

# Step 2: clean
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])

# Step 3: merge
unified_df = node3.merge_datasets(cleaned_data)

# Step 4: row financials
enriched_df = node4.calculate_row_financials(unified_df)

# Step 5: monthly analytics
analytics_store = node5.build_monthly_analytics(enriched_df)

# Step 6: forecasts
forecast_store = node6.build_forecast_store(
    analytics_store=analytics_store,
    models=["linear_regression_lag3", "exponential_smoothing", "naive"],
    horizon=3,
)

# Step 7: dashboard data prep
ui_state = {
    "selected_month": "2019-08-01",
    "selected_business_unit": "Commercial",
    "selected_forecast_scope": "company",
    "selected_forecast_metric": "revenue",
    "selected_forecast_model": "naive",
}

dashboard_store = node7.prepare_dashboard_data(
    enriched_df=enriched_df,
    analytics_store=analytics_store,
    forecast_store=forecast_store,
    ui_state=ui_state,
)

print("\n=== NODE 7 DASHBOARD STORE RESULT ===")
print("top-level keys:", list(dashboard_store.keys()))

company_dashboard = dashboard_store["company_dashboard"]
business_unit_dashboard = dashboard_store["business_unit_dashboard"]
forecast_dashboard = dashboard_store["forecast_dashboard"]

print("\n=== COMPANY DASHBOARD KEYS ===")
print(list(company_dashboard.keys()))

print("\n=== BUSINESS UNIT DASHBOARD KEYS ===")
print(list(business_unit_dashboard.keys()))

print("\n=== FORECAST DASHBOARD KEYS ===")
print(list(forecast_dashboard.keys()))

all_ok = True

print("\n=== HARD CHECKS ===")

# Top-level bundle existence
required_top_keys = [
    "company_dashboard",
    "business_unit_dashboard",
    "forecast_dashboard",
]
for key in required_top_keys:
    if key in dashboard_store:
        print(f"PASS: '{key}' exists")
    else:
        all_ok = False
        print(f"FAIL: '{key}' missing")

# Company dashboard structure
required_company_keys = [
    "selected_month",
    "selected_month_kpis",
    "trend_36_month",
    "month_on_month_comparison",
    "selected_month_customer_metrics",
]
for key in required_company_keys:
    if key in company_dashboard:
        print(f"PASS: company_dashboard['{key}'] exists")
    else:
        all_ok = False
        print(f"FAIL: company_dashboard['{key}'] missing")

# Business unit dashboard structure
required_business_keys = [
    "selected_business_unit",
    "selected_month",
    "selected_month_kpis",
    "monthly_trend",
    "unit_summary",
]
for key in required_business_keys:
    if key in business_unit_dashboard:
        print(f"PASS: business_unit_dashboard['{key}'] exists")
    else:
        all_ok = False
        print(f"FAIL: business_unit_dashboard['{key}'] missing")

# Forecast dashboard structure
required_forecast_keys = [
    "selected_scope",
    "selected_metric",
    "selected_model",
    "history",
    "test_predictions",
    "future_forecast",
    "displayed_error_metrics",
]
for key in required_forecast_keys:
    if key in forecast_dashboard:
        print(f"PASS: forecast_dashboard['{key}'] exists")
    else:
        all_ok = False
        print(f"FAIL: forecast_dashboard['{key}'] missing")

# Company dashboard selected month sanity
company_month = pd.Timestamp(
    company_dashboard["selected_month"]).to_period("M").to_timestamp()
if company_month == pd.Timestamp("2019-08-01"):
    print("PASS: company_dashboard selected month resolved correctly")
else:
    all_ok = False
    print("FAIL: company_dashboard selected month incorrect")

# Business unit selected unit sanity
if business_unit_dashboard["selected_business_unit"] == "Commercial":
    print("PASS: business_unit_dashboard selected business unit correct")
else:
    all_ok = False
    print("FAIL: business_unit_dashboard selected business unit incorrect")

# Forecast dashboard selection sanity
if forecast_dashboard["selected_scope"] == "company":
    print("PASS: forecast_dashboard selected scope correct")
else:
    all_ok = False
    print("FAIL: forecast_dashboard selected scope incorrect")

if forecast_dashboard["selected_metric"] == "revenue":
    print("PASS: forecast_dashboard selected metric correct")
else:
    all_ok = False
    print("FAIL: forecast_dashboard selected metric incorrect")

if forecast_dashboard["selected_model"] == "naive":
    print("PASS: forecast_dashboard selected model correct")
else:
    all_ok = False
    print("FAIL: forecast_dashboard selected model incorrect")

# Forecast dashboard payload sanity
if len(forecast_dashboard["history"]) >= 36:
    print("PASS: forecast history exists and has expected length")
else:
    all_ok = False
    print("FAIL: forecast history too short")

if len(forecast_dashboard["test_predictions"]) == 3:
    print("PASS: forecast test_predictions has 3 rows")
else:
    all_ok = False
    print("FAIL: forecast test_predictions should have 3 rows")

if len(forecast_dashboard["future_forecast"]) == 3:
    print("PASS: forecast future_forecast has 3 rows")
else:
    all_ok = False
    print("FAIL: forecast future_forecast should have 3 rows")

error_metrics = forecast_dashboard["displayed_error_metrics"]
if "mae" in error_metrics and "rmse" in error_metrics:
    print("PASS: displayed_error_metrics contains mae and rmse")
else:
    all_ok = False
    print("FAIL: displayed_error_metrics missing mae and/or rmse")

print("\n=== FINAL VERDICT ===")
if all_ok:
    print("PASS: Node 7 meets the minimum pass condition.")
else:
    print("FAIL: Node 7 does not meet the minimum pass condition.")

import sys
import importlib.util
from pathlib import Path

from PyQt6.QtWidgets import QApplication


base_folder = Path(__file__).resolve().parent


def load_module(filename: str, module_name: str):
    module_path = base_folder / filename
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load Nodes 1 to 7 and Node 12
node1 = load_module("01_input_validation.py", "node1_validation")
node2 = load_module("02_data_cleaning_standardising.py", "node2_cleaning")
node3 = load_module("03_merge_unified_dataset.py", "node3_merge")
node4 = load_module("04_per_row_financial_calculations.py", "node4_financials")
node5 = load_module("05_monthly_analytics_engine.py", "node5_monthly")
node6 = load_module("06_forecasting_engine.py", "node6_forecasting")
node7 = load_module("07_dashboard_data_preparation.py", "node7_dashboard")
node12 = load_module("12_forecast_dashboard.py", "node12_forecast_dashboard")


print("\n=== RUNNING REAL PIPELINE FOR NODE 12 ===")

# Node 1
validation_result = node1.validate_input_files(
    commercial_path=str(base_folder / "Data_Commercial.csv"),
    domestic_path=str(base_folder / "Data_Domestic.csv"),
    cafe_path=str(base_folder / "Data_Cafe.csv"),
)

print("\n=== NODE 1 VALIDATION RESULT ===")
print("ok:", validation_result["ok"])
print("errors:", validation_result["errors"])

if not validation_result["ok"]:
    print("\nNode 1 failed. Dashboard cannot launch.")
    raise SystemExit(1)

# Node 2
cleaned_data = node2.clean_and_standardise(validation_result["raw_data"])
print("\n=== NODE 2 CLEANING RESULT ===")
for name, df in cleaned_data.items():
    print(f"{name}: {df.shape}")

# Node 3
unified_df = node3.merge_datasets(cleaned_data)
print("\n=== NODE 3 MERGE RESULT ===")
print("unified_df shape:", unified_df.shape)

# Node 4
enriched_df = node4.calculate_row_financials(unified_df)
print("\n=== NODE 4 FINANCIAL RESULT ===")
print("enriched_df shape:", enriched_df.shape)

# Node 5
analytics_store = node5.build_monthly_analytics(enriched_df)
print("\n=== NODE 5 MONTHLY ANALYTICS RESULT ===")
print("monthly_company shape:", analytics_store["monthly_company"].shape)
print("monthly_by_unit shape:", analytics_store["monthly_by_unit"].shape)
print("available_months:", len(analytics_store["available_months"]))

# Node 6
forecast_store = node6.build_forecast_store(
    analytics_store=analytics_store,
    models=["linear_regression_lag3", "exponential_smoothing", "naive"],
    horizon=3,
)
print("\n=== NODE 6 FORECAST RESULT ===")
print("forecast entries:", len(forecast_store))

# Initial UI state for Node 7
ui_state = {
    "selected_month": str(analytics_store["available_months"][-1]),
    "selected_business_unit": "Commercial",
    "selected_forecast_scope": "company",
    "selected_forecast_metric": "revenue",
    "selected_forecast_model": "naive",
}

dashboard_store = node7.prepare_dashboard_data(
    enriched_df=enriched_df,
    analytics_store=analytics_store,
    forecast_store=forecast_store,
    ui_state=ui_state,
)

print("\n=== NODE 7 DASHBOARD PREP RESULT ===")
print("dashboard keys:", list(dashboard_store.keys()))
print("forecast dashboard keys:", list(
    dashboard_store["forecast_dashboard"].keys()))

app = QApplication(sys.argv)

widget = node12.ForecastDashboard(
    forecast_dashboard_bundle=dashboard_store["forecast_dashboard"]
)


def refresh_forecast_dashboard():
    refreshed_dashboard_store = node7.prepare_dashboard_data(
        enriched_df=enriched_df,
        analytics_store=analytics_store,
        forecast_store=forecast_store,
        ui_state=ui_state,
    )

    widget.set_dashboard_data(refreshed_dashboard_store["forecast_dashboard"])

    print("\n=== DASHBOARD UPDATED ===")
    print("Selected scope:", ui_state["selected_forecast_scope"])
    print("Selected metric:", ui_state["selected_forecast_metric"])
    print("Selected model:", ui_state["selected_forecast_model"])
    print("Scope card:", widget.scope_card.value_label.text())
    print("Metric card:", widget.metric_card.value_label.text())
    print("Model card:", widget.model_card.value_label.text())
    print("MAE:", widget.mae_card.value_label.text())
    print("RMSE:", widget.rmse_card.value_label.text())


def on_scope_changed(selected_scope_str: str):
    ui_state["selected_forecast_scope"] = selected_scope_str
    refresh_forecast_dashboard()


def on_metric_changed(selected_metric_str: str):
    ui_state["selected_forecast_metric"] = selected_metric_str
    refresh_forecast_dashboard()


def on_model_changed(selected_model_str: str):
    ui_state["selected_forecast_model"] = selected_model_str
    refresh_forecast_dashboard()


widget.scope_changed.connect(on_scope_changed)
widget.metric_changed.connect(on_metric_changed)
widget.model_changed.connect(on_model_changed)

print("\n=== NODE 12 LAUNCHING ===")
print("Initial scope:", ui_state["selected_forecast_scope"])
print("Initial metric:", ui_state["selected_forecast_metric"])
print("Initial model:", ui_state["selected_forecast_model"])

widget.resize(1450, 900)
widget.show()

sys.exit(app.exec())

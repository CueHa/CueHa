import pandas as pd


REQUIRED_INPUT_COLUMNS = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
]


def calculate_row_financials(unified_df: pd.DataFrame) -> pd.DataFrame:
    """
    Add row-level financial columns required for downstream analytics.

    Input:
        unified_df

    Returns:
        enriched_df
    """
    _validate_input(unified_df)

    enriched_df = unified_df.copy(deep=True)

    enriched_df["revenue"] = enriched_df["qty"] * enriched_df["net_unit_price"]
    enriched_df["cost"] = enriched_df["qty"] * enriched_df["unit_cost"]
    enriched_df["gross_profit"] = enriched_df["revenue"] - enriched_df["cost"]

    return enriched_df


def _validate_input(unified_df: pd.DataFrame) -> None:
    if not isinstance(unified_df, pd.DataFrame):
        raise ValueError("unified_df must be a pandas DataFrame.")

    actual_columns = list(unified_df.columns)
    if actual_columns != REQUIRED_INPUT_COLUMNS:
        raise ValueError(
            "unified_df does not match the expected unified schema.\n"
            f"Expected: {REQUIRED_INPUT_COLUMNS}\n"
            f"Actual:   {actual_columns}"
        )

    required_numeric_columns = ["qty", "net_unit_price", "unit_cost"]

    for column_name in required_numeric_columns:
        if not pd.api.types.is_numeric_dtype(unified_df[column_name]):
            raise ValueError(
                f"Column '{column_name}' must be numeric before row financial calculations."
            )

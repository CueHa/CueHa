import pandas as pd


UNIFIED_SCHEMA_COLUMNS = [
    "source_unit",
    "source_row_id",
    "transaction_id",
    "date",
    "business_unit",
    "customer_id",
    "salesperson_id",
    "segment",
    "cafe_location",
    "sku",
    "qty",
    "list_unit_price",
    "discount_pct",
    "net_unit_price",
    "unit_cost",
]


def merge_datasets(cleaned_data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """
    Concatenate the three cleaned datasets into one canonical unified dataset.

    Expected input:
    {
        "commercial": cleaned_commercial_df,
        "domestic": cleaned_domestic_df,
        "cafe": cleaned_cafe_df
    }

    Returns:
        unified_df
    """
    _validate_cleaned_input(cleaned_data)

    commercial_df = cleaned_data["commercial"][UNIFIED_SCHEMA_COLUMNS].copy()
    domestic_df = cleaned_data["domestic"][UNIFIED_SCHEMA_COLUMNS].copy()
    cafe_df = cleaned_data["cafe"][UNIFIED_SCHEMA_COLUMNS].copy()

    expected_row_count = len(commercial_df) + len(domestic_df) + len(cafe_df)

    unified_df = pd.concat(
        [commercial_df, domestic_df, cafe_df],
        axis=0,
        ignore_index=True
    )

    unified_df = unified_df.sort_values(
        by=["date", "business_unit", "source_row_id"],
        kind="mergesort"
    ).reset_index(drop=True)

    actual_row_count = len(unified_df)
    if actual_row_count != expected_row_count:
        raise ValueError(
            f"Row count mismatch after merge. Expected {expected_row_count}, "
            f"got {actual_row_count}."
        )

    return unified_df


def _validate_cleaned_input(cleaned_data: dict[str, pd.DataFrame]) -> None:
    """
    Minimal validation to ensure Node 3 receives the expected cleaned structure.
    """
    required_keys = ["commercial", "domestic", "cafe"]

    for key in required_keys:
        if key not in cleaned_data:
            raise ValueError(f"Missing cleaned dataset: '{key}'")

        if not isinstance(cleaned_data[key], pd.DataFrame):
            raise ValueError(
                f"cleaned_data['{key}'] is not a pandas DataFrame")

        actual_columns = list(cleaned_data[key].columns)
        if actual_columns != UNIFIED_SCHEMA_COLUMNS:
            raise ValueError(
                f"cleaned_data['{key}'] does not match the unified schema.\n"
                f"Expected: {UNIFIED_SCHEMA_COLUMNS}\n"
                f"Actual:   {actual_columns}"
            )

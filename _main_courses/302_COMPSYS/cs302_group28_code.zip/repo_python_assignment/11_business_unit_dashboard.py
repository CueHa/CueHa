from typing import Optional, Sequence

import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


VALID_BUSINESS_UNITS = ["Commercial", "Domestic", "Cafe"]


class StatusBadge(QLabel):
    def __init__(self, text: str, bg_color: str, text_color: str = "#1f2937"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(28)
        self.set_badge_style(text, bg_color, text_color)

    def set_badge_style(self, text: str, bg_color: str, text_color: str = "#1f2937") -> None:
        self.setText(text)
        self.setStyleSheet(
            f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border: 1px solid #d1d5db;
                border-radius: 12px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }}
            """
        )


class SingleKPICard(QFrame):
    def __init__(self, title: str, subtitle: str = ""):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        self.title_label = QLabel(title)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet(
            "font-size: 12px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(self.title_label)

        self.value_label = QLabel("N/A")
        self.value_label.setStyleSheet(
            "font-size: 22px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(self.value_label)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setStyleSheet(
            "font-size: 11px; color: #6b7280;"
        )
        layout.addWidget(self.subtitle_label)

        layout.addStretch()

    def set_value(self, value_text: str, subtitle_text: Optional[str] = None) -> None:
        self.value_label.setText(value_text)
        if subtitle_text is not None:
            self.subtitle_label.setText(subtitle_text)


class BusinessUnitTrendCanvas(FigureCanvas):
    def __init__(self, parent: Optional[QWidget] = None):
        self.figure = Figure(figsize=(7, 4), tight_layout=True)
        self.axes = self.figure.add_subplot(111)
        super().__init__(self.figure)
        self.setParent(parent)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )

    def plot_unit_trend(self, trend_df: pd.DataFrame, business_unit: str) -> None:
        self.axes.clear()

        if trend_df is None or trend_df.empty:
            self.axes.text(
                0.5,
                0.5,
                "No trend data available",
                ha="center",
                va="center",
                transform=self.axes.transAxes,
            )
            self.axes.set_xticks([])
            self.axes.set_yticks([])
            self.draw()
            return

        working_df = trend_df.copy()
        working_df["month"] = pd.to_datetime(working_df["month"])
        working_df = working_df.sort_values("month")

        self.axes.plot(
            working_df["month"],
            working_df["revenue"],
            label="Revenue",
            linewidth=2.4,
            color="#2563eb",
        )
        self.axes.plot(
            working_df["month"],
            working_df["cost"],
            label="Cost",
            linewidth=2.4,
            color="#ef4444",
        )
        self.axes.plot(
            working_df["month"],
            working_df["gross_profit"],
            label="Gross Profit",
            linewidth=2.4,
            color="#0f766e",
        )

        self.axes.set_title(f"{business_unit} Performance Over Time")
        self.axes.set_xlabel("Month")
        self.axes.set_ylabel("Value")
        self.axes.set_facecolor("#f8fafc")
        self.axes.grid(True, alpha=0.25)
        self.axes.legend()

        for spine in self.axes.spines.values():
            spine.set_color("#d1d5db")

        self.figure.autofmt_xdate()
        self.draw()


class CafeLocationBreakdownPanel(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        self.layout_root = QVBoxLayout(self)
        self.layout_root.setContentsMargins(16, 14, 16, 14)
        self.layout_root.setSpacing(10)

        self.title_label = QLabel("Cafe Location Breakdown")
        self.title_label.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;"
        )
        self.layout_root.addWidget(self.title_label)

        self.body_container = QWidget()
        self.body_layout = QVBoxLayout(self.body_container)
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(8)

        self.layout_root.addWidget(self.body_container)

        self.placeholder_label = QLabel(
            "No cafe location breakdown available."
        )
        self.placeholder_label.setWordWrap(True)
        self.placeholder_label.setStyleSheet(
            "font-size: 12px; color: #6b7280;"
        )
        self.body_layout.addWidget(self.placeholder_label)

    def set_breakdown(self, breakdown_df: Optional[pd.DataFrame]) -> None:
        self._clear_body()

        if breakdown_df is None or breakdown_df.empty:
            self.placeholder_label = QLabel(
                "No cafe location breakdown available."
            )
            self.placeholder_label.setWordWrap(True)
            self.placeholder_label.setStyleSheet(
                "font-size: 12px; color: #6b7280;"
            )
            self.body_layout.addWidget(self.placeholder_label)
            return

        for _, row in breakdown_df.iterrows():
            row_widget = QWidget()
            row_layout = QVBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(2)

            location_label = QLabel(str(row["cafe_location"]))
            location_label.setStyleSheet(
                "font-size: 12px; font-weight: 700; color: #111827;"
            )

            metrics_label = QLabel(
                f"Revenue: {self._format_currency(row.get('revenue'))} | "
                f"Cost: {self._format_currency(row.get('cost'))} | "
                f"Gross Profit: {self._format_currency(row.get('gross_profit'))} | "
                f"Gross Margin: {self._format_percentage(row.get('gross_margin_pct'))}"
            )
            metrics_label.setWordWrap(True)
            metrics_label.setStyleSheet(
                "font-size: 11px; color: #4b5563;"
            )

            row_layout.addWidget(location_label)
            row_layout.addWidget(metrics_label)

            self.body_layout.addWidget(row_widget)

    def _clear_body(self) -> None:
        while self.body_layout.count():
            item = self.body_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _format_currency(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"${value:,.2f}"

    def _format_percentage(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"{value:.2f}%"


class BusinessUnitDashboard(QWidget):
    business_unit_changed = pyqtSignal(str)
    month_changed = pyqtSignal(str)

    def __init__(
        self,
        business_unit_dashboard_bundle: Optional[dict] = None,
        available_months: Optional[Sequence] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)

        self._current_bundle: Optional[dict] = None
        self._available_months: list[pd.Timestamp] = []

        self.setStyleSheet(
            """
            QWidget {
                background-color: #eef2f7;
            }
            QLabel {
                border: none;
            }
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #cfd6e4;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 12px;
                color: #111827;
                min-height: 20px;
            }
            QComboBox::drop-down {
                border: none;
                width: 24px;
            }
            """
        )

        self._build_ui()

        if available_months is not None:
            self.set_available_months(available_months)

        if business_unit_dashboard_bundle is not None:
            self.set_dashboard_data(business_unit_dashboard_bundle)

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(18)

        header_card = QFrame()
        header_card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(18, 16, 18, 16)
        header_layout.setSpacing(16)

        title_block = QVBoxLayout()
        title = QLabel("Business Unit Performance")
        title.setStyleSheet(
            "font-size: 24px; font-weight: 800; color: #111827;"
        )

        subtitle = QLabel(
            "Monthly sales performance for the selected business unit."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("font-size: 13px; color: #4b5563;")

        title_block.addWidget(title)
        title_block.addWidget(subtitle)

        header_layout.addLayout(title_block)
        header_layout.addStretch()

        filter_block = QVBoxLayout()
        filter_block.setSpacing(8)

        filter_top = QHBoxLayout()
        filter_top.setSpacing(8)

        self.loaded_badge = StatusBadge(
            "Loaded: 0 months", "#dcfce7", "#166534"
        )
        self.loaded_badge.setFixedWidth(150)
        filter_top.addWidget(self.loaded_badge)

        self.scope_badge = StatusBadge("Business Unit", "#dbeafe", "#1d4ed8")
        self.scope_badge.setFixedWidth(120)
        filter_top.addWidget(self.scope_badge)

        filter_top.addStretch()

        controls_row = QHBoxLayout()
        controls_row.setSpacing(8)

        unit_label = QLabel("Business Unit")
        unit_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.unit_selector = QComboBox()
        self.unit_selector.addItems(VALID_BUSINESS_UNITS)
        self.unit_selector.setFixedWidth(160)
        self.unit_selector.currentIndexChanged.connect(
            self._on_business_unit_changed
        )

        month_label = QLabel("Month")
        month_label.setStyleSheet(
            "font-size: 12px; font-weight: 700; color: #374151;"
        )

        self.month_selector = QComboBox()
        self.month_selector.setFixedWidth(180)
        self.month_selector.currentIndexChanged.connect(self._on_month_changed)

        controls_row.addWidget(unit_label)
        controls_row.addWidget(self.unit_selector)
        controls_row.addWidget(month_label)
        controls_row.addWidget(self.month_selector)

        filter_block.addLayout(filter_top)
        filter_block.addLayout(controls_row)

        header_layout.addLayout(filter_block)
        main_layout.addWidget(header_card)

        self.revenue_card = SingleKPICard("Revenue", "Selected month value")
        self.cost_card = SingleKPICard("Cost", "Selected month value")
        self.gross_profit_card = SingleKPICard(
            "Gross Profit", "Selected month value"
        )
        self.gross_margin_card = SingleKPICard(
            "Gross Margin", "Selected month value"
        )

        kpi_grid = QGridLayout()
        kpi_grid.setHorizontalSpacing(14)
        kpi_grid.setVerticalSpacing(14)

        kpi_grid.addWidget(self.revenue_card, 0, 0)
        kpi_grid.addWidget(self.cost_card, 0, 1)
        kpi_grid.addWidget(self.gross_profit_card, 0, 2)
        kpi_grid.addWidget(self.gross_margin_card, 0, 3)

        main_layout.addLayout(kpi_grid)

        bottom_grid = QGridLayout()
        bottom_grid.setHorizontalSpacing(18)
        bottom_grid.setVerticalSpacing(18)

        chart_card = self._make_info_card("Business Unit Trend")
        chart_layout = chart_card.layout()

        self.chart_subtitle = QLabel(
            "Revenue, cost, and gross profit across the available monthly history."
        )
        self.chart_subtitle.setWordWrap(True)
        self.chart_subtitle.setStyleSheet("font-size: 12px; color: #4b5563;")
        chart_layout.addWidget(self.chart_subtitle)

        self.trend_canvas = BusinessUnitTrendCanvas(self)
        chart_layout.addWidget(self.trend_canvas)

        bottom_grid.addWidget(chart_card, 0, 0)

        side_panel = QWidget()
        side_layout = QVBoxLayout(side_panel)
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.setSpacing(14)

        summary_card = self._make_info_card("Quick Summary")
        summary_layout = summary_card.layout()

        self.summary_text = QLabel("No data loaded.")
        self.summary_text.setWordWrap(True)
        self.summary_text.setStyleSheet(
            "font-size: 12px; color: #374151; line-height: 1.5;"
        )
        summary_layout.addWidget(self.summary_text)
        side_layout.addWidget(summary_card)

        legend_card = self._make_info_card("Chart Legend")
        legend_layout = legend_card.layout()
        legend_layout.addWidget(self._make_legend_row("#2563eb", "Revenue"))
        legend_layout.addWidget(self._make_legend_row("#ef4444", "Cost"))
        legend_layout.addWidget(
            self._make_legend_row("#0f766e", "Gross Profit")
        )
        side_layout.addWidget(legend_card)

        self.cafe_breakdown_panel = CafeLocationBreakdownPanel()
        self.cafe_breakdown_panel.hide()
        side_layout.addWidget(self.cafe_breakdown_panel)

        side_layout.addStretch()

        bottom_grid.addWidget(side_panel, 0, 1)
        bottom_grid.setColumnStretch(0, 9)
        bottom_grid.setColumnStretch(1, 4)

        main_layout.addLayout(bottom_grid)

    def _make_info_card(self, title_text: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            """
            QFrame {
                background-color: white;
                border: 1px solid #d9dee7;
                border-radius: 12px;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        title = QLabel(title_text)
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; color: #111827;"
        )
        layout.addWidget(title)

        return card

    def _make_legend_row(self, color: str, text: str) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)

        swatch = QLabel()
        swatch.setFixedSize(16, 16)
        swatch.setStyleSheet(
            f"""
            QLabel {{
                background-color: {color};
                border-radius: 4px;
                border: 1px solid #d1d5db;
            }}
            """
        )

        label = QLabel(text)
        label.setStyleSheet(
            "font-size: 12px; color: #374151; font-weight: 600;"
        )

        row.addWidget(swatch)
        row.addWidget(label)
        row.addStretch()

        return widget

    def set_available_months(self, available_months: Sequence) -> None:
        normalized_months = []

        for month_value in available_months:
            month_ts = pd.Timestamp(month_value).to_period("M").to_timestamp()
            normalized_months.append(month_ts)

        self._available_months = sorted(set(normalized_months))
        self._refresh_month_selector()

    def set_dashboard_data(self, business_unit_dashboard_bundle: dict) -> None:
        self._validate_bundle(business_unit_dashboard_bundle)

        self._current_bundle = business_unit_dashboard_bundle

        selected_unit = str(
            business_unit_dashboard_bundle["selected_business_unit"]
        )
        selected_month = pd.Timestamp(
            business_unit_dashboard_bundle["selected_month"]
        ).to_period("M").to_timestamp()
        selected_month_kpis = business_unit_dashboard_bundle["selected_month_kpis"]
        monthly_trend = business_unit_dashboard_bundle["monthly_trend"].copy()
        unit_summary = business_unit_dashboard_bundle["unit_summary"]

        monthly_trend["month"] = pd.to_datetime(monthly_trend["month"])
        monthly_trend = monthly_trend.sort_values(
            "month").reset_index(drop=True)

        self.loaded_badge.set_badge_style(
            f"Loaded: {len(monthly_trend)} months",
            "#dcfce7",
            "#166534",
        )
        self.scope_badge.set_badge_style(selected_unit, "#dbeafe", "#1d4ed8")

        self._set_selector_to_business_unit(selected_unit)
        self._set_selector_to_month(selected_month)

        self.revenue_card.set_value(
            self._format_currency(selected_month_kpis.get("revenue")),
            subtitle_text="Selected month value",
        )
        self.cost_card.set_value(
            self._format_currency(selected_month_kpis.get("cost")),
            subtitle_text="Selected month value",
        )
        self.gross_profit_card.set_value(
            self._format_currency(selected_month_kpis.get("gross_profit")),
            subtitle_text="Selected month value",
        )
        self.gross_margin_card.set_value(
            self._format_percentage(
                selected_month_kpis.get("gross_margin_pct")
            ),
            subtitle_text="Selected month value",
        )

        self.trend_canvas.plot_unit_trend(monthly_trend, selected_unit)

        selected_month_available = bool(
            unit_summary.get("selected_month_available", False)
        )
        first_month = unit_summary.get("first_month")
        latest_month = unit_summary.get("latest_month")
        available_month_count = unit_summary.get("available_month_count")

        self.summary_text.setText(
            f"Selected unit: {selected_unit}\n"
            f"Selected month: {selected_month.strftime('%B %Y')}\n\n"
            f"Selected month available: {'Yes' if selected_month_available else 'No'}\n"
            f"History span: {self._format_month(first_month)} to {self._format_month(latest_month)}\n"
            f"Available month count: {available_month_count}\n\n"
            f"The chart shows the monthly trend for the selected unit."
        )

        optional_breakdown = business_unit_dashboard_bundle.get(
            "cafe_location_breakdown"
        )
        if selected_unit == "Cafe" and optional_breakdown is not None:
            if isinstance(optional_breakdown, pd.DataFrame):
                self.cafe_breakdown_panel.set_breakdown(
                    optional_breakdown.copy()
                )
            else:
                self.cafe_breakdown_panel.set_breakdown(
                    pd.DataFrame(optional_breakdown)
                )
            self.cafe_breakdown_panel.show()
        else:
            self.cafe_breakdown_panel.hide()

    def _refresh_month_selector(self) -> None:
        self.month_selector.blockSignals(True)
        self.month_selector.clear()

        for month_ts in self._available_months:
            self.month_selector.addItem(
                month_ts.strftime("%B %Y"),
                month_ts.strftime("%Y-%m-%d"),
            )

        self.month_selector.setEnabled(len(self._available_months) > 0)
        self.month_selector.blockSignals(False)

    def _set_selector_to_business_unit(self, business_unit: str) -> None:
        index = self.unit_selector.findText(business_unit)
        if index >= 0:
            self.unit_selector.blockSignals(True)
            self.unit_selector.setCurrentIndex(index)
            self.unit_selector.blockSignals(False)

    def _set_selector_to_month(self, month_value: pd.Timestamp) -> None:
        if not self._available_months:
            return

        target_data = month_value.strftime("%Y-%m-%d")
        index = self.month_selector.findData(target_data)

        if index >= 0:
            self.month_selector.blockSignals(True)
            self.month_selector.setCurrentIndex(index)
            self.month_selector.blockSignals(False)

    def _on_business_unit_changed(self, index: int) -> None:
        if index < 0:
            return

        business_unit = self.unit_selector.currentText()
        if business_unit:
            self.business_unit_changed.emit(business_unit)

    def _on_month_changed(self, index: int) -> None:
        if index < 0:
            return

        month_data = self.month_selector.itemData(index)
        if month_data is not None:
            self.month_changed.emit(str(month_data))

    def _validate_bundle(self, bundle: dict) -> None:
        required_keys = [
            "selected_business_unit",
            "selected_month",
            "selected_month_kpis",
            "monthly_trend",
            "unit_summary",
        ]

        for key in required_keys:
            if key not in bundle:
                raise ValueError(
                    f"business_unit_dashboard_bundle is missing required key: '{key}'"
                )

        selected_unit = bundle["selected_business_unit"]
        if selected_unit not in VALID_BUSINESS_UNITS:
            raise ValueError(
                f"selected_business_unit must be one of {VALID_BUSINESS_UNITS}. Got: {selected_unit}"
            )

        selected_kpi_keys = [
            "month",
            "business_unit",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
        ]
        for key in selected_kpi_keys:
            if key not in bundle["selected_month_kpis"]:
                raise ValueError(
                    f"selected_month_kpis is missing required key: '{key}'"
                )

        trend_df = bundle["monthly_trend"]
        if not isinstance(trend_df, pd.DataFrame):
            raise ValueError("monthly_trend must be a pandas DataFrame.")

        required_trend_columns = [
            "month",
            "business_unit",
            "revenue",
            "cost",
            "gross_profit",
            "gross_margin_pct",
        ]
        for column_name in required_trend_columns:
            if column_name not in trend_df.columns:
                raise ValueError(
                    f"monthly_trend is missing required column: '{column_name}'"
                )

        unit_summary_keys = [
            "business_unit",
            "first_month",
            "latest_month",
            "available_month_count",
            "selected_month_available",
        ]
        for key in unit_summary_keys:
            if key not in bundle["unit_summary"]:
                raise ValueError(
                    f"unit_summary is missing required key: '{key}'"
                )

    def _format_currency(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"${value:,.2f}"

    def _format_percentage(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return f"{value:.2f}%"

    def _format_month(self, value) -> str:
        if value is None or pd.isna(value):
            return "N/A"
        return pd.Timestamp(value).strftime("%B %Y")


if __name__ == "__main__":
    import sys

    demo_trend_df = pd.DataFrame({
        "month": pd.date_range(start="2023-01-01", periods=36, freq="MS"),
        "business_unit": ["Commercial"] * 36,
        "revenue": [55000 + i * 1200 for i in range(36)],
        "cost": [36000 + i * 850 for i in range(36)],
        "gross_profit": [19000 + i * 350 for i in range(36)],
        "gross_margin_pct": [34.55 + (i * 0.03) for i in range(36)],
    })

    demo_bundle = {
        "selected_business_unit": "Commercial",
        "selected_month": "2025-12-01",
        "selected_month_kpis": {
            "month": "2025-12-01",
            "business_unit": "Commercial",
            "revenue": 97000.0,
            "cost": 65750.0,
            "gross_profit": 31250.0,
            "gross_margin_pct": 32.22,
        },
        "monthly_trend": demo_trend_df,
        "unit_summary": {
            "business_unit": "Commercial",
            "first_month": "2023-01-01",
            "latest_month": "2025-12-01",
            "available_month_count": 36,
            "selected_month_available": True,
        },
    }

    demo_months = pd.date_range(start="2023-01-01", periods=36, freq="MS")

    app = QApplication(sys.argv)

    widget = BusinessUnitDashboard(
        business_unit_dashboard_bundle=demo_bundle,
        available_months=demo_months,
    )
    widget.resize(1380, 820)
    widget.business_unit_changed.connect(print)
    widget.month_changed.connect(print)
    widget.show()

    sys.exit(app.exec())